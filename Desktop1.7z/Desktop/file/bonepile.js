document.addEventListener('DOMContentLoaded', () => {
    loadData();
    loadEvent();
});

const loadEvent = () => {

    document.querySelector('select[name="sl-option"]').addEventListener('change', function(e){
        document.querySelectorAll('.cft-change').forEach(elem => {
            elem.textContent = e.target.value;
        })
    })
 };

const loadData = () => {
    highchartsInit();
    getDailyBonepileInventory();
    getDailyBonepileInventory2();
    getDailyREInOut();
    getTop10Model();
    getTopERC();
};

const highchartsInit = () => {
    Highcharts.setOptions({
        chart: {
            backgroundColor: 'transparent',
            spacing: [10, 5, 0, 5],
        },

        xAxis: {
            gridLineWidth: 1,
            gridLineColor: '#313f62',
            gridLineDashStyle: 'Dash',
            lineWidth: 1,
            lineColor: '#313f62',
            lineDashStyle: 'ShortDash',
            labels: {
                style: {
                    fontSize: '1rem',
                    fontWeight: '600',
                    color: '#7a95c3',
                },
            },
        },

        yAxis: {
            gridLineWidth: 1,
            gridLineColor: '#313f62',
            gridLineDashStyle: 'Dash',
            labels: {
                style: {
                    fontSize: '1rem',
                    fontWeight: '600',
                    color: '#7a95c3',
                },
            },
        },

        credits: {
            enabled: false,
        },

        plotOptions: {
            series: {
                borderWidth: 0,
                dataLabels: {
                    enabled: true,
                    style: {
                        color: '#fff',
                        textOutline: 0,
                        fontWeight: 'normal',
                        fontSize: '1rem'
                    }
                }
            },
        },
    });
};

// Chart 1
const getDailyBonepileInventory = () => {
    Highcharts.chart('chart-1', {
        chart: {
            type: 'line',
            backgroundColor: 'transparent',
        },
        title: null,
        accessibility: {
            point: {
                valueDescriptionFormat: '{xDescription}{separator}{value} million(s)',
            },
        },
        xAxis: {
            title: null,
            categories: [1995, 2000, 2005, 2010, 2015, 2020, 2023],
        },
        yAxis: {
            title: null,
        },
        tooltip: {
            headerFormat: '<b>{series.name}</b><br />',
            pointFormat: '{point.y} million(s)',
        },
        legend: {
            enabled: false,
        },
        plotOptions: {
            line: {
                dataLabels: {
                    enabled: true,
                    style: {
                        color: '#fff',
                        textOutline: 0
                    }
                }
            }
        },
        series: [
            {
                name: 'Internet Users',
                data: [16, 361, 1018, 2025, 3192, 4673, 5200],
                color: 'var(--highcharts-color-1, #2caffe)',
            },
        ],
    });
};

// Chart 2
const getDailyBonepileInventory2 = () => {
    Highcharts.chart('chart-2', {
        chart: {
            type: 'line',
            backgroundColor: 'transparent',
        },
        title: null,
        accessibility: {
            point: {
                valueDescriptionFormat: '{xDescription}{separator}{value} million(s)',
            },
        },
        xAxis: {
            title: null,
            categories: [1995, 2000, 2005, 2010, 2015, 2020, 2023],
        },
        yAxis: {
            title: null,
        },
        tooltip: {
            headerFormat: '<b>{series.name}</b><br />',
            pointFormat: '{point.y} million(s)',
        },
        legend: {
            enabled: false,
        },
        series: [
            {
                name: 'Internet Users',
                data: [16, 361, 1018, 2025, 3192, 4673, 5200],
                color: 'var(--highcharts-color-1, #2caffe)',
            },
        ],
    });
};

// Chart 3
const getDailyREInOut = () => {
    Highcharts.chart('chart-3', {
        chart: {
            type: 'column',
            events: {
                load: function () {
                    const chart = this;
                    const legendContainer = document.getElementById('legend-chart-3');

                    legendContainer.innerHTML = '';
                    chart.series.forEach((series) => {
                        const btn = document.createElement('span');
                        btn.textContent = series.name;
                        btn.style.display = 'flex';
                        btn.style.alignItems = 'center';
                        btn.style.columnGap = '5px';
                        btn.style.margin = '5px';
                        btn.style.fontSize = '0.7rem';
                        btn.style.color = series.visible ? series.color : '#ccc';
                        btn.style.textDecoration = series.visible ? 'unset' : 'line-through';
                        btn.onclick = () => {
                            series.setVisible(!series.visible);
                            btn.style.color = series.visible ? series.color : '#ccc';
                            btn.style.textDecoration = series.visible ? 'unset' : 'line-through';
                        };

                        const circle = document.createElement('span');
                        circle.style.display = 'inline-block';
                        circle.style.width = '10px';
                        circle.style.height = '10px';
                        // circle.style
                        circle.style.backgroundColor = series.visible ? series.color : '#ccc';

                        btn.prepend(circle);

                        legendContainer.appendChild(btn);
                    });
                }
            }
        },
        title: null,
        xAxis: {
            categories: ['Arsenal', 'Chelsea', 'Liverpool', 'Manchester United'],
        },
        yAxis: {
            min: 0,
            softMax: 10,
            title: null,
            stackLabels: {
                enabled: true,
            },
        },
        legend: {
            enabled: false,
            align: 'right',
            x: 0,
            verticalAlign: 'top',
            y: 0,
            floating: true,
            itemStyle: {
                color: '#7a95c3'
            },
            shadow: false,
            padding: 5,
        },
        tooltip: {
            headerFormat: '<b>{category}</b><br/>',
            pointFormat: '{series.name}: {point.y}<br/>Total: {point.stackTotal}',
        },
        plotOptions: {
            column: {
                stacking: 'normal',
                borderWidth: 0,
                maxPointWidth: 40,
                dataLabels: {
                    enabled: true,
                    style: {
                        color: '#fff',
                        textOutline: '1px contrast',
                        fontWeight: 'normal',
                    },
                },
            },
        },
        series: [
            {
                name: 'Check-in',
                color: '#fddd60',
                data: [3, 5, 1, 90],
            },
            {
                name: 'Check-out',
                color: '#7cffb2',
                data: [14, 8, 8, 12],
            },
        ],
    });
};

// Chart 4
const getTop10Model = () => {
    Highcharts.chart('chart-4', {
        title: null,
        xAxis: {
            categories: ['Error A', 'Error B', 'Error C', 'Error D', 'Error E'],
            crosshair: true,
        },
        yAxis: [
            {
                title: null
            },
            {
                title: null,
                minPadding: 0,
                maxPadding: 0,
                max: 100,
                min: 0,
                opposite: true,
                labels: {
                    format: '{value}%',
                },
            },
        ],
        tooltip: {
            shared: true,
        },
        legend: {
            enabled: false,
        },
        plotOptions: {
            column: {
                maxPointWidth: 40
            }
        },
        series: [
            {
                type: 'column',
                name: 'Occurrences',
                color: '#4992ff',
                data: [45, 26, 12, 8, 5],
                zIndex: 2,
            },
            {
                type: 'pareto',
                name: 'Pareto',
                color: '#f1cf28',
                yAxis: 1,
                zIndex: 3,
                baseSeries: 0, // lấy dữ liệu từ series[0]
            },
        ],
    });
};

// Chart 5
const getTopERC = () => {
    Highcharts.chart('chart-5', {
        title: null,
        xAxis: {
            categories: ['Error A', 'Error B', 'Error C', 'Error D', 'Error E'],
            crosshair: true,
        },
        yAxis: [
            {
                title: null
            },
            {
                title: null,
                minPadding: 0,
                maxPadding: 0,
                max: 100,
                min: 0,
                opposite: true,
                labels: {
                    format: '{value}%',
                },
            },
        ],
        tooltip: {
            shared: true,
        },
        legend: {
            enabled: false,
        },
        plotOptions: {
            column: {
                maxPointWidth: 40
            }
        },
        series: [
            {
                type: 'column',
                name: 'Occurrences',
                color: '#4992ff',
                data: [45, 26, 12, 8, 5],
                zIndex: 2,
            },
            {
                type: 'pareto',
                name: 'Pareto',
                color: '#f1cf28',
                yAxis: 1,
                zIndex: 3,
                baseSeries: 0, // lấy dữ liệu từ series[0]
            },
        ],
    });
};
// Table 3
const getAgingDateDistribution = () => { };
