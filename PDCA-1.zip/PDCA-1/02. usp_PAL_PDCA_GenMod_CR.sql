USE [PAL_Module]
GO
/****** Object:  StoredProcedure [dbo].[usp_PAL_PDCA_GenMod_CR]    Script Date: 2026-03-26 9:05:57 SA ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO



ALDDDDTER Procedure [dbo].[usp_PAL_PDCA_GenMod_CR]
		(@FromDateTime varchar(20)='',
		@ToDateTime varchar(20)='')
As
Set NoCount ON
----------------------------------------------------------------------------------------------
-----Created by Meng Zhang on 2016/03/18.
-----Purpose: 收集CR的拣料记录
-----频率：每半小时送一次.
-----每次产生上一个小时时段内的资料.
----------------------------------------------------------------------------------------------
--########## Update Log Begin  ###################
--Date             UpdateOwner   Description
--2016/03/20 20:25  Meng        应客户的要求当这段时间没有生产的时候就不用发送只有一个#End的数据（0001）
--2016/05/15 14:52  Meng        应客户的要求将该数据加入到监控里面：在40.6里面进行发送到PDCA和PDCA反馈数据对比（0002）
--2016/05/17        Lisa Han    加上TRY catch的逻辑(0003) 
--2016/06/11 15:42  Meng        拣料数据当前表里面找不到要去历史数据库去找(0004) 
--2016/06/11 15:42  Meng        拣料的数据实时发送，改变原来入库时发送的逻辑(0005) 
--2016/11/06 14:47  Meng		删除的材料会塞一笔"D"到CompSN_PDCA_DelLog，送PDCA的时候需要看这张表(0006)
--2017/02/07 14:30  Meng		应PDCA客户 Michelle要求需要送 LGP 的资料(0007)
--2017/05/01 14:30  Lisa		将拣料表的数据收集到CompSN_Transfer_MDS，最终将被送到[17.80.233.241](0008)
--2017/05/01 15:00  Meng		更新QCI_Model   （0009）
--2017/05/13 19:10  Meng		应PDCA Michelle需求,如果是LCD则需要在最后一栏放52码的材料SN,目前只是针对于J79/J130系列   （0010）
--2019/02/14 15:51  OuYang      取消原来Housing Module 送捡料信息，新增J290(当整机)的MLB送捡料信息（0011）
--2019/10/09 10:00  OuYang      PDCA Material Name Mapping(0012)
--2020/04/08 10:28  Freedom     材料名称改为大写  (0013)
--2020/07/21 08:21  Freedom     将EnginneringID的长度由52调整为200 （0014）
--2021/04/28 08:21  Freedom     将Comp_SN varchar(100)的长度调整为200 （0015）
--2021/05/20 13:14  Freedom     捡料部分有J290，去掉S (0016)
--2022/07/13		Tacey		将txt塞进PAL_PDCA_Compare，该功能客人已通知取消,取消塞入此表(0017）
--2023/02/16 13:14  Freedom     Follow整机送'D'时由之前Link时间transdatetime,修改成deldatetime并往前推5秒,客户在问为什么这么短的时间可以删除然后装上去（0018）
--2023/06/02 10:52  Freedom     Follow Fatp取消送PQC_Repair,会有两笔D的记录。（0019）
--2023/06/19		Tacey		应QM,SW需要同步送insight捡料资料(0020）
--2024/12/13        River       Change IP from 10.33.83.149 -> 10.33.223.66  (0021)
--2024/12/25		Tacey		King:客人要求送datecode,FILM1,FILM2排除(0022）
--2025/04/04		River		In order to facilitate the subsequent adjustment of FTPServer IP, the remote SF_Data path is maintained in the table File_Path (0023)
--2025/05/12		Neil		(Flow QSMC)King:客人要求FILM1,FILM2送datecode,将几合一的每个膜片datecode以空格连接在一起作为整体datecode(0024）
--2026/03/20		Neil		CmdShell更改为CLR   0025
--##########Update Log End # ###################
----------------------------------------------------------------------------------------------
-----------------------------------------------------------
------避免同时间点数据还未塞进来，从而造成少量Data Missing.
Declare @Flag_1 varchar(10)='N'
-----------------0001 
declare @ErrMsg Nvarchar(4000)=''
declare @StepFlag varchar(100)=''
declare @SP_Name varchar(100)=''
Declare @FlatFileName varchar(100)=''
Declare @strSQL nvarchar(600)=''
Declare @iResult Varchar(200)='' , @iMessage Nvarchar(max)='' , @parametersJson NVARCHAR(MAX)='',  @pathJson Nvarchar(max)=''

Declare @FileBKPath varchar(300)=''
Declare @FileLocalPath varchar(300)='e:\PALFA\Share\PDCA\WWSFS\Import\MOD-TRACK\'
Declare @Model varchar(20)=''
Declare @SF_DataSourcePath Varchar(1000) ='' ---0023
Begin Try
	set @SP_Name=isnull(OBJECT_NAME(@@PROCID),'' )
	set @StepFlag='Try Start'
-----------------0001 

	If Len(@FromDateTime)!=14 or Len(@ToDateTime)!=14
	Begin
		Set @Flag_1 ='Y'
		Select @FromDateTime =dbo.FormatDate(DATEADD(HOUR,-1,GetDate()),'YYYYMMDDHH')+'0000'
		Select @ToDateTime =dbo.FormatDate(DateAdd(Minute,-1,GetDate()),'YYYYMMDDHHNNSS')
	End
	-----------------------------------------------------------
	---采用断点续传的方法
	Declare @StartDateTime varchar(20)
	Set @StartDateTime=''
	-----------------------------------------------------------
	----Select top 1000 * From FAeDatetime Where category='CRModTrack'
	Declare @Flag varchar(10)='N'
	If @Flag_1 ='Y'
	Begin
	Set @Flag ='Y'
	Select @StartDateTime=EDatetime  From FAeDatetime Where category='CRModTrack'
	--print @StartDateTime
	Set @FromDateTime=@StartDateTime
	End

	
	--0023 Begin
	exec File_Path_GetValue   @SP_Name ,'SF_DataPath', @SF_DataSourcePath output 
	--0023 End

	------------------------------------------------------------------------------------------
	--Select QCI_SN,TransDateTime  Into #PAL_SN From PAL_SN
	--Where TransDateTime BETWEEN @FromDateTime AND @ToDateTime
	--AND Status ='9H'
	--Select B.TransDateTime as TransDateTime_1 ,B.* Into #COMPSN From #PAL_SN A WITH(NOLOCK) JOIN COMPSN B  WITH(NOLOCK)
	--ON A.QCI_SN =B.PAL_SN
	------------------------------------------------------------------------------------------
	------0004 Begin
	--Select A.* Into #Null From #PAL_SN A With(Nolock) Left Join #COMPSN B With(Nolock)
	--On A.QCI_SN =B.PAL_SN 
	--	Where B.PAL_SN Is Null 
	--Insert Into #COMPSN
	--Select B.TransDateTime as TransDateTime_1 ,B.* From #Null A WITH(NOLOCK) JOIN PALModuleBK.dbo.COMPSN B  WITH(NOLOCK)
	--ON A.QCI_SN =B.PAL_SN
	------0004 End
	------------------------------------------------------------------------------------------
	Select TransDateTime as TransDateTime_1 ,* Into #COMPSN From COMPSN WITH(NOLOCK)
		Where TransDateTime BETWEEN @FromDateTime AND @ToDateTime
	set @StepFlag='1'
	----0008 Begin
	--将CompSN的数据收集到CompSN_Transfer_MDS，最终将被送到[17.80.233.241]
	 Declare @CollectDateTime varchar(100)=dbo.FormatDate(GetDate(),'YYYYMMDDHHNNSS')
	 Insert Into CompSN_Transfer_MDS( PAL_SN, Comp_SN, Comp_PN, Station, Trans_Date, Trans_Time,	 Line, Comp_Rev, Comp_Name, EEE_Code, Cust_PN, Vendor, Type, TransDateTime, QCI_Model ,SourceIP ,CollectDateTime)
		Select PAL_SN, Comp_SN, Comp_PN, Station, Trans_Date, Trans_Time, Line, Comp_Rev, Comp_Name, EEE_Code, Cust_PN, Vendor, Type, TransDateTime, QCI_Model ,'10.36.6.86',@CollectDateTime
		FROM  #COMPSN with(nolock) where comp_name ='MLB'and QCI_Model='J290' ------comp_name ='Housing'--------0011
	----0008 End

select top 100 * from CompSN_Transfer_MDS with(nolock)

	--INSERT #COMPSN
	--SELECT   TransDateTime as TransDateTime_1 , B.*   FROM  ___M ENG1 A   join PALModuleBK..COMPSN B 
	--on A.c1 =B.PAL_SN AND A.c =B.Comp_Name 
	set @StepFlag='2'--0015
	Create table #Temp_PDCA_Module(PAL_SN varchar(100),PickDate varchar(100),PickTime varchar(100),Cust_PN varchar(100),Comp_Name varchar(100)
	,Comp_SN varchar(200),EEE_Code varchar(100),Line varchar(100),LotCode varchar(100),DateCode varchar(100),Vendor varchar(100),Flag varchar(100))
	Insert Into #Temp_PDCA_Module
	Select A.PAL_SN,
			Substring(dbo.FormatDate(dbo.Convert2Date(A.TransDateTime_1),'YYYYMMDD HH:NN:SS'),1,8) As PickDate,
			Substring(dbo.FormatDate(dbo.Convert2Date(A.TransDateTime_1),'YYYYMMDD HH:NN:SS'),10,8) As PickTime,
		A.Cust_PN,A.Comp_Name,A.Comp_SN,A.EEE_Code,A.Line,'' As LotCode,'' As DateCode,A.Vendor,'A' As Flag  
		From #CompSN A with (nolock)
		
	------------------------------------------------------------------------------------------
	--0006 Begin
	--(对于以下Update语句处理方式原因在于：前一次的”A”(Add)还未送出就被”D”(Delete), 这样这次的”D”是不用送的.
	---逻辑: 对于CompSN_PDCA_DelLog中DeleteDateTime与TransDateTime属于同一区段(00~15, 15~30, 30~45, 45~00)的数据,则不要送”D”.)
	Update CompSN_PDCA_DelLog
		Set SendPDCAFlag ='X' Where OperationType ='Swap BackFlow Comp'
		And SendPDCAFlag ='N'
		And TransDateTime between @FromDateTime and @ToDateTime 
		And DelDateTime between @FromDateTime and @ToDateTime
	set @StepFlag='3'
	Insert Into #Temp_PDCA_Module
		Select PAL_SN,
			--Substring(dbo.FormatDate(dbo.Convert2Date(TransDateTime),'YYYYMMDD HH:NN:SS'),1,8) As PickDate,
			--Substring(dbo.FormatDate(dbo.Convert2Date(TransDateTime),'YYYYMMDD HH:NN:SS'),10,8) As PickTime,----0018
			Substring( [dbo].[FormatDate](DateAdd(s,-5,dbo.Convert2Date(DelDateTime)),'YYYYMMDD HH:NN:SS'),1,8) As PickDate,
            Substring( [dbo].[FormatDate](DateAdd(s,-5,dbo.Convert2Date(DelDateTime)),'YYYYMMDD HH:NN:SS'),10,8) As PickTime,
			Cust_PN,Comp_Name,Comp_SN,EEE_Code,Line,'' As LotCode,'' As DateCode,Vendor,'D' As Flag
		From CompSN_PDCA_DelLog with(nolock) 
		Where Deldatetime between @FromDateTime and @ToDateTime 
		And SendPDCAFlag ='N'

	Update CompSN_PDCA_DelLog
		Set sendPDCAflag ='Y' 
		From CompSN_PDCA_DelLog 
		Where Deldatetime between @FromDateTime and @ToDateTime
		And SendPDCAFlag ='N'

	--0006 End
	------------------------------------------------------------------------------------------
	--Insert Into #Temp_PDCA_Module
	--Select A.PAL_SN,
	--	Substring(dbo.FormatDate(dbo.Convert2Date(A.TransDateTime),'YYYYMMDD HH:NN:SS'),1,8) As PickDate,
	--	Substring(dbo.FormatDate(dbo.Convert2Date(A.TransDateTime),'YYYYMMDD HH:NN:SS'),10,8) As PickTime,
	--A.Cust_PN,A.Comp_Name,A.Comp_SN,A.EEE_Code,A.Line,'' As LotCode,'' As DateCode,A.Vendor,'A' As Flag  
	--From CompSN A with (nolock) Where PAL_SN IN(Select COL1 From   ___M eng1 ) 

	--Insert Into #Temp_PDCA_Module
	--Select A.PAL_SN,
	--	Substring(dbo.FormatDate(dbo.Convert2Date(A.TransDateTime),'YYYYMMDD HH:NN:SS'),1,8) As PickDate,
	--	Substring(dbo.FormatDate(dbo.Convert2Date(A.TransDateTime),'YYYYMMDD HH:NN:SS'),10,8) As PickTime,
	--A.Cust_PN,A.Comp_Name,A.Comp_SN,A.EEE_Code,A.Line,'' As LotCode,'' As DateCode,A.Vendor,'A' As Flag  
	--From PALModuleBK.DBO.CompSN A with (nolock) Where PAL_SN IN(Select COL1 From   ___M eng1 ) 
	------------------------------------------------------------------------------------------
	set @StepFlag='4'
	---处理PQC_Repair里面的'D'
	---0005 Begin----0019
	--Insert Into #Temp_PDCA_Module
	--Select A.Serial_Number,
	--		--Substring(dbo.FormatDate(dbo.Convert2Date(A.TransDateTime),'YYYYMMDD HH:NN:SS'),1,8) As PickDate,
	--		--Substring(dbo.FormatDate(dbo.Convert2Date(A.TransDateTime),'YYYYMMDD HH:NN:SS'),10,8) As PickTime,-----0018
	--		Substring( [dbo].[FormatDate](DateAdd(s,-5,dbo.Convert2Date(A.TransDateTime)),'YYYYMMDD HH:NN:SS'),1,8) As PickDate,
 --           Substring( [dbo].[FormatDate](DateAdd(s,-5,dbo.Convert2Date(A.TransDateTime)),'YYYYMMDD HH:NN:SS'),10,8) As PickTime,
	--	C.Option_Code,A.RepairCode,A.Comp_SN,Right(Replace(Replace(Replace( b.Option_Barcode,'*',''),'+',''),'-',''),4) ,A.Line,'' As LotCode,'' As DateCode,c.Supplier as Vendor,'D' As Flag  
	--From PQC_Repair A with (nolock) ,option_tag B with(nolock) ,TDDOptio C with(nolock) 
	--	Where A.TransDateTime Between @FromDateTime AND @ToDateTime
	--	And A.Comp_PN=B.option_code
	--	and Len(A.Comp_SN)=Len(B.option_barcode)
	--	and A.NewComp_SN!=''
	--	and A.SolutionCode='SWAP'
	--	and A.Comp_SN like Replace(B.Option_Barcode,'*','_')
	--	and A.Comp_PN=C.Option_Code
	----------------------------------------------------------------------------------------------
	set @StepFlag='5'
	--处理报废里面的'D'
	Insert Into #Temp_PDCA_Module
	Select A.PAL_SN,
			--Substring(dbo.FormatDate(dbo.Convert2Date(A.TransDateTime),'YYYYMMDD HH:NN:SS'),1,8),
			--Substring(dbo.FormatDate(dbo.Convert2Date(A.TransDateTime),'YYYYMMDD HH:NN:SS'),10,8) ,--------0018 --REPDateTime
			Substring(dbo.FormatDate(dbo.Convert2Date(A.REPDateTime),'YYYYMMDD HH:NN:SS'),1,8),
			Substring(dbo.FormatDate(dbo.Convert2Date(A.REPDateTime),'YYYYMMDD HH:NN:SS'),10,8) ,
		A.Cust_PN,A.Comp_Name,A.Comp_SN,A.EEE_Code,A.Line,'' As LotCode,'' As DateCode,A.Vendor,'D' As Flag  
		From CompSN_BK_REP  A with (nolock)
		Where TransDateTime BETWEEN @FromDateTime AND @ToDateTime

		select top 100 * from CompSN_BK_REP with(nolock)
	---0005 End
	----------------------------------------------------------------------------------------------
	Delete A From  #Temp_PDCA_Module A with(nolock), OPTION_TAG B with(nolock) 
		Where A.Comp_SN like Replace(B.OPTION_BARCODE ,'*','_')
		And LEN(A.Comp_SN) = len(B.OPTION_BARCODE)
		And (B.OPTION_NAME like '%QSMC SN'
		--OR b.OPTION_NAME ='LGP'	--0007
		OR b.OPTION_NAME ='ROE SN')
	update a 
	set a.line=b.PDCA_Line 
	From  #Temp_PDCA_Module a inner join PAL_Routing_Line b 
	on a.line=b.line 
	Where b.Line!=b.PDCA_Line and b.PDCA_Line!=''and b.SendToPDCA='Y' 
	Delete #Temp_PDCA_Module Where line not in (select PDCA_Line from PAL_Routing_Line)
	set @StepFlag='7'
	--0010 Begin-----0014
	Select *,Cast('' As Varchar(200)) LCD52Bit,Cast('' As Varchar(10)) Model Into #PDCA_Module From #Temp_PDCA_Module

	Update A
		Set A.Model =C.Model 
		From #PDCA_Module A,PAL_SN C
		Where A.PAL_SN =C.QCI_SN 

	SELECT TOP 100 * FROM PAL_Comp_PQC_EngID WITH(NOLOCK)

	Update A
		Set LCD52Bit=B.EnginneringID 
		From #PDCA_Module A,PAL_Comp_PQC_EngID B 
		Where A.Comp_Name ='LCD' And A.Comp_SN =B.Serial_number 
		--And (A.Model Like 'J79%' Or A.Model Like 'J130%')

	If Exists(Select * From #PDCA_Module Where LCD52Bit='' And Comp_Name ='LCD' /*And (Model Like 'J79%' Or Model Like 'J130%')*/)
	Begin
		Update A
			Set LCD52Bit=B.EnginneringID 
			From #PDCA_Module A,PALModuleBK.dbo.PAL_Comp_PQC_EngID B 
			Where A.Comp_Name ='LCD' And A.Comp_SN =B.Serial_number 
			--And (A.Model Like 'J79%' Or A.Model Like 'J130%')
			And A.LCD52Bit=''
	End
-------	Update #PDCA_Module Set LCD52Bit='' Where Len(LCD52Bit)<>52 And Comp_Name ='LCD'-----0014

	-----0022 begin
	update #PDCA_Module set DateCode= case when len(EEE_Code)=4 then SUBSTRING(Comp_SN,4,4) else SUBSTRING(Comp_SN,4,3) end 
	where Comp_Name not in('FILM1','FILM2')

	---0024
	update #PDCA_Module set DateCode= (SELECT STRING_AGG(substring(val,17,3), ' ') 
						 FROM (SELECT SUBSTRING(comp_sn,Number*25-24,25) AS val
							   FROM master..spt_values
							   WHERE Type='P' AND Number BETWEEN 1 AND (LEN(comp_sn)+24)/25)
						 AS t)
	where Comp_Name in('FILM1','FILM2')

	-----0022 end

	select top 100 * from MaterialName_Mapping with(nolock) 

	Update A
		Set A.Comp_Name=B.PDCAMaterial_Name 
		From #PDCA_Module A,[dbo].[MaterialName_Mapping] B 
		Where A.Comp_Name =B.SFMaterial_Name
	--0010 End
	--0009
	------------0016
	Update  #PDCA_Module Set PAL_SN=right(PAL_SN,len(PAL_SN)-1) where PAL_SN like'S%'

	-------------
	--Insert Into PAL_PDCA_ModTrack_File_CR (COL1 ,QCI_Model)
		Select Distinct upper([PAL_SN])+char(9)+[PickDate]+char(9)+[PickTime]+char(9)+[Cust_PN]+char(9)+upper([Comp_Name])     --------0013
				+char(9)+ upper([Comp_SN])+char(9)+[EEE_Code]+char(9)+[Line]+char(9)+[LotCode]+char(9)+[DateCode]+char(9)+[Vendor]+char(9)+[Flag]+char(9)+LCD52Bit As Col1,Model 
		Into #PAL_PDCA_ModTrack_File_CR
		From #PDCA_Module  

	Select Distinct Model Into #PAL_PDCA_ModTrack_Model From #PAL_PDCA_ModTrack_File_CR 
	----------------------------------------------------------------------------------------------
	
	Declare @CurrentDateTime varchar(19)
	Set @CurrentDateTime=Replace(Replace(Replace(Convert(varchar(19),GetDate(),121),'-',''),':',''),' ','')
	--Print @CurrentDateTime
	Declare @iYear varchar(6)
	Declare @iMonth varchar(6)
	Declare @iDay varchar(6)

	SET @parametersJson =  (SELECT 'E:\PALFA\Share\PDCA\WWSFS\Import\MOD-TRACK' as path FOR JSON PATH,WITHOUT_ARRAY_WRAPPER)
	Exec PAL_Module.dbo.CMDSHELL2CLR 'CreateDirectory',@parametersJson,@iResult output ,@iMessage output   --0025
	--Set @strSQL='"MD e:\PALFA\Share\PDCA\WWSFS\Import\MOD-TRACK"'
	--EXEC master..xp_cmdshell @strSQL
	
	Set @iYear=Substring(@CurrentDateTime,1,4)
	Set @iMonth=Substring(@CurrentDateTime,5,2)
	Set @iDay=Substring(@CurrentDateTime,7,2)
	----------------------------------------------------------------------------------------------

	SET @parametersJson =  (SELECT 'E:\PALFA\Share\PDCA\WWSFS\Import\MOD-TRACK_BK\'+@iYear+'\'+@iMonth+'\'+@iDay as path FOR JSON PATH,WITHOUT_ARRAY_WRAPPER)
	Exec PAL_Module.dbo.CMDSHELL2CLR 'CreateDirectory',@parametersJson,@iResult output ,@iMessage output   --0025


	--Set @strSQL='"MD E:\PALFA\Share\PDCA\WWSFS\Import\MOD-TRACK_BK\'+@iYear+'"'
	--EXEC master..xp_cmdshell @strSQL

	--Set @strSQL='"MD E:\PALFA\Share\PDCA\WWSFS\Import\MOD-TRACK_BK\'+@iYear+'\'+@iMonth+'"'
	--EXEC master..xp_cmdshell @strSQL

	--Set @strSQL='"MD E:\PALFA\Share\PDCA\WWSFS\Import\MOD-TRACK_BK\'+@iYear+'\'+@iMonth+'\'+@iDay
	--EXEC master..xp_cmdshell @strSQL

	Set @FileBKPath='E:\PALFA\Share\PDCA\WWSFS\Import\MOD-TRACK_BK\'+@iYear+'\'+@iMonth+'\'+@iDay+'\'
	set @StepFlag='8'
	----------------------------------------------------------------------------------------------
	------0020 ---1---------------
	--exec master..xp_cmdshell 'net use \\172.26.65.52\m\Louis\SF_CR_Insight 123 /user:rd-ssd5'
	--exec master..xp_cmdshell 'net use \\10.33.83.149\SF_Data\SF_CR_Insight 1234 /user:qmh_beck1' 
	--exec master..xp_cmdshell 'net use \\10.33.223.66\SF_Data\SF_CR_Insight 1234 /user:qmh_beck1' --0021

	SET @parametersJson = ( 
		SELECT 
			'qmh_beck1' as username  --0025
			,'1234' as password   ----- V0001调整密码123到QSMCSW+0987654321 --0025
			,'\\10.33.165.57\SF_Data\SF_CR_Insight' as path
			,@SP_Name as CallSP
		FOR JSON PATH,WITHOUT_ARRAY_WRAPPER); 
	Exec PAL_Module.dbo.CMDSHELL2CLR 'CreateConnection',@parametersJson,@iResult output ,@iMessage output 

	
	
	 --Set @strSQL = 'net use '+@SF_DataSourcePath+' 1234 /user:qmh_beck1' ---0023
  -- exec master..xp_cmdshell @strSQL

	----------------------------------------------------------------------------------------------
	While Exists(Select * From #PAL_PDCA_ModTrack_Model)  
	Begin
		Select Top 1 @Model=Model From #PAL_PDCA_ModTrack_Model
		Truncate Table PAL_PDCA_ModTrack_File_CR


		select top 100 * from PAL_PDCA_ModTrack_File_CR with(nolock)
		Insert Into PAL_PDCA_ModTrack_File_CR (Col1) 
			Select Col1 From #PAL_PDCA_ModTrack_File_CR Where Model=@Model 
			Union All
			Select '#END'
		Set @FlatFileName='QCMT_FATP_MOD_'+@Model+'CR_'+@ToDateTime+'.txt'
		----------------------------------------------------------------------------------------------
				
		--Set @strSQL='bcp "Select COL1 From PAL_Module.dbo.PAL_PDCA_ModTrack_File_CR  Order by Col1 Desc" queryout e:\PALFA\Share\PDCA\WWSFS\Import\MOD-TRACK\'+
		--	@FlatFileName+
		--	' -c -S"10.36.6.86" -U"sa" -P"East#86_qmh2024"'
		--EXEC master..xp_cmdshell @strSQL		
				SET @pathJson = ( 
			Select COL1 From PAL_Module.dbo.PAL_PDCA_ModTrack_File_CR  Order by Col1 Desc
			FOR JSON PATH);  

		SET @parametersJson = ( 
			SELECT 
				@FileBKPath+@FlatFileName as path
				,@pathJson as jsonString 
				,'N' as header
		--		,'\t' as split 
				,@SP_Name as CallSP
			FOR JSON PATH,WITHOUT_ARRAY_WRAPPER); 
		Exec [PAL_Module].dbo.CMDSHELL2CLR 'CreateFile',@parametersJson ,@iResult output ,@iMessage output	
		--Set @strSQL='bcp "Select COL1 From PAL_Module.dbo.PAL_PDCA_ModTrack_File_CR  Order by Col1 Desc" queryout '+
		--	@FileBKPath+@FlatFileName+
		--	' -c -S"10.36.6.86" -U"sa" -P"East#86_qmh2024"'
		----Print @strSQL
		--EXEC master..xp_cmdshell @strSQL
		----------------------------------------------------------------------------------------
		Waitfor Delay '00:00:00.200'
			SET @parametersJson = ( 
			SELECT 
				@FileBKPath as Sourcepath 
				,@FileLocalPath as Destpath 
				,@FlatFileName as filename
				,@FlatFileName as newfilename
				,@SP_Name as CallSP
			FOR JSON PATH,WITHOUT_ARRAY_WRAPPER); 
		Exec [PAL_Module].dbo.CMDSHELL2CLR 'CopyFile',@parametersJson,@iResult output ,@iMessage output --0025
		--Set @strSQL='"Copy '+@FileBKPath+@FlatFileName+' '+@FileLocalPath+'"'
		--EXEC master..xp_cmdshell @strSQL
		----------------------------------------------------------------------------------------
		------0002 Begin ---0017
		--每产生一个txt就将该txt塞进PAL_PDCA_Compare
		--Insert Into PAL_PDCA_Compare
		--Select @FlatFileName,'Mod_CRMANUAL',@ToDateTime,'','N'
		------0002 End
		----------0020 ----2  生成一份到SW server
		--  Set @strSQL='bcp "Select Col1 from PAL_Module.dbo.PAL_PDCA_ModTrack_File_CR  Order by Col1 Desc" queryout \\10.33.83.149\SF_Data\SF_CR_Insight\'+ 
	   -- Set @strSQL='bcp "Select Col1 from PAL_Module.dbo.PAL_PDCA_ModTrack_File_CR  Order by Col1 Desc" queryout \\10.33.223.66\SF_Data\SF_CR_Insight\'+    --0021

	   SET @parametersJson = ( 
			SELECT 
				@FileBKPath as Sourcepath 
				,'\\10.33.165.57\SF_Data\SF_CR_Insight' as Destpath 
				,@FlatFileName as filename
				,@FlatFileName as newfilename
				,@SP_Name as CallSP
			FOR JSON PATH,WITHOUT_ARRAY_WRAPPER); 
		Exec [PAL_Module].dbo.CMDSHELL2CLR 'CopyFile',@parametersJson,@iResult output ,@iMessage output --0025
		--Set @strSQL='bcp "Select Col1 from PAL_Module.dbo.PAL_PDCA_ModTrack_File_CR  Order by Col1 Desc" queryout '+@SF_DataSourcePath+ '\' +  --0022
	 --       @FlatFileName+' -c -t "," -T'
		-- EXEC master..xp_cmdshell @strSQL

		Delete From #PAL_PDCA_ModTrack_Model Where Model=@Model
		----------------------------------------------------------------------------------------
	End

	If @Flag='Y'
	Begin
	update  FAeDatetime  set EDateTime=@ToDateTime,rundatetime=@ToDateTime
	 Where Category='CRModTrack'
	End
-----------------0001 
	set @StepFlag='Try End'

End Try
Begin Catch
	Select @ErrMsg=N'Stored Precedure:['+@SP_Name+'] is executed exceptionally,'
		+N'ERROR_NUMBER:'+CAST(ERROR_NUMBER() as varchar(50)) 
		+N'ERROR_MESSAGE:'+ERROR_MESSAGE() 
	 
	set @StepFlag=@StepFlag+':' +'Error Happen'
	exec MonitorAgent_SaveErrorLog @SP_Name,@StepFlag,@StepFlag ,@StepFlag,@ErrMsg	 
End Catch
-----------------0001 

