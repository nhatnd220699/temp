USE [PAL_Module]
GO
/****** Object:  StoredProcedure [dbo].[usp_PAL_PDCA_CheckM44]    Script Date: 2026-03-27 4:52:18 CH ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

ALDDDTER PROCEDURE [dbo].[usp_PAL_PDCA_CheckM44]
As
-----------------------------------------------------------------------------------------------
-----Created by Shem Wen on 2010-12-08.
-----Purpose: Validate M42/M44 Correctness.
-----------------------------------------------------------------------------------------------
--########## Update Log Begin  ###################
--Date				UpdateOwner		Description
--2010/12/16 12:40  Shem Wen         防止在做选择条件时因找不到该字段的值而无法结束循环(-----0001)
--2010/12/30 10:06  Shem Wen		 因为PE提供的mapping list 中已知的'021-1676'的条件欠缺，故暂时取消其对应的alarm!(-----0002)
--2019/01/16 10:06  Freedom Gao		删除setnocountoff(-----0003)
--2020/07/16  09:09 Freedom            增加try catch  （0004）
--##########Update Log End # ###################
-----------------------------------------------------------------------------------------------
SET NOCOUNT ON;
-----------------------------------------------------------------------------------------------
----Import file
Declare @iSQL nvarchar(600)
Declare @iTXTFile nvarchar(100)
Declare @iFilePath nvarchar(100)
Declare @iFilePathb nvarchar(100)


-----0004 bgein
declare @ErrMsg Nvarchar(4000)=''
declare @StepFlag varchar(100)=''
declare @SP_Name varchar(100)=''

Begin Try
	set @SP_Name=isnull(OBJECT_NAME(@@PROCID),'' )
	set @StepFlag='Try Start'
-----0004 end

Declare @CurrentDateTime varchar(30),@Year varchar(19),@Month varchar(5),@Day varchar(5)
Set @CurrentDateTime = Replace(Replace(Replace(Convert(varchar(19),GetDate(),121),'-',''),':',''),' ','')
Set @Year = SUBSTRING (@CurrentDateTime,1,4)
Set @Month = SUBSTRING (@CurrentDateTime,5,2)
Set @Day = SUBSTRING (@CurrentDateTime,7,2)
--------------------------------------------------------------------------------------------
Create Table #TempAffectedRows(AffectedRow nvarchar(800))
Create Table #TempProcessInterim(iRows nvarchar(800))
--------------------------------------------------------------------------------------------

Set @iFilePathb ='D:\Test\'
Set @iFilePath='\\172.26.16.28\d$\PDCA\QSMCFTP\ValidatePDCA\'
Set @iSQL='"Dir \\172.26.16.28\d$\PDCA\QSMCFTP\ValidatePDCA\*M4* /b"'
Truncate Table #TempAffectedRows
Truncate Table PAL_M44_PDCA_FTPFeed
Insert Into #TempAffectedRows
	EXEC master..xp_cmdshell @iSQL
	--select * from #TempAffectedRows
Delete from #TempAffectedRows where  AffectedRow is null
select AffectedRow from #TempAffectedRows where AffectedRow like '%M4%'
If @@ROWCOUNT = 0
	Begin
		Return
	ENd
--------------------------------------------------------------------------------------------

Truncate Table #TempProcessInterim
Declare iWOCursor Cursor For
	Select Distinct AffectedRow from #TempAffectedRows Order by AffectedRow
Open iWOCursor
FETCH Next from iWOCursor Into @iTXTFile
WHILE @@FETCH_STATUS = 0
Begin
	Set @iSQL= 'Copy \\172.26.16.28\D$\PDCA\QSMCFTP\ValidatePDCA\'+@iTXTFile+'  D:\Test\'
		EXEC master..xp_cmdshell @iSQL
	Set @iSQL= 'Copy \\172.26.16.28\D$\PDCA\QSMCFTP\ValidatePDCA\'+@iTXTFile+'  \\172.26.16.28\d$\PDCA\QSMCFTP\ValidatePDCA\Backup\'+@Year+'\'+@Month+'\'+@Day+'\'
		EXEC master..xp_cmdshell @iSQL
		Declare @FT nvarchar(60)
		Declare @RT nvarchar(60)
		Set @FT=CHAR(9)
		Set @RT=CHAR(10)
		DECLARE @bulk_cmd varchar(1000)
	If @iTXTFile like '%M44%'
		Begin
			Truncate Table PAL_M44_PDCA_FTPFeedTrim
			  SET @bulk_cmd = 'BULK INSERT PAL_M44_PDCA_FTPFeedTrim FROM ''D:\Test\'+@iTXTFile+'''
			  WITH (
			  DATAFILETYPE = ''char'',
			  FIELDTERMINATOR = '''+@FT+''',
			  ROWTERMINATOR = '''+@RT+''',  
			  FIRSTROW = 2
			  )'
			 EXEC(@bulk_cmd)
			 -----0001
			 Update PAL_M44_PDCA_FTPFeedTrim
				 Set Apple_ThirdParty_SW ='' from PAL_M44_PDCA_FTPFeedTrim where Apple_ThirdParty_SW  is null

			 ---
			 Select @iTXTFile As PDCAFileName, IDENTITY(int,1,1) As RowID,* Into #Temp_M44  from PAL_M44_PDCA_FTPFeedTrim 
			 Insert into PAL_M44_PDCA_FTPFeed(PDCAFileName  ,RowID ,Vendor ,Plant ,Regi ,CID,MPN_CID_Description ,Project_Name,Apple_ThirdParty_SW,Char_Value)
				 Select PDCAFileName ,RowID ,Vendor ,Plant ,Regi ,CID,CID_Description ,Project_Name,Apple_ThirdParty_SW,Char_Value from #Temp_M44
			 Drop table #Temp_M44
		End
	Else
		Begin
			Truncate Table PAL_M42_PDCA_FTPFeedTrim
			  SET @bulk_cmd = 'BULK INSERT PAL_M42_PDCA_FTPFeedTrim FROM ''D:\Test\'+@iTXTFile+'''
			  WITH (
			  DATAFILETYPE = ''char'',
			  FIELDTERMINATOR = '''+@FT+''',
			  ROWTERMINATOR = '''+@RT+''',  
			  FIRSTROW = 2
			  )'
			 EXEC(@bulk_cmd)
			 Update PAL_M42_PDCA_FTPFeedTrim
				 Set Apple_ThirdParty_SW ='' from PAL_M42_PDCA_FTPFeedTrim where Apple_ThirdParty_SW  is null 
			 Select @iTXTFile As PDCAFileName, IDENTITY(int,1,1) As RowID,* Into #Temp_M42  from PAL_M42_PDCA_FTPFeedTrim 
			 Insert into PAL_M44_PDCA_FTPFeed(PDCAFileName  ,RowID ,Vendor ,Plant ,Regi ,CID,MPN_CID_Description,Project_Name,Apple_ThirdParty_SW,Char_Value)
				 Select PDCAFileName ,RowID ,Vendor ,Plant ,Regi ,MPN,MPN_Description ,Project_Number,Apple_ThirdParty_SW,Variant_Characteristics from #Temp_M42
			 Drop table #Temp_M42		
		End		
	Set @iSQL='"Del '+@iFilePath+@iTXTFile+'"'
		EXEC master..xp_cmdshell @iSQL
	--Set @iSQL='"Del '+@iFilePathb+@iTXTFile+'"'
	--	EXEC master..xp_cmdshell @iSQL
Delete from PAL_M44_PDCA_FTPFeed where Vendor like '%Trailer%'
    	Fetch Next from iWOCursor into @iTXTFile
End
CLOSE iWOCursor
DEALLOCATE iWOCursor
Truncate Table PAL_M44_VerifyResult


----process of checking---PAL_PN_2	PAL_PN_3	Update_Date
----065-0016	021-1514	201012031600
create table #Figure(F1 varchar(50))
create table #Figure2(F2 varchar(50))
create table #tempsum(F1 varchar(50),PAL_PN_2 varchar(50),PAL_PN_3 varchar(50),Update_Date varchar(50))
create table #tempsum2(F2 varchar(50),F1 varchar(50),PAL_PN_2 varchar(50),PAL_PN_3 varchar(50),Update_Date varchar(50))
create table #tempsum3(F2 varchar(50),F1 varchar(50),PAL_PN_2 varchar(50),PAL_PN_3 varchar(50),Update_Date varchar(50))
While exists(select top 1 * from PAL_M44_PDCA_FTPFeed)
	Begin
		Truncate table #Figure 
		Truncate table #Figure2 
		Truncate table #tempsum
		Truncate table #tempsum2
		Truncate table #tempsum3
		Declare @PDCAFileName varchar(100)
		Declare @RowID varchar(100)
		Select top 1 @PDCAFileName=PDCAFileName,@RowID=RowID from PAL_M44_PDCA_FTPFeed
		--print @PDCAFileName
		--print @RowID
		Declare @char_value varchar(500)
		Select @char_value= char_value from PAL_M44_PDCA_FTPFeed where PDCAFileName=@PDCAFileName and RowID=@RowID
		Declare @Apple_ThirdParty_SW varchar(300)
		Select @Apple_ThirdParty_SW=Apple_ThirdParty_SW from PAL_M44_PDCA_FTPFeed where PDCAFileName=@PDCAFileName and RowID=@RowID
		Declare @returnrows1 int
		Declare @returnrows2 int
		Declare @returnrows3 int
		Insert into #Figure
			Select *  from dbo.Func_SplitStr(@Char_Value,',')
		Insert into	#Figure2
			Select *  from dbo.Func_SplitStr2(@Apple_ThirdParty_SW,',')
		Insert into #tempsum	
			Select *  from #Figure A  inner join PAL_M44_MT_Mapping  B on A.F1 =B.PAL_PN_2 
			Set @returnrows1 = @@rowcount
		Insert into #tempsum2
			Select *  from #Figure2 A  inner join #tempsum  B on a.F2 =B.PAL_PN_3 
			Set @returnrows2 = @@rowcount
		Insert into #tempsum3	
			Select *  from #Figure2 A  left join #tempsum  B on a.F2 =B.PAL_PN_3 
			Set @returnrows3 = @@rowcount
		--select * from #tempsum
		--select * from #tempsum2
		--select * from #tempsum3
		---print @Tqty
		---print @Rqty
		If @returnrows1 = @returnrows2 and @returnrows2=@returnrows3 
			Begin
				Delete from PAL_M44_PDCA_FTPFeed 
				where PDCAFileName=@PDCAFileName and RowID=@RowID
			End
		Else
			Begin
				Insert into PAL_M44_VerifyResult
				Select * from PAL_M44_PDCA_FTPFeed 
				where PDCAFileName=@PDCAFileName and RowID=@RowID
				Delete from PAL_M44_PDCA_FTPFeed 
				where PDCAFileName=@PDCAFileName and RowID=@RowID
			End

	End
---Send alarm email
-----0002
Delete from PAL_M44_VerifyResult where Apple_ThirdParty_SW  like '%021-1676%'
---
select * into #PAL_M44_VerifyResult from PAL_M44_VerifyResult order by PDCAFileName,CAST(RowID as int) 
If exists(select top 10 * from  #PAL_M44_VerifyResult)
	Begin
        Declare @EmailContent nvarchar(max)
        Declare @SendContent varchar(max)
        Set @SendContent=''
	    Set @EmailContent='<font color=black size=4 face="Times New Roman">Dear All,<br>
		                   &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Here is the un-matched result of validating correctness of M44/M42 files, please pay attention to it.<br>
		                   &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;You may call Shem Wen (#41128) if you have any doubt
		                   </font>'           
	    Select @SendContent=@SendContent+'<tr align=center>'+
			'<td>'+PDCAFileName+'</td>'+
			'<td>'+RowID+'</td>'+
			--'<td>'+Vendor+'</td>'+
			--'<td>'+Plant+'</td>'+
			--'<td>'+Regi+'</td>'+
			--'<td>'+Material+'</td>'+
			--'<td>'+[Description]+'</td>'+
			'<td>'+CID+'</td>'+
			--'<td>'+MPN_CID_Description+'</td>'+
			--'<td>'+CCC_Code+'</td>'+
			'<td>'+Project_Name+'</td>'+
			--'<td>'+MPU+'</td>'+
			--'<td>'+Test_String+'</td>'+
			--'<td>'+Mac_OS+'</td>'+
			'<td>'+Apple_ThirdParty_SW+'</td>'+
			--'<td>'+Char_Value+'</td>'+
			'</tr>'
		from #PAL_M44_VerifyResult
-----------------------------------------------------------------
		Set @SendContent='<br>&nbsp;&nbsp;&nbsp;&nbsp;For more information,please refer to the form below:<br>'+
			'<Table style="table-layout: fixed; margin-left:25pt; position:relative;" border="2">'+
			'<tr bgcolor=#ffff11 align=center>'+   
			'<td>PDCAFileName</td>'+
			'<td>RowID</td>'+
			--'<td>Vendor</td>'+
			--'<td>Plant</td>'+
			--'<td>Regi</td>'+
			--'<td>Material</td>'+
			--'<td>Description</td>'+
			'<td>CID</td>'+
			--'<td>MPN_CID_Description</td>'+
			--'<td>CCC_Code</td>'+
			'<td>Project_Name</td>'+
			--'<td>MPU</td>'+
			--'<td>Test_String</td>'+
			--'<td>Mac_OS</td>'+
			'<td>Apple_ThirdParty_SW</td>'+
			--'<td>Char_Value</td>'+
			'</tr>'+@SendContent+'</Table>'+'<br>&nbsp;&nbsp;&nbsp;&nbsp;QMS<br>'
	    Set @EmailContent='<HTML><BODY><FONT Name=Arial Size=7pt Color=Blue>'+
		                  @EmailContent+
		                  @SendContent+
		                  '</FONT></BODY></HTML>'
		                  
        Declare @AllEmailAddressTo varchar(4000)=''
	    Declare @AllEmailAddressCC varchar(4000)=''
	    Declare @MailGroup varchar(50)
	    Declare @subject varchar(200)
	 	    set @MailGroup='PAL_M44_CHK'
	  	    set @subject='SFCS_NB6_Validate M42/M44 Correctness'
        select @AllEmailAddressTo=EmailAddress+';'+@AllEmailAddressTo
           from [172.26.6.6].SF_Maintain.dbo.QMSSC_Send_Email
           WHERE FuncType=@MailGroup AND SendFlag='Y' AND ActiveFlag='Y'
           order by userid desc
        select @AllEmailAddressCC=EmailAddress+';'+@AllEmailAddressCC 
           from [172.26.6.6].SF_Maintain.dbo.QMSSC_Send_Email
           WHERE FuncType=@MailGroup AND CCFlag='Y' AND ActiveFlag='Y'
           order by userid desc
		EXEC msdb.dbo.sp_send_dbmail 
			@profile_name = 'QMS',   
			@recipients=@AllEmailAddressTo,
			@copy_recipients=@AllEmailAddressCC,
			@blind_copy_recipients='',
			@subject = @subject,
			@body = @EmailContent,
			@body_format = 'html',
			@Importance = 'High',
			@file_attachments= ''
     End

Return
--------------------0003



-----0004 begin
     set @StepFlag='Try End'

End Try
Begin Catch

	Select @ErrMsg=N'Stored Precedure:['+@SP_Name+'] is executed exceptionally,'
		+N'ERROR_NUMBER:'+CAST(ERROR_NUMBER() as varchar(50)) 
		+N'ERROR_MESSAGE:'+ERROR_MESSAGE() 
	 
	set @StepFlag=@StepFlag+':' +'Error Happen'

	exec MonitorAgent_SaveErrorLog @SP_Name,@StepFlag ,'' ,@StepFlag,@ErrMsg
	
End Catch	
-----0004 end
		

