USE [PAL_COMPSN_P80]
GO
/****** Object:  StoredProcedure [dbo].[usp_PAL_PDCA_SubLine]    Script Date: 2026-03-28 9:23:52 SA ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,Hardy>
-- Create date: <Create Date,2015/03/02 14:36>
-- Description:	<Description,Get FATP SubLine段的资料并且回塞到40.9>
-- =============================================
ALdddTER PROCEDURE [dbo].[usp_PAL_PDCA_SubLine]
 		(@FromDateTime varchar(20)='',
		@ToDateTime varchar(20)='')
AS
--########## Update Log Begin  ###################
--Date					UpdateOwner		Description
---20150316            Hardy Chen      LCD Test 3 站的PASS数据取经过站别时间最早的那笔(0001)
---20150319            Hardy Chen      Update ErrCode Description(0002)
---20211103            Earl  Chen      SP报错，添加StepFlag以便查找原因 （0003）
---20211104            Freedom         去掉OPID的左右空格（0004）
--##########Update Log End # ###################
-----------------------------------------------------------------------------------------------
SET NOCOUNT ON;

declare @ErrMsg Nvarchar(4000)=''
declare @StepFlag varchar(100)=''
declare @SP_Name varchar(100)='usp_PAL_PDCA_SubLine'

Begin Try
	Set @SP_Name=IsNULL(OBJECT_NAME(@@PROCID),'')
	set @StepFlag='Try Start'
	----(0011)
	Truncate Table PAL_MODULE_LCDRATE
	
	set @StepFlag='InsertData_1'  --0003
	Insert into PAL_MODULE_LCDRATE(Line, Serial_Number, Work_Order, Part_Num, ErrCode, Trans_Date, Trans_Time, Station, Product_Type, Num, Type, Description, InputDateTime, Repaired, ERRDESC, Rework_Fix, Comment, Cust_PN)
	Select a.line,a.Comp_SN,c.QCI_WO,C.QCI_PN_1,A.ErrCode,substring(A.TransDateTime,1,8) Trans_Date,
		substring(A.TransDateTime,9,2)+':'+substring(A.TransDateTime,11,2)+':'+substring(A.TransDateTime,13,2) Trans_Time,
		'LCD Cosmetic 2',RTrim(LTrim(A.OPID)), A.Num, 'Fail' as Type, ----0004
		c.Model, A.TransDateTime , 'N'as 'RepairFlag' ,'' as 'ERRDESC',
		'' as rework_fix,'' as comment ,c. Cust_PN_1  
	from PAL_Data_Return_CR a with(nolock) inner join [10.36.6.86].PAL_Module.dbo.PAL_SN c with(nolock) on a.comp_sn=c.QCI_SN
	where Serial_Number like '20%' and len(Serial_Number)=14 
		and a.TransDateTime Between @FromDatetime and @ToDateTime
	
	set @StepFlag='InsertData_2'  --0003
	Insert into PAL_MODULE_LCDRATE(Line, Serial_Number, Work_Order, Part_Num, ErrCode, Trans_Date, Trans_Time, Station, Product_Type, Num, Type, Description, InputDateTime, Repaired, ERRDESC, Rework_Fix, Comment, Cust_PN)
	Select a.line,a.Comp_SN,c.QCI_WO,C.QCI_PN_1,A.ErrCode,substring(A.TransDateTime,1,8) Trans_Date,
		substring(A.TransDateTime,9,2)+':'+substring(A.TransDateTime,11,2)+':'+substring(A.TransDateTime,13,2) Trans_Time,
		'LCD Cosmetic 2',RTrim(LTrim(A.OPID)), A.Num, 'Fail' as Type, -----0004
		c.Model, A.TransDateTime , 'N' as 'RepairFlag' ,'' as 'ERRDESC',
		'' as rework_fix,'' as comment ,c. Cust_PN_1  
	from PAL_Data_Return_CR_bk a with(nolock) inner join [10.36.6.86].PAL_Module.dbo.PAL_SN c with(nolock) on a.comp_sn=c.QCI_SN
	where a.Serial_Number like '20%'  and len(a.Serial_Number)=14  
		and a.TransDateTime Between @FromDatetime and @ToDateTime
	----
	---------------------------------------------------------------------------------------------------------------------0005 0008 LCD3
	-------0001
	set @StepFlag='InsertData_3'  --0003
	Insert into PAL_MODULE_LCDRATE(Line, Serial_Number, Work_Order, Part_Num, ErrCode, Trans_Date, Trans_Time, Station, Product_Type, Num, Type, Description, InputDateTime, Repaired, ERRDESC, Rework_Fix, Comment, Cust_PN)
	Select a.line,b.Comp_SN,c.QCI_WO,C.QCI_PN_1,A.ErrorCode,substring(A.TransDateTime,1,8) Trans_Date,
		substring(A.TransDateTime,9,2)+':'+substring(A.TransDateTime,11,2)+':'+substring(A.TransDateTime,13,2) Trans_Time,
		case  when  a.Station in('LCDC','LCDF','LCDT') then 'LCD Test 3' end as Station,A.OPID, A.Num, '' as Type, 
		A.Cust_Model, A.TransDateTime , A.RepairFlag ,'' ERRDESC,
		'' as rework_fix,'' as comment ,c. Cust_PN_1  
		from  PAL_Module_PQC a WITH(NOLOCK),
		PAL_Module_CompSN b with(nolock),[10.36.6.86].PAL_Module.dbo.PAL_SN C WITH(NOLOCK)
		  WHERE a.Station in('LCDC','LCDF','LCDT')
		  and a.Module_SN = B.Module_SN and b.Comp_name='CR' and b.Comp_SN=c.QCI_SN and A.ErrorCode<>'PASS'
		    And A.TransDateTime Between @FromDatetime and @ToDateTime
		    
	Select b.Comp_SN,MIN(A.TransDatetime) AS TransDatetime INTO #TempPDCA_Interim
		from  PAL_Module_PQC a WITH(NOLOCK),
		PAL_Module_CompSN b with(nolock)
		  WHERE a.Station in('LCDC','LCDF','LCDT')
		  and a.Module_SN = B.Module_SN and b.Comp_name='CR' and A.ErrorCode='PASS'
		     And A.TransDateTime Between @FromDatetime and @ToDateTime
		       GROUP BY Comp_SN
	
	set @StepFlag='InsertTempPDCA'  --0003
	Select a.line,b.Comp_SN,c.QCI_WO,C.QCI_PN_1,A.ErrorCode,substring(A.TransDateTime,1,8) Trans_Date,
		substring(A.TransDateTime,9,2)+':'+substring(A.TransDateTime,11,2)+':'+substring(A.TransDateTime,13,2) Trans_Time,
		case  when  a.Station in('LCDC','LCDF','LCDT') then 'LCD Test 3' end as Station,A.OPID, A.Num, '' as Type, 
		A.Cust_Model, A.TransDateTime , A.RepairFlag ,'' ERRDESC,
		'' as rework_fix,'' as comment ,c. Cust_PN_1  INTO #TempPDCA
		from  PAL_Module_PQC a WITH(NOLOCK),
		PAL_Module_CompSN b with(nolock),[10.36.6.86].PAL_Module.dbo.PAL_SN C WITH(NOLOCK)
		  WHERE a.Station in('LCDC','LCDF','LCDT')
		  and a.Module_SN = B.Module_SN and b.Comp_name='CR' and b.Comp_SN=c.QCI_SN and A.ErrorCode='PASS'
		  And A.TransDateTime Between @FromDatetime and @ToDateTime
	
	Insert into PAL_MODULE_LCDRATE(Line, Serial_Number, Work_Order, Part_Num, ErrCode, Trans_Date, Trans_Time, Station, Product_Type, Num, Type, Description, InputDateTime, Repaired, ERRDESC, Rework_Fix, Comment, Cust_PN)
	SELECT A.* FROM #TempPDCA A,#TempPDCA_Interim B WHERE 
	    A.Comp_SN=B.Comp_SN AND A.TRANSDATETIME=B.TRANSDATETIME
	-------0001
	--Insert into PAL_MODULE_LCDRATE
	--Select a.line,b.Comp_SN,c.QCI_WO,C.QCI_PN_1,A.ErrorCode,substring(A.TransDateTime,1,8) Trans_Date,
	--	substring(A.TransDateTime,9,2)+':'+substring(A.TransDateTime,11,2)+':'+substring(A.TransDateTime,13,2) Trans_Time,
	--	case  when  a.Station in('LCDC','LCDF','LCDT') then 'LCD Test 3' end as Station,A.OPID, A.Num, '' as Type, 
	--	A.Cust_Model, A.TransDateTime , A.RepairFlag ,'' ERRDESC,
	--	'' as rework_fix,'' as comment ,c. Cust_PN_1  
	--	from  PAL_Module_PQC a WITH(NOLOCK),
	--	PAL_Module_CompSN b,[10.36.6.86].PAL_Module.dbo.PAL_SN C WITH(NOLOCK)
	--	  WHERE a.Station in('LCDC','LCDF','LCDT')
	--	  and a.Module_SN = B.Module_SN and b.Comp_name='CR' and b.Comp_SN=c.QCI_SN 
	--	    And A.TransDateTime Between @FromDatetime and @ToDateTime
	set @StepFlag='InsertData_4'  --0003	    
	Insert into PAL_MODULE_LCDRATE(Line, Serial_Number, Work_Order, Part_Num, ErrCode, Trans_Date, Trans_Time, Station, Product_Type, Num, Type, Description, InputDateTime, Repaired, ERRDESC, Rework_Fix, Comment, Cust_PN)
	Select a.line,a.Module_SN,c.QCI_WO,C.QCI_PN_1,A.ErrorCode,substring(A.TransDateTime,1,8) Trans_Date,
		substring(A.TransDateTime,9,2)+':'+substring(A.TransDateTime,11,2)+':'+substring(A.TransDateTime,13,2) Trans_Time,
		 'LCD Test 3'  as Station,A.OPID, A.Num, '' as Type, 
		A.Cust_Model, A.TransDateTime , A.RepairFlag ,'' ERRDESC,
		'' as rework_fix,'' as comment ,c. Cust_PN_1  
		from  PAL_Module_PQC a WITH(NOLOCK),[10.36.6.86].PAL_Module.dbo.PAL_SN C WITH(NOLOCK)
		  WHERE a.Station IN('CRFUN','CRFUNIN') 
		  and a.Module_SN = c.QCI_SN  
		    And A.TransDateTime Between @FromDatetime and @ToDateTime
	---------------------------------------------------------------------------------------------------------------------0005 0008 LCD3  
	
	---------------------------------------------------------------------------------------------------------------------0005 0008 0012 TPT 
	--insert into PAL_MODULE_LCDRATE
	--Select line,Module_SN,'' as Work_Order,'' as QCI_PN,ErrorCode,substring(TransDateTime,1,8) Trans_Date,
	--	substring(TransDateTime,9,2)+':'+substring(TransDateTime,11,2)+':'+substring(TransDateTime,13,2) Trans_Time,
	--	case  when Station IN('TPT','TOPT') then 'Top-Assembly' end as Station,OPID, Num, 'Fail' as Type, 
	--	Cust_Model, TransDateTime , RepairFlag ,'' ERRDESC,
	--	'' as rework_fix,'' as comment ,'' as Cust_PN  
	--	from  [10.36.6.66].PAL_COMPSN_P80.dbo.PAL_Module_PQC WITH(NOLOCK) 
	--	  where Station IN('TPT','TOPT')  and  TransDateTime Between @FromDatetime and @ToDateTime
	set @StepFlag='InsertData_5'  --0003
	insert into PAL_MODULE_LCDRATE(Line, Serial_Number, Work_Order, Part_Num, ErrCode, Trans_Date, Trans_Time, Station, Product_Type, Num, Type, Description, InputDateTime, Repaired, ERRDESC, Rework_Fix, Comment, Cust_PN)
	Select line,Module_SN,'' as Work_Order,'' as QCI_PN,ErrorCode,substring(TransDateTime,1,8) Trans_Date,
	substring(TransDateTime,9,2)+':'+substring(TransDateTime,11,2)+':'+substring(TransDateTime,13,2) Trans_Time,
	    'Top-Assembly' as Station,OPID, Num, 'Fail' as Type, 
	    Cust_Model, TransDateTime , RepairFlag ,'' ERRDESC,
	    '' as rework_fix,'' as comment ,'' as Cust_PN  
	    from  PAL_Module_PQC  WITH(NOLOCK)
	      where Station in ('TOPT','TPT', 'TOPF' ) and  TransDateTime Between @FromDatetime and @ToDateTime
	
	set @StepFlag='InsertData_6'  --0003
	insert into PAL_MODULE_LCDRATE(Line, Serial_Number, Work_Order, Part_Num, ErrCode, Trans_Date, Trans_Time, Station, Product_Type, Num, Type, Description, InputDateTime, Repaired, ERRDESC, Rework_Fix, Comment, Cust_PN)
	Select line,Module_SN,'' as Work_Order,'' as QCI_PN,ErrorCode,substring(TransDateTime,1,8) Trans_Date,
	substring(TransDateTime,9,2)+':'+substring(TransDateTime,11,2)+':'+substring(TransDateTime,13,2) Trans_Time,
	    'KEY-MODULE4' as Station,OPID, Num, 'Fail' as Type, 
	    Cust_Model, TransDateTime , RepairFlag ,'' ERRDESC,
	    '' as rework_fix,'' as comment ,'' as Cust_PN  
	    from  PAL_Module_PQC  WITH(NOLOCK)
	      where Station in ('BCCOS') and  TransDateTime Between @FromDatetime and @ToDateTime

		  select top 100 * from PAL_Module_PQC with(nolock)
	      
	set @StepFlag='UpdateData'  --0003
	Update A   ----0005
		Set A.cust_pn =b.Cust_PN  from PAL_MODULE_LCDRATE A,CompSN B with(nolock)
		Where A.Serial_Number=B.Comp_SN
		and A.Cust_PN=''
	
	If exists(Select Top 1 * from PAL_MODULE_LCDRATE with(nolock) where Cust_PN ='')
	Begin
	    Update A  ----------0005
			Set A.cust_pn =b.Cust_PN  from PAL_MODULE_LCDRATE A With(nolock),PALDBBK.dbo.CompSN B with(nolock)
			Where A.Serial_Number=B.Comp_SN 
			and A.Cust_PN=''
		
		Update A  ----------0005
			Set A.cust_pn =b.Cust_PN  from PAL_MODULE_LCDRATE A With(nolock),PAL_Module_CompSN B with(nolock)
			Where A.Serial_Number=B.Comp_SN 
			and A.Cust_PN=''
	End 
	---0002
	update A
		Set A.ERRDESC =B.Description  from PAL_MODULE_LCDRATE A With(nolock),Error_Code B With(nolock)
			Where A.ErrCode=B.ErrCode
	Update A
	Set A.Rework_Fix =B.Description  from PAL_MODULE_LCDRATE A With(nolock),Error_Code B
		Where A.Rework_Fix=B.ErrCode
	-----------------------------------------------------------------------------------------
	--IF EXISTS(SELECT TOP 1 * FROM PAL_MODULE_LCDRATE WITH(NOLOCK) WHERE LEN(line)=2 )---Automatically update lines whose length is 2
	--	BEGIN
	--		UPDATE ppmtq
	--			SET line=t.Input_Line FROM PAL_MODULE_LCDRATE e ppmtq ,PAL_SN t WITH(nolock) 
	--				WHERE LEFT(ppmtq.Serial_Number,13)=t.QCI_SN AND LEN(ppmtq.Line)=2
	--	END
	-----------------------------------------------------------------------------------------

	set @StepFlag='Try End'

End Try
Begin Catch

	Select @ErrMsg=N'Stored Precedure:['+@SP_Name+'] is executed exceptionally,'
		+N'ERROR_NUMBER:'+CAST(ERROR_NUMBER() as varchar(50)) 
		+N'ERROR_MESSAGE:'+ERROR_MESSAGE() 
	 
	exec MonitorAgent_SaveErrorLog @SP_Name,'','',@StepFlag,@ErrMsg
	 
End Catch




 

 
