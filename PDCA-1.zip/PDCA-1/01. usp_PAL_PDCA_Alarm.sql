USE [PAL_Module]
GO
/****** Object:  StoredProcedure [dbo].[usp_PAL_PDCA_Alarm]    Script Date: 2026-03-26 8:25:51 SA ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO






--<*Program* or *Description* or *Programer* or *Date*>
-----------------------------------------------------------------------------------------------
--########## Update Log Begin  ###################
--2016/05/17        Lisa Han         加上TRY catch的逻辑(0001) 
--2019/01/16        Freedom Gao        删除setnocountoff(0002) 
--2020/8/17			Jack Guo		 由20调整到30(G0001)
--2021/7/27         Jack Guo		 延迟一下，避免数据重复(G0002)
--2022/12/7			Jack Guo		 送的资料增多了(线材使用次数)，由30调整到50(G0003)
--2023/5/10			Jack Guo		 增加LCD-Attr与MaterialSN路径下的报警G0004
--2023/5/30         Tacey            更改提示路径172.26.16.29为172.26.16.28(0005) 
--2025/02/11		Neil     	     调整CMDShell为CLR 方式 0006
-----------------------------------------------------------------------------------------------

ALDDDTER PROCEDURE [dbo].[usp_PAL_PDCA_Alarm] 

AS

----------------------------------------------------------------------------------------------
Set nocount on

DECLARE @TO		nvarchar(max)
DECLARE @CC		nvarchar(max)
DECLARE @BCC	nvarchar(max)

-----------------0001 
declare @ErrMsg Nvarchar(4000)=''
declare @StepFlag varchar(100)=''
declare @SP_Name varchar(100)=''

Begin Try

Declare @Count int=0 --0006
	Declare @iResult Varchar(200)='' , @iMessage Nvarchar(max)='' , @parametersJson NVARCHAR(MAX)=''  --0006
	set @SP_Name=isnull(OBJECT_NAME(@@PROCID),'' )
	set @StepFlag='Try Start'
-----------------0001

	SELECT @TO='',@CC='',@BCC=''

	Select @TO = @TO + mail_account+';'
	   from mail_user where system_name='PDCA_AlarmRpt'
	Select @CC = @CC +mail_account+';'
	   from mail_user where system_name='PDCA_AlarmRpt'


	--SELECT @TO='Lisa.Han@quan  tacn.com;Seven.Gao@quan  tacn.com;Meng.Zhang@quan  tacn.com;Eric.Ni@quan  tacn.com;Sundai.Sun@quan  tacn.com'
	--SELECT @CC='Denver.Yang@quan    tacn.com'
	---------------------------------------------------------------------------

	DECLARE @FileList TABLE(fileName NVARCHAR(100),ItemValue nvarchar(100),DT varchar(30))  --0006

	SET @parametersJson =  (SELECT 'E:\PALFA\Share\PDCA\WWSFS\Import\MANUAL-LCDRate' as path FOR JSON PATH,WITHOUT_ARRAY_WRAPPER)
	INSERT INTO @FileList(fileName,ItemValue,DT)
	Exec PAL_Module.dbo.CMDSHELL2CLR 'GetFilesJson',@parametersJson,@iResult output ,@iMessage output 

	SET @parametersJson =  (SELECT 'E:\PALFA\Share\PDCA\WWSFS\Import\MOD-TRACK' as path FOR JSON PATH,WITHOUT_ARRAY_WRAPPER)
	INSERT INTO @FileList(fileName,ItemValue,DT)
	Exec PAL_Module.dbo.CMDSHELL2CLR 'GetFilesJson',@parametersJson,@iResult output ,@iMessage output 

	SET @parametersJson =  (SELECT 'E:\PALFA\Share\PDCA\WWSFS\Import\MANUAL-LCDATTR' as path FOR JSON PATH,WITHOUT_ARRAY_WRAPPER)
	INSERT INTO @FileList(fileName,ItemValue,DT)
	Exec PAL_Module.dbo.CMDSHELL2CLR 'GetFilesJson',@parametersJson,@iResult output ,@iMessage output 

	SET @parametersJson =  (SELECT 'E:\PALFA\Share\PDCA\WWSFS\Import\MANUAL-MaterialSN' as path FOR JSON PATH,WITHOUT_ARRAY_WRAPPER)
	INSERT INTO @FileList(fileName,ItemValue,DT)
	Exec PAL_Module.dbo.CMDSHELL2CLR 'GetFilesJson',@parametersJson,@iResult output ,@iMessage output 


			--DECLARE @FileList TABLE(fileName VARCHAR(100))
			--Declare @CMD NVARCHAR(1000)
			--Declare @Count int
			--SET @CMD='DIR E:\PALFA\Share\PDCA\WWSFS\Import\MANUAL-LCDRate'	 
			--INSERT INTO @FileList(fileName)
			--EXEC XP_CMDSHELL @CMD --,no_output 
		
			--SET @CMD='DIR E:\PALFA\Share\PDCA\WWSFS\Import\MOD-TRACK'
			--INSERT INTO @FileList(fileName)
			--EXEC XP_CMDSHELL @CMD --,no_output
			
			----G0004
			--SET @CMD='DIR E:\PALFA\Share\PDCA\WWSFS\Import\MANUAL-LCDATTR'
			--INSERT INTO @FileList(fileName)
			--EXEC XP_CMDSHELL @CMD --,no_output

			----G0004
			--SET @CMD='DIR E:\PALFA\Share\PDCA\WWSFS\Import\MANUAL-MaterialSN'
			--INSERT INTO @FileList(fileName)
			--EXEC XP_CMDSHELL @CMD --,no_output

			SELECT @Count=count(*) from @FileList where FileName like '%txt%'
	--'Jay.Gao@quan   tacn.com;Jie.Bai@quan    tacn.com;Before.Liu@quan    tacn.com'
	--'Hardy.Chen@quan   tacn.com;Bailey.Cao@quan   tacn.com;Carson.Xu@quan   tacn.com;Ball.Wang@quan   tacn.com'
	SET @BCC=''
	Set @CC=''
	Declare @Subj varchar(100)
			DECLARE @Today		varchar(19)
			Declare @qty int=0
			Declare @sum int=0
			DECLARE @MailBody	nvarchar(max)
			SET @Today=CONVERT(varchar(19),GetDate(),121)
			set @Subj='Urgent:PAL_Module---Not send files of PDCA is too large,please check it!The Count is '+Cast(@Count AS VARCHAR(10))
			SET @MailBody=N'<HTML><BODY><FONT name=Arial color=blue size=2pt>'+
			'Dear All,'+'<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'+'Quanta FTP server(172.26.16.28) can’t link Apple’s server(17.80.230.36) to submit PDCA data !'+
			'<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'+'You may enter 172.26.16.28 to check FTP Voyager job status,maybe some of them stop working.'+
			'<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'+'(Check if a lot of files blocked at E:\PALFA\Share\PDCA\WWSFS\Import\MANUAL-LCDRate'+
			'<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'+'Or at \\172.26.16.28\d$\PDCA\WWSFS\Import\MANUAL-LCDRate'+
			'<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'+'Or at \\172.26.16.28\d$\PDCA\WWSFS\Import\MOD-TRACK)'+
			'<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'+'Please start those 3 FTP Voyager jobs on [172.26.16.28](kill the FVScheduler process and restart it if necessary).'+
			'<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'+'Also need network team from Quanta and Apple to check the FTP server(17.80.230.36) status if there are too many files blocked.'+
			'<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'+'It means system back to normal if there is no such alarm email.'+
			'<br>'+
			'<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'+'Contact window at Quanta side:'+
			'<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'+'Day shift (08:00~20:00, China Time): Meng Zhang, Rainey Yan;'+
			'<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'+'Night shift (20:00~08:00, China Time): Horace Tang, Rainman Ren.'+
			'</FONT></BODY></HTML>'+@Today
	----------------------------------------------------------------------------------
	  --      DECLARE @FileList TABLE(fileName VARCHAR(100))
	  --      Declare @CMD NVARCHAR(1000)
	  --      Declare @Count int
			--SET @CMD='DIR E:\PALFA\Share\PDCA\WWSFS\Import\MANUAL-LCDRate'	 
			--INSERT INTO @FileList(fileName)
			--EXEC XP_CMDSHELL @CMD --,no_output 
		
			--SET @CMD='DIR E:\PALFA\Share\PDCA\WWSFS\Import\MOD-TRACK'
			--INSERT INTO @FileList(fileName)
			--EXEC XP_CMDSHELL @CMD --,no_output	 
			--SELECT @Count=count(*) from @FileList where FileName like '%txt%'
			--Print @Count
			--If @Count>500
    
		 If @Count>50 ----(G0001)(G0003)
		  Begin
			 DECLARE @mailitem_id int
			 DECLARE @id int

			-------------------------------------
			Declare @SendTime int=5
			While @SendTime>0
			Begin
			EXEC msdb.dbo.sp_send_dbmail
					  @profile_name ='QMS',
					  @recipients=@TO,
					  @copy_recipients=@CC,
					  @blind_copy_recipients=@BCC,
					  @subject=@Subj,
					  @body=@MailBody,
					  @body_format='HTML',  --TEXT ;HTML
					  @importance='High',  --Low;Normal;High
					  @sensitivity='Normal',  --Normal;Personal;Private;Confidential;
					  @file_attachments='',
					  @query='',
					  @execute_query_database='',
					  @attach_query_result_as_file='0', 
					  @query_attachment_filename='', 
					  @query_result_header='', 
					  @query_result_width='4096', 
					  @query_result_separator='|',
					  @exclude_query_output='1', 
					  @append_query_error='', 
					  @query_no_truncate='',
					  @mailitem_id=@id OUTPUT;
		    
				SET @SendTime=@SendTime-1
				waitfor delay '00:00:05'  --G0002
			 End
		  End
-----------------0001 
	set @StepFlag='Try End'

End Try
Begin Catch
	Select @ErrMsg=N'Stored Precedure:['+@SP_Name+'] is executed exceptionally,'
		+N'ERROR_NUMBER:'+CAST(ERROR_NUMBER() as varchar(50)) 
		+N'ERROR_MESSAGE:'+ERROR_MESSAGE() 
	 
	set @StepFlag=@StepFlag+':' +'Error Happen'
	exec MonitorAgent_SaveErrorLog @SP_Name,'','PDCA Alarm' ,@StepFlag,@ErrMsg	 
End Catch
-----------------0001 
-----------------0002
 
 --set @Filename=REPLACE(@Filename,'tmp','txt') 
 




