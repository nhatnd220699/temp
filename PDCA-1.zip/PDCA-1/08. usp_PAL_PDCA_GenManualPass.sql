USE [PAL_Module]
GO
/****** Object:  StoredProcedure [dbo].[usp_PAL_PDCA_GenManualPass]    Script Date: 2026-03-27 4:53:33 CH ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO



ALDDDTER Procedure [dbo].[usp_PAL_PDCA_GenManualPass]
	(
		@FromDateTime varchar(20)='',
		@ToDateTime varchar(20)=''
	)
As
SET NOCOUNT ON;
--declare @FromDateTime varchar(20)='',
--			@ToDateTime varchar(20)=''

------EXEC usp_PAL_PDCA_GenManualPass
----------------------------------------------------------------------------------------
-----Created by Dennis Ding on 2008/01/30.
-----Purpose: Generate flat file of Manual Pass for PDCA feed.
-----频率：15分钟送一次.
-----每次产生上一个15分钟时段内的资料.
-----之前的写法是PAL P/N是Z开头或是/A结尾的才写入P/N，否则P/N部分为空，可现在有/B结尾的PAL P/N.
-----目前的做法是不做判断.
-----20190711	OuYang	参照iMac SP:usp_PAL_PDCA_GenManualPass 创建J290送PDCA数据的SP:usp_PAL_PDCA_GenManualPass,仅用作J290Module_PQC数据送Insight  ---0001
-----20200312   OuYang   应客户要求送J290 Insight信息 Line 格式 F5-2F-J35  ---0002
-----20210520   Freedom  RTrim(A.Serial_Number)+RTrim(c.PAL_P_N) As [CID] 中去掉开头S和PAL_P_N --0003
-----20260320	Neil	CMDShell更改为CLR   0004
----------------------------------------------------------------------------------------
-----1. 获取时间段.
--Declare @FlatFileName varchar(20)--20
declare @ErrMsg Nvarchar(4000)=''
declare @StepFlag varchar(100)=''
declare @SP_Name varchar(100)='usp_PAL_PDCA_GenManualPass'
Declare @iResult Varchar(200)='' , @iMessage Nvarchar(max)='' , @parametersJson NVARCHAR(MAX)='',  @pathJson Nvarchar(max)=''
Begin Try      
	set @SP_Name=isnull(OBJECT_NAME(@@PROCID),'' )
	set @StepFlag='Try Start'
	Declare @FlatFileName varchar(60)=''


	If Len(@FromDateTime)!=14 or Len(@ToDateTime)!=14
	Begin
		Declare @CurrentHour varchar(10)
		Declare @iCurrentMinute int
		Set @CurrentHour=Replace(Replace(Convert(varchar(13),DateAdd(minute,-15,GetDate()),121),'-',''),' ','')
		Set @iCurrentMinute=Convert(int,Substring(Convert(varchar(16),DateAdd(minute,-15,GetDate()),121),15,2))
		If @iCurrentMinute>=0 and @iCurrentMinute<15
		Begin
			Set @FromDateTime=@CurrentHour+'0000'
			Set @ToDateTime=@CurrentHour+'1459'
		End
		If @iCurrentMinute>=15 and @iCurrentMinute<30
		Begin
			Set @FromDateTime=@CurrentHour+'1500'
			Set @ToDateTime=@CurrentHour+'2959'
		End
		If @iCurrentMinute>=30 and @iCurrentMinute<45
		Begin
			Set @FromDateTime=@CurrentHour+'3000'
			Set @ToDateTime=@CurrentHour+'4459'
		End
		If @iCurrentMinute>=45 and @iCurrentMinute<60
		Begin
			Set @FromDateTime=@CurrentHour+'4500'
			Set @ToDateTime=@CurrentHour+'5959'
		End
		-----Added by Dennis on 2015/02/17 14:30.
		-----上面的写法可以Mark掉.
		-----这里减去一个不规则秒数，目的是让Portable/iMAC产生的文件不重名(相互覆盖).
		----Select @ToDateTime =dbo.FormatDate(DateAdd(Second,-57,GetDate()),'YYYYMMDDHHNNSS')
	End
	-----------------------------------------------------------
	---Added by Tim Cui On 2009/10/21保证传送的连续性
	Declare @StartDateTime varchar(20)
	Declare @EndDateTime varchar(20)
	--Declare @FromDateTime varchar(20)
	
	Set @StartDateTime=''
	Set @EndDateTime=''
	-----------------------------------------------------------
	--Select * from FAeDatetime where category='PDCAManualPass'
	Select @StartDateTime=EdateTime  from FAeDatetime where category='PDCAManualPass'
	set @EndDateTime=Replace(Replace(Convert(varchar(20),GETDATE(),121),'-',''),' ','')
	PRINT @FromDateTime
	print @StartDateTime
	Print @EndDateTime
	----select datediff(mi,dbo.Convert2Date(@StartDateTime),dbo.Convert2Date(@FromDateTime))
	------------------------------------------------------------- 
	if datediff(mi,dbo.Convert2Date(@StartDateTime),dbo.Convert2Date(@FromDateTime))>15
	Begin
	   Set @FromDateTime=@StartDateTime
	End
	---------------------------------------------

	----------------------------------------------------------------------------------------
	-----2. 收集COS PASS资料.
	-----Select Top 100 * from PQC
	Truncate Table PAL_PDCA_ManualPass
	---select top 100 * from PAL_PDCA_ManualPass
	Insert Into PAL_PDCA_ManualPass(CID, Trans_Date, Trans_Time, Stage, line, QCI_Model)
		Select Distinct 
		--RTrim(a.Serial_Number)+RTrim(b.PAL_P_N) As CID,----0003
	    CASE WHEN SUBSTRING(a.Serial_Number,1,1)='S' THEN  right(a.Serial_Number,len(a.Serial_Number)-1)
	    ELSE RTrim(a.Serial_Number) END As CID,			
			Trans_Date=Substring(a.TransDateTime,1,8),
			Trans_Time=Substring(a.TransDateTime,9,2)+':'+
				Substring(a.TransDateTime,11,2)+':'+
				Substring(a.TransDateTime,13,2),
			Stage=a.Station,
			a.line,a.Description  
			from PQC a with(nolock),PAL b with(nolock)
			where a.TransDateTime between @FromDateTime and @ToDateTime
			and a.Station in (select ShopFloor_Format from PAL_PDCA_StageMapping)
			and A.ErrCode='PASS'
			and a.Part_Num=b.QCI_P_N
			and a.Description in ('J290','A132','A290')

	Update A
	Set A.stage = B.PDCA_Format from PAL_PDCA_ManualPass A,PAL_PDCA_StageMapping B
		Where A.Stage =B.ShopFloor_Format 
	Delete A from PAL_PDCA_ManualPass A
		Where Stage not in (Select PDCA_Format  from PAL_PDCA_StageMapping) 
			and Stage not in (select BobcatStation from BobCat_RoutingControl B with(nolock) where A.[QCI_Model]=B.Model)	

	--------------------------------------------------------------------------------
	Declare @CurrentDateTime varchar(19)
	Set @CurrentDateTime=Replace(Replace(Replace(Convert(varchar(19),GetDate(),121),'-',''),':',''),' ','')
	Print @CurrentDateTime
	Declare @iYear varchar(6)
	Declare @iMonth varchar(6)
	Declare @iDay varchar(6)
	Declare @FileBKPath varchar(300)
	Declare @strSQL nvarchar(600)
	Declare @FileLocalPath varchar(300) 
	Declare @Model varchar(20)=''
	Declare @RemoteFileBKPath varchar(300)
	Declare @RemoteFileLocalPath varchar(300)

	Set @iYear=Substring(@CurrentDateTime,1,4)
	Set @iMonth=Substring(@CurrentDateTime,5,2)
	Set @iDay=Substring(@CurrentDateTime,7,2)
	----------------------------------------------------------------------------------------------
		SET @parametersJson =  (SELECT 'E:\Data\PDCA\WWSFS\Import\MANUAL-PASS_BK\'+@iYear as path FOR JSON PATH,WITHOUT_ARRAY_WRAPPER)
	Exec PAL_Module.dbo.CMDSHELL2CLR 'CreateDirectory',@parametersJson,@iResult output ,@iMessage output   --0004
	--Set @strSQL='"MD E:\Data\PDCA\WWSFS\Import\MANUAL-PASS_BK\'+@iYear+'"'
	--EXEC master..xp_cmdshell @strSQL

	SET @parametersJson =  (SELECT 'E:\Data\PDCA\WWSFS\Import\MANUAL-PASS_BK\'+@iYear+'\'+@iMonth as path FOR JSON PATH,WITHOUT_ARRAY_WRAPPER)
	Exec PAL_Module.dbo.CMDSHELL2CLR 'CreateDirectory',@parametersJson,@iResult output ,@iMessage output   --0004
	--Set @strSQL='"MD E:\Data\PDCA\WWSFS\Import\MANUAL-PASS_BK\'+@iYear+'\'+@iMonth+'"'
	--EXEC master..xp_cmdshell @strSQL

	SET @parametersJson =  (SELECT 'E:\Data\PDCA\WWSFS\Import\MANUAL-PASS_BK\'+@iYear+'\'+@iMonth+'\'+@iDay as path FOR JSON PATH,WITHOUT_ARRAY_WRAPPER)
	Exec PAL_Module.dbo.CMDSHELL2CLR 'CreateDirectory',@parametersJson,@iResult output ,@iMessage output   --0004
	--Set @strSQL='"MD E:\Data\PDCA\WWSFS\Import\MANUAL-PASS_BK\'+@iYear+'\'+@iMonth+'\'+@iDay+'"'
	--EXEC master..xp_cmdshell @strSQL

	SET @parametersJson =  (SELECT 'E:\Data\PDCA\WWSFS\Import\MANUAL-PASS' as path FOR JSON PATH,WITHOUT_ARRAY_WRAPPER)
	Exec PAL_Module.dbo.CMDSHELL2CLR 'CreateDirectory',@parametersJson,@iResult output ,@iMessage output   --0004
	--Set @strSQL='"MD E:\Data\PDCA\WWSFS\Import\MANUAL-PASS"'
	--EXEC master..xp_cmdshell @strSQL

	Set @FileBKPath='E:\Data\PDCA\WWSFS\Import\MANUAL-PASS_BK\'+@iYear+'\'+@iMonth+'\'+@iDay+'\'
	Set @FileLocalPath='E:\Data\PDCA\WWSFS\Import\MANUAL-PASS\'


	---------------------------------------------------------------------------------------
	Select Distinct QCI_Model Into #PAL_PDCA_ManualPass_Model From PAL_PDCA_ManualPass With(nolock) Where QCI_Model<>'' 
	update PAL_PDCA_ManualPass set Line='F5-2F-J35' Where QCI_Model ='J290'	----0002
	
	While Exists(Select * from #PAL_PDCA_ManualPass_Model)  ---------0054
	Begin	
			Select Top 1 @Model=QCI_Model from #PAL_PDCA_ManualPass_Model
			Truncate Table PAL_PDCA_ManualPass_File
			----select @Model
			-----(0007)
			Insert into PAL_PDCA_ManualPass_File(Col1)
				Select upper(CID)+char(9)+Trans_Date+char(9)+Trans_Time+char(9)+Stage+char(9)+Line As Col1
				from PAL_PDCA_ManualPass where QCI_Model=@Model
	-----(0007)
	----- 添加结束符#END.

			Insert Into PAL_PDCA_ManualPass_File(Col1) Values ('#END')

			----select * from PAL_PDCA_ManualPass_File
			----------------------------------------------------------------------------------------
			----- 产生文档.
			-----Select Top 100 * from PAL_PDCA_ManualPass

			Set @FlatFileName='QSMC_MPASS_YLD_'+@Model+'_'+@ToDateTime+'.txt'
			SET @pathJson = ( 
				Select Col1 from PAL_Module.dbo.PAL_PDCA_ManualPass_File Order by Col1 Desc
				FOR JSON PATH);  

			SET @parametersJson = ( 
				SELECT 
					@FileBKPath+@FlatFileName as path
					,@pathJson as jsonString 
					,'N' as header
			--		,'\t' as split 
					,@SP_Name as CallSP
				FOR JSON PATH,WITHOUT_ARRAY_WRAPPER); 
			Exec [PAL_Module].dbo.CMDSHELL2CLR 'CreateFile',@parametersJson ,@iResult output ,@iMessage output  --0004

			--Set @strSQL='bcp "Select Col1 from PAL_Module.dbo.PAL_PDCA_ManualPass_File Order by Col1 Desc" queryout '+@FileBKPath+
			--	@FlatFileName+
			--	' -c -S"10.36.6.86" -U"sa" -P"East#86_qmh2024"'
			--EXEC master..xp_cmdshell @strSQL
			----------------------------------------------------------------------------------------------
			WAITFOR   DELAY   '00:00:00.200' 

			SET @parametersJson = ( 
			SELECT 
				@FileBKPath as Sourcepath 
				,@FileLocalPath as Destpath 
				,@FlatFileName as filename
				,@FlatFileName as newfilename
				,@SP_Name as CallSP
			FOR JSON PATH,WITHOUT_ARRAY_WRAPPER); 
			Exec [PAL_Module].dbo.CMDSHELL2CLR 'CopyFile',@parametersJson,@iResult output ,@iMessage output   --0004
			--Set @strSQL='"Copy '+@FileBKPath+@FlatFileName+' '+@FileLocalPath+'"' 
			--EXEC master..xp_cmdshell @strSQL

			----WAITFOR   DELAY   '00:00:00.200' 
			------exec master..xp_cmdshell 'net use \\10.36.6.66\e$ ayD*aoT@w6 /user:fp-qsmc\administrator'
			----Set @strSQL='"Copy '+@FileBKPath+@FlatFileName+' '+@RemoteFileBKPath+'"' 
			----EXEC master..xp_cmdshell @strSQL

			----WAITFOR   DELAY   '00:00:00.200' 

			----Set @strSQL='"Copy '+@FileBKPath+@FlatFileName+' '+@RemoteFileLocalPath+'"' 
			----EXEC master..xp_cmdshell @strSQL
			
			----------------------------------------------------------------------------------------
			--每产生一个txt就将该txt塞进PAL_PDCA_Compare
			Insert Into PAL_PDCA_Compare(FileName, Type, CreateTime, FeedBKTime, Flag)
			Select @FlatFileName,'ModuleManualPass',@ToDateTime,'','N'
			-----------------------------------------------------------------------------------------
			Delete From #PAL_PDCA_ManualPass_Model Where QCI_Model =@Model
	End
	---------------------------------

	update  FAeDatetime  set EDateTime=@ToDateTime,rundatetime=@ToDateTime
	 where Category='PDCAManualPass'
	----------------------------------------------------------------------------------------
	---6. 发送邮件通知相关人员.
	Declare @AllEmailToAddress varchar(3000)
	Declare @AllEmailCcAddress varchar(3000)
	Set @AllEmailToAddress=''
	Set @AllEmailCcAddress=''



	Print @AllEmailToAddress

	Declare @EmailTitle nvarchar(600)=''
	Set @EmailTitle='Manual PASS complete, file name: '+@FlatFileName+' (new method)'

	Declare @IPAddress varchar(30)=''
	Set @IPAddress=Convert(varchar(20),ConnectionProperty('Local_Net_Address'))
	Declare @EmailContent nvarchar(4000)=''
	
	----------------------------------------------------------------------------------------
	Declare @iSQL varchar(800)
	Declare @iRow int
	Create Table #TempAffectedRows(AffectedRow nvarchar(800))
	Create Table #TempUnUpload(Folder nvarchar(70) ,     --0029
								FileName nvarchar(800)  ,
								DateTime varchar(20) )

	----------------------------------------------------------------------------------------
	-----(0011) -- Start
	-----本地检查一个目录.
	Set @iSQL='"Dir E:\Data\PDCA\WWSFS\Import\MANUAL-PASS\*.txt /b"'
	Insert Into #TempAffectedRows
		EXEC master..xp_cmdshell @iSQL
	insert into #TempUnUpload(Folder,FileName,DateTime)      --0029
		select 'E:\Data\PDCA\WWSFS\Import\MANUAL-PASS',AffectedRow,REVERSE(substring(REVERSE(AffectedRow),5,14)) from #TempAffectedRows   
	delete from #TempAffectedRows   
	-----因最近[172.26.16.28]上FTP软件经常出问题，导致FTP Job无故停止执行.
	-----所以增加检查[172.26.16.28]中的目录.
	Set @iSQL='"Dir \\172.26.16.29\d$\PDCA\WWSFS\Import\MANUAL-FAIL\*.txt /b"'
	Insert Into #TempAffectedRows
		EXEC master..xp_cmdshell @iSQL
	insert into #TempUnUpload(Folder,FileName,DateTime)
		select '\\172.26.16.29\d$\PDCA\WWSFS\Import\MANUAL-FAIL',AffectedRow,REVERSE(substring(REVERSE(AffectedRow),5,14)) from #TempAffectedRows
	delete from #TempAffectedRows 

	Set @iSQL='"Dir \\172.26.16.29\d$\PDCA\WWSFS\Import\MANUAL-PASS\*.txt /b"'
	Insert Into #TempAffectedRows
		EXEC master..xp_cmdshell @iSQL
	insert into #TempUnUpload(Folder,FileName,DateTime)
		select '\\172.26.16.29\d$\PDCA\WWSFS\Import\MANUAL-PASS',AffectedRow,REVERSE(substring(REVERSE(AffectedRow),5,14)) from #TempAffectedRows
	delete from #TempAffectedRows 

	--Set @iSQL='"Dir \\172.26.16.29\d$\PDCA\WWSFS\Import\MOD-TRACK\*.txt /b"'
	--Insert Into #TempAffectedRows
	--	EXEC master..xp_cmdshell @iSQL
	--insert into #TempUnUpload(Folder,FileName,DateTime)
	--	select '\\172.26.16.29\d$\PDCA\WWSFS\Import\MOD-TRACK',AffectedRow,REVERSE(substring(REVERSE(AffectedRow),5,14)) from #TempAffectedRows
	--delete from #TempAffectedRows 

	-----Added by Dennis on 2015/2/4.
	--Set @iSQL='"Dir \\172.26.16.29\d$\PDCA\WWSFS\Import\MOD-RFBRMA\*.txt /b"'
	--Insert Into #TempAffectedRows
	--	EXEC master..xp_cmdshell @iSQL
	--insert into #TempUnUpload(Folder,FileName,DateTime)
	--	select '\\172.26.16.29\d$\PDCA\WWSFS\Import\MOD-RFBRMA',AffectedRow,REVERSE(substring(REVERSE(AffectedRow),5,14)) from #TempAffectedRows
	----drop table #TempAffectedRows 
	---------(0011) -- End
	--------------------------------------------------------------------------------------------	
	Delete from #TempAffectedRows where AffectedRow not like '%.txt' or AffectedRow is null -----or AffectedRow='File Not Found'--0029
	Delete from #TempUnUpload where FileName not like '%.txt' or FileName is null
	--------------------------------------------------------------------------------------------
	Declare @Bef10Time varchar(20)
	set @Bef10Time=dbo.FormatDate(DATEADD(N,-15,getdate()),'YYYYMMDDHHNNSS')
	
	DECLARE @Table		nvarchar(max)=''
	DECLARE @i			int
	DECLARE @folder    	nvarchar(70)
	DECLARE @Num    	varchar(3)
	--Select @iRow=count(*) from #TempAffectedRows 
	--If @iRow>8
	If exists(select folder,count(FileName) from #TempUnUpload where DateTime<@Bef10Time group by Folder having count(FileName)>10)
	Begin
		select ROW_NUMBER() OVER (ORDER BY folder) AS Seq,folder,count(FileName) as Num into #Data from #TempUnUpload where DateTime<@Bef10Time group by Folder having count(FileName)>10
        SELECT @iRow=Count(*) FROM #Data
		SET @i=1
		WHILE @i<=@iRow
		BEGIN
			SELECT @folder=folder,@Num=Num	FROM #Data WHERE Seq=@i
			SET @Table=@Table+'FolderName:'+@folder+' Number:'+@Num+'  '
			SET @i=@i+1
		END
		-----Dennis changed "some" to CONVERT(varchar(6),@iRow) on 2013-04-25 10:17.
		Set @EmailTitle='FTP Voyager Run Fail,Some files are blocked at Quanta side -- [172.26.40.15]'
		Set @EmailContent='<HTML><BODY><FONT name=Arial color=blue size=2pt>'+
			'Dear All,'+'<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'+'Quanta FTP server(172.26.16.29) can’t link Apple’s server(17.80.230.36) to submit PDCA data !'+
			'<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'+'You may enter 172.26.16.29 to check FTP Voyager job status,maybe some of them stop working.'+
			'<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'+'<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'+'(Check The Follow Folder:'+
			'<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'+@Table+')'+
			'<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'+'<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'+
			'<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'+'Please start those FTP Voyager jobs on [172.26.16.29](kill the FVScheduler process and restart it if necessary).'+
			'<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'+'Also need network team from Quanta and Apple to check the FTP server(17.80.230.36) status if there are too many files blocked.'+
			'<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'+'It means system back to normal if there is no such alarm email.'+
			'<br>'+
			'<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'+'Contact window at Quanta side:'+
			'<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'+'Day shift (08:00~20:00, China Time): Meng Zhang, Ray Yao;'+
			'<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'+'Night shift (20:00~08:00, China Time): Hunter Wang, Rainman Ren.'+
			'</FONT></BODY></HTML>'

		exec [QMSSendMail] @System_Name='FTP_RunFail',@Sender='Qms_Notice',@Title=@EmailTitle,@Body=@EmailContent,@Attachment1='',@Attachment2='',@Attachment3='',@Importance=2,@HtmlText=1  --0030

	End
			--------------------------------------------------------------
	set @StepFlag='Try End'

End Try
Begin Catch     
	Select @ErrMsg=N'Stored Precedure:['+@SP_Name+'] is executed exceptionally,'
		+N'ERROR_NUMBER:'+CAST(ERROR_NUMBER() as varchar(50)) 
		+N'ERROR_MESSAGE:'+ERROR_MESSAGE() 
	 
	set @StepFlag=@StepFlag+':' +'Error Happen'
	exec MonitorAgent_SaveErrorLog @SP_Name,'','Convey out' ,@StepFlag,@ErrMsg	 
End Catch

