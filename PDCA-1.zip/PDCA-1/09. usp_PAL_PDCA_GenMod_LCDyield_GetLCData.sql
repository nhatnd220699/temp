USE [PAL_Module]
GO
/****** Object:  StoredProcedure [dbo].[usp_PAL_PDCA_GenMod_LCDyield_GetLCData]    Script Date: 2026-03-27 4:53:56 CH ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALDDTER Procedure [dbo].[usp_PAL_PDCA_GenMod_LCDyield_GetLCData]
		(@FromDateTime varchar(20)='',
		@ToDateTime varchar(20)='')
As
-----------------------------
Set NoCount ON
----------------------------
------------------------------------------------------------------------------
-----Created by Hardy Chen on 2015-04-02.
-----Purpose: Generate Module related PDCA LCDyield data.
----------------------------------------------------------------------------------------------
--########## Update Log Begin  ###################
--Date                 UpdateOwner        Description
--2015/04/02 08:02	   Hardy			  应客户要求,LCD段的数据也要送至PDCA   (0001)
--2016/02/24 08:29     Meng               对于某些已经定义的model但是在LCD PQC的某些站别却未显示出来，故现在做一次update，保证送PDCA的时候数据有model（0002）
--2016/02/25 19:48     Meng               有部分数据在16.160上面，从Archive DB上面获取数据（0003）
--2016/03/02 16:18     Meng               由于客人要LCD测试的线别,但是目前没办法得到,故采取以下措施（0004）
--2016/06/13 20:00     Meng               有LCD的SN补送数据,只需要将LCD的相关数据塞到Report.dbo.___Meng1,然后解开0005_1和0005_2的注释，跑完后再注释掉（0005）
--2016/06/14        Lisa Han              加上TRY catch的逻辑(0006) 
--##########Update Log End # ###################
----exec [usp_PAL_PDCA_LCDyield]
----------------------------------------------------------------------------------------------
---------（0004）  Start

-----------------0006
declare @ErrMsg Nvarchar(4000)=''
declare @StepFlag varchar(100)=''
declare @SP_Name varchar(100)=''

Begin Try
	set @SP_Name=isnull(OBJECT_NAME(@@PROCID),'' )
	set @StepFlag='Try Start'
-----------------0006 

	Select DISTINCT Comp_SN ,Line  into #Temp_Compqc FROM Compsn WITH(NOLOCK) 
	WHERE  TransDateTime Between @FromDatetime and @ToDatetime    
	and Comp_Name ='LCD'

	------------------------------------------------------------------------------------------------------------------------
	-----0005_1 Begin
	/**
	insert into #Temp_Compqc
	SELECT b.Comp_SN ,b.Line  FROM Report.dbo.___Meng1 a with(nolock) join compsn b  WITH(NOLOCK) 
	on a.col1 =b.Comp_SN 

	insert into #Temp_Compqc
	SELECT b.Comp_SN ,b.Line  FROM Report.dbo.___Meng1 a with(nolock) join CompSN_BK_REP  b  WITH(NOLOCK) 
	on a.col1 =b.Comp_SN 

	insert into #Temp_Compqc
	SELECT b.Comp_SN ,b.Line  FROM Report.dbo.___Meng1 a with(nolock) join PALModuleBK.dbo.compsn b  WITH(NOLOCK) 
	on a.col1 =b.Comp_SN 

	--Select A.* Into #NULL from Report.dbo.___Meng1 a  with(nolock) left join #Temp_Compqc b 
	--on a.col1 =b.Comp_SN
	--where B.Comp_SN IS NULL

	--insert into #Temp_Compqc
	--SELECT b.Comp_SN ,b.Line  FROM #NULL a with(nolock) join [172.26.16.160].[PAL_Module_Archive].dbo.[COMPSN] b  WITH(NOLOCK) 
	--on a.col1 =b.Comp_SN 

	--insert into #Temp_Compqc
	--SELECT b.Comp_SN ,b.Line  FROM #NULL a with(nolock) join [172.26.16.160].[PAL_Module].dbo.[COMPSN] b  WITH(NOLOCK) 
	--on a.col1 =b.Comp_SN 

	DELETE FROM  Report.dbo.___Meng1
	------0005_1 End    **/
	------------------------------------------------------------------------------------------------------------------------
	Select distinct B.*,A.Line  into #TempCompqc from #Temp_Compqc a WITH(NOLOCK) join PAL_Comp_PQC b WITH(NOLOCK) 
	on a.Comp_SN =b.Serial_Number 
	WHERE STATION IN('CellT','CellT2','CellIN')
	Insert #TempCompqc
	Select distinct B.*,A.Line  from #Temp_Compqc a WITH(NOLOCK) join PALModuleBK.dbo.PAL_Comp_PQC b WITH(NOLOCK) 
	on a.Comp_SN =b.Serial_Number 
	WHERE STATION IN('CellT','CellT2','CellIN')
	------------------------------------------------------------------------------------------------------------
	------0005_2 Begin
	/*
	Insert #TempCompqc
	Select distinct B.*,A.Line from #Temp_Compqc a WITH(NOLOCK) join [172.26.16.160].PAL_Module.dbo.PAL_Comp_PQC b WITH(NOLOCK) 
	on a.Comp_SN =b.Serial_Number 
	WHERE STATION IN('CellT','CellT2','CellIN')
	Insert #TempCompqc
	Select distinct B.*,A.Line  from #Temp_Compqc a WITH(NOLOCK) join [172.26.16.160].PAL_Module_Archive.dbo.PAL_Comp_PQC b WITH(NOLOCK) 
	on a.Comp_SN =b.Serial_Number 
	WHERE STATION IN('CellT','CellT2','CellIN')
	------0005_2 End		--*/
	---------------------------------------------------------------------------------------------------------------
	--SELECT DISTINCT * into #TempCompqc FROM PAL_COMP_PQC WITH(NOLOCK) WHERE STATION IN('CellT','CellT2','CellIN')
	--   and TransDateTime Between @FromDatetime and @ToDatetime   
	---------（0004）  END 
	---------（0002）  Start
	Declare @Serial_Number varchar(100)='',
			@Station varchar(100)='',
			@Model varchar(100)=''
	Select * into #TempCompqc_1 from #TempCompqc Where Description=''
	While exists(Select 1 from #TempCompqc_1 Where Description ='')
	Begin
		Select Top 1 @Serial_Number=Serial_Number,@Station=Station from #TempCompqc_1
		Select @Model=Model from PAL_Comp_Match_Model Where EEECode=Left(Right(@Serial_Number,6),4)
		Update #TempCompqc
		Set Description =@Model
		Where Description ='' 
		And Serial_Number=@Serial_Number
		And Station=@Station
		Delete from #TempCompqc_1
		Where Serial_Number=@Serial_Number
		And Station=@Station
	End
	---------（0002）  End
	----------------------------------------------------------------------------------------------
	----------------（0003）Start
	--Exec [172.26.16.160].[PAL_Module_Archive].dbo.[usp_ResentPDCAFile]
	--Insert Into #TempCompqc
	--Select * from [172.26.16.160].[PAL_Module_Archive].dbo.[___PAL_COMP_PQC]
	--Insert into PAL_MODULE_LCDRATE
	--Select * from [172.26.16.160].[PAL_Module_Archive].dbo.[___PAL_MODULE_LCDRATE]  
	----------------（0003）End
	----------------------------------------------------------------------------------------------
	--INSERT INTO #TempCompqc
	--SELECT a.Serial_Number,a.Station,a.Status as ErrCode,a.TransDatetime,'' as OPID,'' AS Defective_Code,b.Model 
	-- from PAL_SaveFixtureTestLog a with(nolock),PAL_Comp_Match_Model B WHERE 
	--   A.TransDatetime BETWEEN @FromDatetime and @ToDatetime AND Station='LED Shelf ASSY' AND SUBSTRING (A.Serial_Number,12,4)=B.EEECode AND Comp_Name='LCD'
	--SELECT  * FROM OPTION_TAG  WHERE OPTION_NAME='LCD' AND SUBSTRING(OPTION_BARCODE,12,4)='F444'
	SELECT A.SERIAL_NUMBER,MAX(B.OPTION_DESC_5) AS OPTION_CODE INTO #OptionCode FROM  #TempCompqc A,OPTION_TAG B WHERE 
		SUBSTRING(SERIAL_NUMBER,12,4) =SUBSTRING(B.OPTION_BARCODE,12,4) 
		and Len(Option_Barcode)=len(Serial_Number) AND B.OPTION_NAME='LCD'
		AND OPTION_TAG_AREA NOT IN('LCDChK','LCDChK1','LCD Label')
		GROUP BY SERIAL_NUMBER

	Select A.*,B.OPTION_CODE ,C.Option_PALPN INTO #SummarData FROM #TempCompqc A with(nolock), 
		#OptionCode B,TDDOptio C WITH(NOLOCK) WHERE B.OPTION_CODE=C.OPTION_CODE
		AND A.Serial_Number=B.Serial_Number
	--Insert into PAL_MODULE_LCDRATE
	--Select distinct '' as Line, A.Serial_Number, '' as Work_Order, A.OPTION_CODE, A.ErrCode, 
	--		substring(A.TransDateTime,1,8) Trans_Date
	--		,substring(A.TransDateTime,9,2)+':'+substring(A.TransDateTime,11,2)+':'+substring(A.TransDateTime,13,2) Trans_Time, 
	--		C.PDCA_Format AS Station,
	--		A.OPID, '' AS Num, A.Defective_Code, A.Description, A.TransDateTime, '' As Repaired,'' As ERRDESC,
	--		'' as rework_fix,'' as comment ,Option_PALPN
	--		From #SummarData A with(nolock)  ,PAL_PDCA_StageMapping C WITH(NOLOCK)   --0019
	--		where   A.Station=C.ShopFloor_Format ORDER BY TransDateTime DESC  
	---------（0004）  Start     
	Insert into PAL_MODULE_LCDRATE
	Select distinct A.Line , A.Serial_Number, '' as Work_Order, A.OPTION_CODE, A.ErrCode, 
			substring(A.TransDateTime,1,8) Trans_Date
			,substring(A.TransDateTime,9,2)+':'+substring(A.TransDateTime,11,2)+':'+substring(A.TransDateTime,13,2) Trans_Time, 
			C.PDCA_Format AS Station,
			A.OPID, '' AS Num, A.Defective_Code, A.Description, A.TransDateTime, '' As Repaired,'' As ERRDESC,
			'' as rework_fix,'' as comment ,Option_PALPN
			From #SummarData A with(nolock)  ,PAL_PDCA_StageMapping C WITH(NOLOCK)   --0019
			where   A.Station=C.ShopFloor_Format ORDER BY TransDateTime DESC       
	---------（0004）  END
-----------------0006 
	set @StepFlag='Try End'

End Try
Begin Catch
	Select @ErrMsg=N'Stored Precedure:['+@SP_Name+'] is executed exceptionally,'
		+N'ERROR_NUMBER:'+CAST(ERROR_NUMBER() as varchar(50)) 
		+N'ERROR_MESSAGE:'+ERROR_MESSAGE() 
	 
	set @StepFlag=@StepFlag+':' +'Error Happen'
	exec MonitorAgent_SaveErrorLog @SP_Name,'','Convey out' ,@StepFlag,@ErrMsg	 
End Catch
-----------------0006
