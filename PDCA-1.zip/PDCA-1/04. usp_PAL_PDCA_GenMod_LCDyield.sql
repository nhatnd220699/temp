USE [PAL_Module]
GO
/****** Object:  StoredProcedure [dbo].[usp_PAL_PDCA_GenMod_LCDyield]    Script Date: 2026-03-26 4:52:14 CH ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO




ALddddddTER Procedure [dbo].[usp_PAL_PDCA_GenMod_LCDyield]
		(@FromDateTime varchar(20)='',
		@ToDateTime varchar(20)='')
As
-----------------------------
Set NoCount ON
----------------------------
------------------------------------------------------------------------------
-----Created by Shem Wen on 2011-11-04.
-----Purpose: Generate Module related PDCA LCDyield data.
----------------------------------------------------------------------------------------------
--########## Update Log Begin  ###################
--Date                 UpdateOwner        Description
--2013/01/21 10:19	   Dennis			  ??????????Update??    (0001)
--2013/01/23 16:13	   Shem				  Implement quarantine system in case of those data inculde invalid PDCA line were sent to PDCA (0002)
--2013/06/21 10:19	   Bailey			  ADD J43,J41 (0003)
--2014/03/24 15:22	   Hardy			  ADD Station:PATT,AgingIN,AgingOUT,VSWRT (0004)
--2014/03/27 11:35	   Hardy			  ADD Station:LCDC,FQACOS,TPT,TOPT (0005)
--2014/11/17 11:22	   Hardy			  ADD J44,J45 (0006)
--2014/11/20 08:29	   Hardy			  以后PDCA资料不By机种送，默认所有机种都送 (0007)
--2015/01/27 14:25	   Hardy			  0005新增的站别的以后PDCA资料不By机种送，默认所有机种都送 (0008)
--2015/02/17 12:20	   Dennis			  改为使用PAL_Routing_Line中的PDCA_Line (0009)
--2015/02/17 14:00	   Dennis			  修改@ToDateTime取法，文件名不再以0000结尾，便于手动执行Job时可以连续产生不重名的文件 (0010)
--2015/02/25 11:11	   Ball				  add LCD Cosmetic 2 (0011)
--2015/02/28 10:18	   Hardy			  TOPT、TPT、TPTF这三站以前的代码写法有问题，现优化成如下 (0012)
--2015/02/28 11:18	   Ball				  add table PAL_MODULE_LCDRATE_resend (0013)
--2015/03/02 12:11	   Hardy			  还原Link40.6的捡料表来更新客户料号 (0014)
--2015/03/03 08:46	   Hardy			  Get FATP SubLine段的资料并且回塞到40.9 (0015)
--2015/03/09 14:24     Hardy              add below new station SFS send PDCA data:ChinAF,ClampOut,Pre-Cos,PR655,Cooling,ClampIn(0016)
--2015/03/13 08:05     Hardy              以下站别：FQC_3,FQC_4,不送PASS的数据(0017)
--2015/03/19 14:01     Hardy              以下站别：Cooling站的数据无需送PDCA(0018)
--2015/03/19 14:19     Hardy              事先在表中维护要送PDCA的站别(0019)
--2015/04/13 14:01	   Hardy			  应客户要求,LCD段的数据也要送至PDCA   (0020)
--2015/05.29 09:56     Hardy              add station:FQC_41 (0021)
--2015/07/13 16:28     Hardy              Fail数据送PDCA时间部分取的是报废表，但此时PQC表可能已经备份，需要Link历史DB（0022）
--2016/01/29 12:12     Meng               如果有Model(Decription)栏位为空的情况，为了不排在#END后面，排序条件做调整（0023）
--2016/02/19 14:49     Meng               如果有Model(Decription)栏位为空的情况，为了不排在#END后面，排序条件做调整（0024）,0023的调整不正确，现修改为0024
--2016/03/15 13:49     Meng               将Top-Assembly, Pre-Cos and PR655三个站别的分开来送（0025）
--2016/04/26 17:18     Meng               Add point "FA-CHECK-IN","FA-CHECK-OUT"（0026）
--2016/05/11 16:00     Meng               只有对应的几站才写入Check In和Check Out（0027）
--2016/05/11 16:00     Meng               报废的材料不需要送PDCA，所以有的材料会有Check In但是没有Check Out，客人认可这一点（0028）
--2016/05/17           Lisa               加上TRY catch的逻辑(0029) 
--2016/05/18           Meng               当文件为空时不送文件到PDCA(0030) 
--2016/05/25           Meng               送到PDCA的不管几次CheckIN都送过去，并且CheckOUT的时间使用维修的时间(0031) 
--2016/06/11           Meng               这3个机种'J130','J79','J80'送的数据是从PQC里面取(0032) 
--2016/07/07           Meng               更换送数据的逻辑(0033) 
--2016/08/17 20:43     Meng               应客户要求J80G使用J80作为Model,KeyBoard改成SA(0034) 
--2017/05/01 15:00	   Meng				  更新QCI_Model   （0035）
--2017/12/18 15:00	  WalkerTong		  all projects use  ‘SA’ for  Description  not only J80 and  j79  （0036）
--2019/05/06 10:00	  Tacey		          修改发邮件的逻辑  （0037）
--2019/06/20 10:00	  Tacey		          修改Bobcat机种(包括J290)送FA-CHECK-IN/OUT  （0038）
--2021/05/20 13:14    Freedom             送之前确保去掉S （0039）
--2022/05/26 11:20    Tacey               应King要求，送PQC站DHAP400，follow FA-CHECK-IN  （0040）
--2022/06/08 08:55    Tacey               应客人,PE要求,原REP送的不良，改为及时送，即PQC时间  （0041）
--2022/07/13		  Tacey				  将txt塞进PAL_PDCA_Compare，该功能客人已通知取消,取消塞入此表(0042）
---2024/04/15		OuYang				  add QMH PPCODE (J4F/J4G/J4H)   (0043)
--2025/05/12		  Neill				  Flow QSMC : 应Xiaowen:PQC Pass资料取消Num=1的限制，全部都送(0044）
--2025/06/17		  Neill				  应Xiaowen:PQC_Repair时间栏位由ErrTransDateTime修改为送TransDateTime(0045）
--2026/03/20	      Neil			      CMDShell更改为CLR   0046
--##########Update Log End # ###################
----exec [usp_PAL_PDCA_LCDyield]
----------------------------------------------------------------------------------------------
Declare @FlatFileName varchar(50)=''

-----------------0029 
Declare @ErrMsg Nvarchar(4000)=''
Declare @StepFlag varchar(100)=''
Declare @SP_Name varchar(100)=''
Declare @Model varchar(20)=''
Declare @strSQL nvarchar(600)=''
Declare @CurrentDateTime varchar(19)=Replace(Replace(Replace(Convert(varchar(19),GetDate(),121),'-',''),':',''),' ','')
Declare @iResult Varchar(200)='' , @iMessage Nvarchar(max)='' , @parametersJson NVARCHAR(MAX)='',  @pathJson Nvarchar(max)=''
Begin Try
	set @SP_Name=isnull(OBJECT_NAME(@@PROCID),'' )
	set @StepFlag='Try Start'
-----------------0029
 
	If Len(@FromDateTime)!=14 or Len(@ToDateTime)!=14
	Begin
		select @FromDateTime =dbo.FormatDate(DATEADD(HOUR,-1,GetDate()),'YYYYMMDDHH')+'0000'
		-----(0010)
		-----Dennis add DateAdd on 2015/02/17 13:55.
		-----Purpose: 避免同时间点数据还未塞进来，从而造成少量Data Missing.
		-----Select @ToDateTime =dbo.FormatDate(GetDate(),'YYYYMMDDHH')+'0000'
		Select @ToDateTime =dbo.FormatDate(DateAdd(Minute,-1,GetDate()),'YYYYMMDDHHNNSS')
	End
	-----------------------------------------------------------
	---????????
	Declare @StartDateTime varchar(20)
	Set @StartDateTime=''
	-----------------------------------------------------------
	----Select top 1000 * from FAeDatetime
	Select @StartDateTime=EDatetime  from FAeDatetime where category='PDCALCDyield'
	print @StartDateTime
	------------------------------------------------------------- 
	----if datediff(mi,dbo.Convert2Date(@StartDateTime),dbo.Convert2Date(@FromDateTime))>15
	----Begin
	----   Set @FromDateTime=@StartDateTime
	----End
	---------------------------------------------
	Set @FromDateTime=@StartDateTime
	----------------------------------------------------------------------------------------
	--Set @FlatFileName=Substring(@ToDateTime,1,8)+'_'+Substring(@ToDateTime,9,6)+'.txt'
	----------------------------------------------------------------------------------------
	-----Select Top 100 * from PQC
	Truncate Table PAL_MODULE_LCDRATE

	select  top 5000 * from PAL_MODULE_LCDRATE with(nolock) where Serial_Number

	select top 1000 * from CompSN with(nolock) where comp_sn like 'J4F%'

	----(0013)
	insert into PAL_MODULE_LCDRATE(Line, Serial_Number, Work_Order, Part_Num, ErrCode, Trans_Date, Trans_Time, Station, Product_Type, Num, Type, Description, InputDateTime, Repaired, ERRDESC, Rework_Fix, Comment, Cust_PN)
	select Line, Serial_Number, Work_Order, Part_Num, ErrCode, Trans_Date, Trans_Time, Station, Product_Type, Num, Type, Description, 
		InputDateTime, Repaired, ERRDESC, Rework_Fix, Comment, Cust_PN
	from PAL_MODULE_LCDRATE_resend where flag='N'
	update PAL_MODULE_LCDRATE_resend set flag='Y' where flag='N'
	----
	-----*******Collect Pass section
	Insert into PAL_MODULE_LCDRATE(Line, Serial_Number, Work_Order, Part_Num, ErrCode, Trans_Date, Trans_Time, Station, Product_Type, Num, Type, Description, InputDateTime, Repaired, ERRDESC, Rework_Fix, Comment, Cust_PN)
		Select distinct A.Line, A.Serial_Number, A.Work_Order, A.Part_Num, A.ErrCode, substring(A.TransDateTime,1,8) Trans_Date
			,substring(A.TransDateTime,9,2)+':'+substring(A.TransDateTime,11,2)+':'+substring(A.TransDateTime,13,2) Trans_Time, C.PDCA_Format AS Station,
			A.OPID, A.Num, A.Defective_Code, A.Description, A.InputDateTime, A.Repaired,'' ERRDESC,
			'' as rework_fix,'' as comment ,'' Cust_PN  
			From PQC A with(nolock) ,PAL B with(nolock) ,PAL_PDCA_StageMapping C WITH(NOLOCK)   --0019
			where --- Serial_Number  like 'C02%'  -- 0043
		    Exists(select 1 from PAL_SN_PlantCode P with(nolock)  WHERE P.SNLenType='18Digit' AND P.Type='CR' and a.Serial_Number like P.PlantCode+'%') 
			And A.Part_Num = B.QCI_P_N and ErrCode ='Pass'  ----0044 取消  and A.Num ='1'
			--And A.Station in ('FQC_3','FQC_4','Cosmetic','CameraT','OQC','Machine','PATT','AgingIN','AgingOut',
			--	'VSWRT','ChinAF','ClampOut','Pre-Cos','PR655','ClampIn','FQC_41') 
			AND A.Station=C.ShopFloor_Format          
			--and [Description] in('J41','J43','J11','J13','K21','K78','D2','J44','J45') ---('K21','K78','K16','K99')  ---0007
			And A.TransDateTime Between @FromDatetime and @ToDatetime 


			select top 5000 * from PAL_MODULE_LCDRATE with(nolock)
	----------------------------------------------------------------------------------------
	----0038 抓取bobcat机种
	 select distinct Model into #bobcatModel
	        from BobCat_RoutingControl with(nolock)

	----0026_2 Begin 
	Insert into PAL_MODULE_LCDRATE(Line, Serial_Number, Work_Order, Part_Num, ErrCode, Trans_Date, Trans_Time, Station, Product_Type, Num, Type, Description, InputDateTime, Repaired, ERRDESC, Rework_Fix, Comment, Cust_PN)
		Select distinct A.Line, A.Serial_Number, A.Work_Order, A.Part_Num, 'Pass' AS ErrCode, substring(A.TransDateTime,1,8) Trans_Date
			,substring(A.TransDateTime,9,2)+':'+substring(A.TransDateTime,11,2)+':'+substring(A.TransDateTime,13,2) Trans_Time, 'FA-CHECK-IN' AS Station,
			A.OPID, A.Num, A.Defective_Code, A.Description, A.InputDateTime, A.Repaired,'' ERRDESC,
			'' as rework_fix,'' as comment ,'' Cust_PN  
			From PQC A with(nolock) ,PAL B with(nolock)
			where  --- Serial_Number  like 'C02%'  --- 0043
			Exists(select 1 from PAL_SN_PlantCode P with(nolock)  WHERE P.SNLenType='18Digit' AND P.Type='CR' and a.Serial_Number like P.PlantCode+'%') 
			And A.Part_Num = B.QCI_P_N --and A.Num ='1'----0031_1
			And A.TransDateTime Between @FromDatetime and @ToDatetime 
			And A.Work_Order Like '350%'
			And A.ErrCode <>'Pass'
			And A.Station In ('CameraT2','ALST','CameraS','CLUT','LLT','FQC_4','FQC_3')      ------0027
			---And A.Description  Not In('J130','J79','J80')   ----0032_1 --0038
			And A.Description  Not In(select Model from #bobcatModel) ---0038

	
	----0026_2 End 
	----------------------------------------------------------------------------------------
	-----*******Collect Fail section
	--select top 1000 * from PQC_Repair with(nolock)
	--where UpStation in ('FQC_3','FQC_4','Cosmetic') and  Serial_Number not like 'C02%'
	--order by TransDateTime desc ----It can prove SN begin with "ROE" need not to be upload
	----0045  ErrTransDateTime变更TransDateTime
	Insert into PAL_MODULE_LCDRATE(Line, Serial_Number, Work_Order, Part_Num, ErrCode, Trans_Date, Trans_Time, Station, Product_Type, Num, Type, Description, InputDateTime, Repaired, ERRDESC, Rework_Fix, Comment, Cust_PN)
	Select distinct A.Line, A.Serial_Number, A.Work_Order, A.Part_Num, A.ErrCode, substring(A.TransDateTime,1,8) Trans_Date---Get Errordatetime
		,substring(A.TransDateTime,9,2)+':'+substring(A.TransDateTime,11,2)+':'+substring(A.TransDateTime,13,2) Trans_Time, C.PDCA_Format AS Station,
		A.OPID, A.Num, 'Fail' as Type, A.PN_Body, A.ErrTransDateTime , '' as Repaired,ErrCode ERRDESC,
		CorrectiveAction as rework_fix,FailureAnalysis as comment ,'' Cust_PN  
		From PQC_Repair A with(nolock) ,PAL B with(nolock) ,PAL_PDCA_StageMapping C WITH(NOLOCK) --0019
		where   ---- Serial_Number  like 'C02%'  --- 0043
		Exists(select 1 from PAL_SN_PlantCode P with(nolock)  WHERE P.SNLenType='18Digit' AND P.Type='CR' and a.Serial_Number like P.PlantCode+'%') 
		And A.Part_Num = B.QCI_P_N 
		--And A.UpStation in ('FQC_3','FQC_4','Cosmetic','CameraT','OQC','Machine','PATT','AgingIN','AgingOut',
		--	'VSWRT','ChinAF','ClampOut','Pre-Cos','PR655','ClampIn','FQC_41') 
		AND A.UpStation=C.ShopFloor_Format   
		--and PN_Body in('J41','J43','J11','J13','K21','K78','D2','J44','J45')  -----0007
		And A.TransDateTime Between @FromDatetime and @ToDateTime 

		select top 100 * from PQC_Repair with(nolock)

	----------------------------------------------------------------------------------------
	----0026_1 Begin 
		Insert into PAL_MODULE_LCDRATE(Line, Serial_Number, Work_Order, Part_Num, ErrCode, Trans_Date, Trans_Time, Station, Product_Type, Num, Type, Description, InputDateTime, Repaired, ERRDESC, Rework_Fix, Comment, Cust_PN)
			Select distinct A.Line, A.Serial_Number, A.Work_Order, A.Part_Num, 'Pass' AS ErrCode, substring(A.TransDateTime,1,8) Trans_Date---Get Errordatetime  ---0031_2
			,substring(A.TransDateTime,9,2)+':'+substring(A.TransDateTime,11,2)+':'+substring(A.TransDateTime,13,2) Trans_Time, 'FA-CHECK-OUT' AS Station,
			A.OPID, A.Num, 'Fail' as Type, A.PN_Body, A.ErrTransDateTime , '' as Repaired,'' as ERRDESC,
			'' as rework_fix,'' as comment ,'' Cust_PN  
			From PQC_Repair A with(nolock) ,PAL B with(nolock) 
			where --- Serial_Number  like 'C02%'  --- 0043
			Exists(select 1 from PAL_SN_PlantCode P with(nolock)  WHERE P.SNLenType='18Digit' AND P.Type='CR' and a.Serial_Number like P.PlantCode+'%') 
			And A.Part_Num = B.QCI_P_N 
			And A.TransDateTime Between @FromDatetime and @ToDateTime 
			And A.Work_Order Like '350%'
			And A.UpStation In('FQC_3','FQC_4','LLT','CLUT','CameraT2','ALST','ALSTA','CameraS')----0027
			--And A.PN_Body Not In('J130','J79','J80')  -----0032_2  ---0038
			And A.PN_Body Not In(select Model from #bobcatModel)  -----0032_2  ---0038
	----0026_1 End 
	----------------------------------------------------------------------------------------
	--0032_3 Begin
	Insert into PAL_MODULE_LCDRATE(Line, Serial_Number, Work_Order, Part_Num, ErrCode, Trans_Date, Trans_Time, Station, Product_Type, Num, Type, Description, InputDateTime, Repaired, ERRDESC, Rework_Fix, Comment, Cust_PN)
		Select distinct A.Line, A.Serial_Number, A.Work_Order, A.Part_Num, ErrCode  AS ErrCode, substring(A.TransDateTime,1,8) Trans_Date
			,substring(A.TransDateTime,9,2)+':'+substring(A.TransDateTime,11,2)+':'+substring(A.TransDateTime,13,2) Trans_Time, 
			Case A.Station  ----0038
			When 'Camera-FA-Check-IN' Then 'FA-CHECK-IN'
			when 'Camera-FA-Check-OUT' then 'FA-CHECK-OUT' 
			else A.Station END AS Station,
			A.OPID, A.Num, A.Defective_Code, A.Description, A.InputDateTime, A.Repaired,'' ERRDESC,
			'' as rework_fix,'' as comment ,'' Cust_PN  
			From PQC A with(nolock) ,PAL B with(nolock)
			where ---Serial_Number  like 'C02%'  And ----------------------0038 取消like'C02%'，J290为SC02xxxx
			A.Part_Num = B.QCI_P_N 
			And A.TransDateTime Between @FromDatetime and @ToDatetime 
			--And A.Work_Order Like '350%'
			--And A.Station In('FA-CHECK-IN','FA-CHECK-OUT')---0038
			And A.Station In('FA-CHECK-IN','FA-CHECK-OUT','Camera-FA-Check-in','Camera-FA-Check-out','DHAP400')---0038 --0040
			--And A.Description In('J130','J79','J80')   ---0038
			And A.Description In(select Model from #bobcatModel)     ---0038
	--0032_3 End
	----------------------------------------------------------------------------------------
	---0041 begin----
	Insert into PAL_MODULE_LCDRATE(Line, Serial_Number, Work_Order, Part_Num, ErrCode, Trans_Date, Trans_Time, Station, Product_Type, Num, Type, Description, InputDateTime, Repaired, ERRDESC, Rework_Fix, Comment, Cust_PN)
		Select distinct A.Line, A.Serial_Number, A.Work_Order, A.Part_Num, A.ErrCode, substring(A.TransDateTime,1,8) Trans_Date
			,substring(A.TransDateTime,9,2)+':'+substring(A.TransDateTime,11,2)+':'+substring(A.TransDateTime,13,2) Trans_Time, C.PDCA_Format AS Station,
			A.OPID, A.Num, 'Fail' as Type, A.Description, A.InputDateTime, '' as Repaired,ErrCode as ERRDESC,
			'' as rework_fix,'' as comment ,'' Cust_PN  
			From PQC A with(nolock) ,PAL B with(nolock) ,PAL_PDCA_StageMapping C WITH(NOLOCK)   --0019
			where  --- Serial_Number  like 'C02%' --- 0043
			Exists(select 1 from PAL_SN_PlantCode P with(nolock)  WHERE P.SNLenType='18Digit' AND P.Type='CR' and a.Serial_Number like P.PlantCode+'%') 
			And A.Part_Num = B.QCI_P_N ---and ErrCode ='Pass' and A.Num ='1'
			AND ErrCode<>'PASS'---AND Repaired='N'
			AND A.Station=C.ShopFloor_Format          
			And A.TransDateTime Between @FromDatetime and @ToDatetime   

	---0041 REP送20220610140030之前的PQC
	-----------Most of failed modue SN do not go through Repaired process but come into scrap processPre 
	----0022Begin
	SELECT DISTINCT PAL_SN INTO #CompSN_BK_REP FROM CompSN_BK_REP WITH(NOLOCK) WHERE REPDateTime BETWEEN @FromDatetime and @ToDateTime 
	SELECT A.* INTO #PQC FROM PQC A WITH(NOLOCK),#CompSN_BK_REP B WHERE A.Serial_Number=B.PAL_SN AND A.TransDateTime<'20220610140030' ---0041-REP送20220610140030之前的PQC,过渡期后取消
	INSERT INTO #PQC
	SELECT A.* FROM PALModuleBK.dbo.PQC A WITH(NOLOCK),#CompSN_BK_REP B WHERE A.Serial_Number=B.PAL_SN AND A.TransDateTime<'20220610140030' ---0041-REP送20220610140030之前的PQC,过渡期后取消
	----0022End
	Insert into PAL_MODULE_LCDRATE(Line, Serial_Number, Work_Order, Part_Num, ErrCode, Trans_Date, Trans_Time, Station, Product_Type, Num, Type, Description, InputDateTime, Repaired, ERRDESC, Rework_Fix, Comment, Cust_PN)
	select distinct e.Line,e.Serial_Number ,e.Work_Order,e.Part_Num ,e.ErrCode ,substring(a.REPDateTime ,1,8) Trans_Date
		,substring(a.REPDateTime ,9,2)+':'+substring(a.REPDateTime ,11,2)+':'+substring(a.REPDateTime ,13,2) Trans_Time,F.PDCA_Format AS Station,e.OPID ,e.Num ,'Fail' as Type ,e.Description ,e.TransDateTime as ErrTransDateTime,
		'' as Reapaired,e.ErrCode ERRDESC,'' as rework_fix, ''as comment ,'' Cust_PN 
		from CompSN_BK_REP a with(nolock), 
		 PAL_SN_Rework b with(nolock),
		 PAL_MIS_WO c with(nolock),
		 TDDOptio d with(nolock),
		 #PQC e with(nolock),
		 PAL_PDCA_StageMapping f WITH(NOLOCK)  --0019
		where a.PAL_SN=b.QCI_SN 
		--and Comp_Name='LCD' 
		and a.REPDateTime Between @FromDatetime and @ToDateTime 
		and b.QCI_WO=c.Work_Order 
		and a.Comp_PN=d.Option_Code 
		and a.PAL_SN=e.Serial_Number 
		and e.ErrCode<>'pass'
		and e.Repaired='N'
	  --  and e.Station in ('FQC_3','FQC_4','Cosmetic','CameraT','OQC','Machine','PATT','AgingIN','AgingOut',
			--'VSWRT','ChinAF','ClampOut','Pre-Cos','PR655','ClampIn','FQC_41')
		and e.Station =F.ShopFloor_Format
		----and e.Description in('J41','J43','J11','J13','K21','K78','D2','J44','J45')  ------0007
		-- and a.PAL_SN like 'C02%' --- 0043
		AND Exists(select 1 from PAL_SN_PlantCode P with(nolock)  WHERE P.SNLenType='18Digit' AND P.Type='CR' and a.PAL_SN like P.PlantCode+'%') 
	  ---0041 end----
		----------------------------------------------------------------------------------------
		------0028 Begin
		------0026_3 Begin 
		--Insert into PAL_MODULE_LCDRATE
		--select distinct e.Line,e.Serial_Number ,e.Work_Order,e.Part_Num ,e.ErrCode ,substring(a.REPDateTime ,1,8) Trans_Date
		--,substring(a.REPDateTime ,9,2)+':'+substring(a.REPDateTime ,11,2)+':'+substring(a.REPDateTime ,13,2) Trans_Time,'FA-CHECK-OUT' AS Station,e.OPID ,e.Num ,'Fail' as Type ,e.Description ,e.TransDateTime as ErrTransDateTime,
		--'' as Reapaired,'' as ERRDESC,'' as rework_fix, ''as comment ,'' Cust_PN 
	 --   from CompSN_BK_REP a with(nolock), 
		-- PAL_SN_Rework b with(nolock),
		-- PAL_MIS_WO c with(nolock),
		-- TDDOptio d with(nolock),
		-- #PQC e with(nolock),
		-- PAL_PDCA_StageMapping f WITH(NOLOCK)  --0019
	 --   where a.PAL_SN=b.QCI_SN 
	 --   --and Comp_Name='LCD' 
	 --   and a.REPDateTime Between @FromDatetime and @ToDateTime 
	 --   and b.QCI_WO=c.Work_Order 
	 --   and a.Comp_PN=d.Option_Code 
	 --   and a.PAL_SN=e.Serial_Number 
	 --   and e.ErrCode<>'pass'
	 --   and e.Repaired='N'
	 -- --  and e.Station in ('FQC_3','FQC_4','Cosmetic','CameraT','OQC','Machine','PATT','AgingIN','AgingOut',
		--	--'VSWRT','ChinAF','ClampOut','Pre-Cos','PR655','ClampIn','FQC_41')
		--and e.Station =F.ShopFloor_Format
	 --   ----and e.Description in('J41','J43','J11','J13','K21','K78','D2','J44','J45')  ------0007
	 --   and a.PAL_SN like 'C02%'
		--And e.Work_Order Like '350%'
		------0026_3 End 
		------0028 Begin
		----------------------------------------------------------------------------------------

	----(0011)
	--------Mark
	--Insert into PAL_MODULE_LCDRATE
	--Select a.line,a.Comp_SN,c.QCI_WO,C.QCI_PN_1,A.ErrCode,substring(A.TransDateTime,1,8) Trans_Date,
	--	substring(A.TransDateTime,9,2)+':'+substring(A.TransDateTime,11,2)+':'+substring(A.TransDateTime,13,2) Trans_Time,
	--	'LCD Cosmetic 2',A.OPID, A.Num, 'Fail' as Type, 
	--	c.Model, A.TransDateTime , 'N'as 'RepairFlag' ,'' as 'ERRDESC',
	--	'' as rework_fix,'' as comment ,c. Cust_PN_1  
	--from [10.36.6.66].PAL_COMPSN_P80.dbo.PAL_Data_Return_CR a inner join PAL_SN c on a.comp_sn=c.QCI_SN
	--where Serial_Number like '20%' and len(Serial_Number)=14 
	--	and a.TransDateTime Between @FromDatetime and @ToDateTime
	--Insert into PAL_MODULE_LCDRATE
	--Select a.line,a.Comp_SN,c.QCI_WO,C.QCI_PN_1,A.ErrCode,substring(A.TransDateTime,1,8) Trans_Date,
	--	substring(A.TransDateTime,9,2)+':'+substring(A.TransDateTime,11,2)+':'+substring(A.TransDateTime,13,2) Trans_Time,
	--	'LCD Cosmetic 2',A.OPID, A.Num, 'Fail' as Type, 
	--	c.Model, A.TransDateTime , 'N' as 'RepairFlag' ,'' as 'ERRDESC',
	--	'' as rework_fix,'' as comment ,c. Cust_PN_1  
	--from [10.36.6.66].PAL_COMPSN_P80.dbo.PAL_Data_Return_CR_bk a inner join PAL_SN c on a.comp_sn=c.QCI_SN
	--where a.Serial_Number like '20%'  and len(a.Serial_Number)=14  
	--	and a.TransDateTime Between @FromDatetime and @ToDateTime
	------
	-----------------------------------------------------------------------------------------------------------------------0005 0008 LCD3
	--Insert into PAL_MODULE_LCDRATE
	--Select a.line,b.Comp_SN,c.QCI_WO,C.QCI_PN_1,A.ErrorCode,substring(A.TransDateTime,1,8) Trans_Date,
	--	substring(A.TransDateTime,9,2)+':'+substring(A.TransDateTime,11,2)+':'+substring(A.TransDateTime,13,2) Trans_Time,
	--	case  when  a.Station in('LCDC','LCDF','LCDT') then 'LCD Test 3' end as Station,A.OPID, A.Num, 'Fail' as Type, 
	--	A.Cust_Model, A.TransDateTime , A.RepairFlag ,'' ERRDESC,
	--	'' as rework_fix,'' as comment ,c. Cust_PN_1  
	--	from  [10.36.6.66].PAL_COMPSN_P80.dbo.PAL_Module_PQC a WITH(NOLOCK),
	--	[10.36.6.66].PAL_COMPSN_P80.dbo.PAL_Module_CompSN b,PAL_SN C WITH(NOLOCK)
	--	  WHERE a.Station in('LCDC','LCDF','LCDT')
	--	  and a.Module_SN = B.Module_SN and b.Comp_name='CR' and b.Comp_SN=c.QCI_SN 
	--	    And A.TransDateTime Between @FromDatetime and @ToDateTime
	    
	--Insert into PAL_MODULE_LCDRATE
	--Select a.line,a.Module_SN,c.QCI_WO,C.QCI_PN_1,A.ErrorCode,substring(A.TransDateTime,1,8) Trans_Date,
	--	substring(A.TransDateTime,9,2)+':'+substring(A.TransDateTime,11,2)+':'+substring(A.TransDateTime,13,2) Trans_Time,
	--	case a.Station when 'CRFUN' then 'LCD Test 3' end as Station,A.OPID, A.Num, 'Fail' as Type, 
	--	A.Cust_Model, A.TransDateTime , A.RepairFlag ,'' ERRDESC,
	--	'' as rework_fix,'' as comment ,c. Cust_PN_1  
	--	from  [10.36.6.66].PAL_COMPSN_P80.dbo.PAL_Module_PQC a WITH(NOLOCK),PAL_SN C WITH(NOLOCK)
	--	  WHERE a.Station='CRFUN' 
	--	  and a.Module_SN = c.QCI_SN  
	--	    And A.TransDateTime Between @FromDatetime and @ToDateTime
	-----------------------------------------------------------------------------------------------------------------------0005 0008 LCD3  

	-----------------------------------------------------------------------------------------------------------------------0005 0008 0012 TPT 
	----insert into PAL_MODULE_LCDRATE
	----Select line,Module_SN,'' as Work_Order,'' as QCI_PN,ErrorCode,substring(TransDateTime,1,8) Trans_Date,
	----	substring(TransDateTime,9,2)+':'+substring(TransDateTime,11,2)+':'+substring(TransDateTime,13,2) Trans_Time,
	----	case  when Station IN('TPT','TOPT') then 'Top-Assembly' end as Station,OPID, Num, 'Fail' as Type, 
	----	Cust_Model, TransDateTime , RepairFlag ,'' ERRDESC,
	----	'' as rework_fix,'' as comment ,'' as Cust_PN  
	----	from  [10.36.6.66].PAL_COMPSN_P80.dbo.PAL_Module_PQC WITH(NOLOCK) 
	----	  where Station IN('TPT','TOPT')  and  TransDateTime Between @FromDatetime and @ToDateTime
	--insert into PAL_MODULE_LCDRATE
	--Select line,Module_SN,'' as Work_Order,'' as QCI_PN,ErrorCode,substring(TransDateTime,1,8) Trans_Date,
	--substring(TransDateTime,9,2)+':'+substring(TransDateTime,11,2)+':'+substring(TransDateTime,13,2) Trans_Time,
	--    'Top-Assembly' as Station,OPID, Num, 'Fail' as Type, 
	--    Cust_Model, TransDateTime , RepairFlag ,'' ERRDESC,
	--    '' as rework_fix,'' as comment ,'' as Cust_PN  
	--    from  [10.36.6.66].PAL_COMPSN_P80.dbo.PAL_Module_PQC  WITH(NOLOCK)
	--      where Station in ('TOPT','TPT', 'TOPF' ) and  TransDateTime Between @FromDatetime and @ToDateTime
	--------------Mark
	---------------------------------------------------------------------------------------------------------------------0005 0008 0012 TPT    
	Delete PAL_MODULE_LCDRATE where  ----Only D2 need upload these 3 staions.
	--select top 1000 * from PAL_MODULE_LCDRATE
	------0017
	Delete from PAL_MODULE_LCDRATE where Station in('LCD Test 1','LCD Test 2') and ErrCodeStation in ('Pre-Camera/ALS','Cell Assembly','BLU OQC') and Description !='D2'='PASS'
	------0017
	--------------------------------------------------------------------Get LCD3 Station data
	--Exec [10.36.6.66].PAL_COMPSN_P80.dbo.usp_PAL_PDCA_ModuleLCD3 @FromDateTime,@ToDateTime 
	Exec [10.36.6.66].PAL_COMPSN_P80.dbo.usp_PAL_PDCA_SubLine @FromDateTime,@ToDateTime 

	Insert into PAL_MODULE_LCDRATE(Line, Serial_Number, Work_Order, Part_Num, ErrCode, Trans_Date, Trans_Time, Station, Product_Type, Num, Type, Description, InputDateTime, Repaired, ERRDESC, Rework_Fix, Comment, Cust_PN)
		Select * from [10.36.6.66].PAL_COMPSN_P80.DBO.PAL_MODULE_LCDRATE

	------0020
	Exec [usp_PAL_PDCA_GenMod_LCDyield_GetLCData] @FromDateTime,@ToDateTime 
	------*******Update description	
	Update A
	Set A.ERRDESC =B.Description  from PAL_MODULE_LCDRATE A,Error_Code   B
		Where A.ErrCode=B.ErrCode
	Update A
	Set A.Rework_Fix =B.Description  from PAL_MODULE_LCDRATE A,Error_Code   B
		Where A.Rework_Fix=B.ErrCode
	
	Update A
	Set A.ERRDESC =B.Description  from PAL_MODULE_LCDRATE A,[10.36.6.66].PAL_COMPSN_P80.DBO.Error_Code   B
		Where A.ErrCode=B.ErrCode
	Update A
	Set A.Rework_Fix =B.Description  from PAL_MODULE_LCDRATE A,[10.36.6.66].PAL_COMPSN_P80.DBO.Error_Code   B
		Where A.Rework_Fix=B.ErrCode
	------------------------------------------------------------------------------------
	Update A
		Set A.cust_pn = Cust_PN_1  from PAL_MODULE_LCDRATE A,PAL_SN B with(nolock)
		Where A.Serial_Number=B.QCI_SN 
		and A.Cust_PN=''

	Update A
		Set A.cust_pn = Cust_PN_1  from PAL_MODULE_LCDRATE A,PALModuleBK.dbo.PAL_SN B with(nolock)
		Where A.Serial_Number=B.QCI_SN 
		and A.Cust_PN=''
	------Mark	
	--Update A   ----0005----0014
	--	Set A.cust_pn =b.Cust_PN  from PAL_MODULE_LCDRATE A,[10.36.6.66].PAL_COMPSN_P80.dbo.CompSN B with(nolock)
	--	Where A.Serial_Number=B.Comp_SN
	--	and A.Cust_PN=''
	------Mark 
	------------------------------------------------------------------------------------
	-----(0001)
	-----Dennis added log on 2013-01-21 10:23.
	-----Purpose: ??Update??PN(????,???????????)???,??????????Update??,
	-----???????,???????Block???Alarm.	
	If exists(Select Top 1 * from PAL_MODULE_LCDRATE with(nolock) where Cust_PN ='')
	Begin
		Update A
			Set A.cust_pn = Cust_PN_1  from PAL_MODULE_LCDRATE A,PALModuleBK.dbo.PAL_SN B with(nolock)
			Where A.Serial_Number=B.QCI_SN 
			and A.Cust_PN=''
	------Mark    
	  --  Update A  ----------0005
			--Set A.cust_pn =b.Cust_PN  from PAL_MODULE_LCDRATE A,[10.36.6.66].PALDBBK.dbo.CompSN B with(nolock)
			--Where A.Serial_Number=B.Comp_SN 
			--and A.Cust_PN=''
	------Mark
	End
	-----????????,??????????Update.
	Delete from PAL_MODULE_LCDRATE where Cust_PN=''
	------------------------------------------------------------------------------------
	------*******First we split Errcode Description by slashes , but now cancel it since we will follow FA transfer way.
	/*----[Rework_Fix]+char(9)+[Comment]
	update A
		Set A.Rework_Fix = substring(A.ERRDESC,CHARINDEX ('/',A.ERRDESC)+1,
			CHARINDEX ('/',A.ERRDESC,CHARINDEX ('/',A.ERRDESC)+1)-CHARINDEX ('/',A.ERRDESC)-1),
			A.Comment = reverse(substring(reverse(A.ERRDESC),1,CHARINDEX ('/',reverse(A.ERRDESC))-1)),
			A.ERRDESC=substring(A.ERRDESC,1,CHARINDEX ('/',A.ERRDESC)-1)
			from PAL_MODULE_LCDRATE A 
			where CHARINDEX ('/',A.ERRDESC,CHARINDEX ('/',A.ERRDESC)+1)!=0
	
	update A
		Set A.comment =reverse(substring(reverse(A.ERRDESC),1,CHARINDEX ('/',reverse(A.ERRDESC))-1)) ,
			--A.Comment = substring(reverse(A.ERRDESC),1,CHARINDEX ('/',reverse(A.ERRDESC))-1) 
			A.ERRDESC=substring(A.ERRDESC,1,CHARINDEX ('/',A.ERRDESC)-1)
			from PAL_MODULE_LCDRATE A 
			where CHARINDEX ('/',A.ERRDESC,CHARINDEX ('/',A.ERRDESC)+1)=0
			And CHARINDEX ('/',A.ERRDESC) !=0*/
	----customer complain olny few Fail were upload ,so add a log
	Insert into PAL_MODULE_LCDRATE_BK(Line, Serial_Number, Work_Order, Part_Num, ErrCode, Trans_Date, Trans_Time, Station, Product_Type, Num, Type, Description, InputDateTime, Repaired, ERRDESC, Rework_Fix, Comment, Cust_PN)
	select *  from PAL_MODULE_LCDRATE where type='Fail'
	-------------(0002)
	IF EXISTS(SELECT TOP 1 * FROM PAL_MODULE_LCDRATE_Quarantine WITH(NOLOCK) WHERE LEN(line)=2 )---Automatically update lines whose length is 2
		BEGIN
			UPDATE ppmtq
				SET line=t.Input_Line FROM PAL_MODULE_LCDRATE_Quarantine ppmtq ,PAL_SN t WITH(nolock) 
			WHERE ppmtq.Serial_Number =t.QCI_SN AND LEN(ppmtq.Line)=2
					----40.6??????40.6??
		END
	----------------------------------------------------------------------------------------------
	-----(0009)  Start
	-----仍然保留了条件b.SendToPDCA='Y'，以后确定不需要时可以拿掉.
	Update a set a.line=b.PDCA_Line 
		from  PAL_MODULE_LCDRATE a inner join PAL_Routing_Line b with(nolock)
		on a.line=b.line 
		where b.Line!=b.PDCA_Line and b.PDCA_Line!=''and b.SendToPDCA='Y' 
	-----例如，对于F14线，在Module中无定义，是for FATP Sub段“LCD Test 3”之用,所以通过Module的PAL_Routing_Line表是无法Update为“F4-2FT-F14”的.
	-----而之后与FATP PAL_Routing_Line关联时，会因为不符合“Line IN (SELECT PDCA_LINE FROM [10.36.6.66]...”而别抓入quarantine Table.
	SELECT * Into #Temp_FATPLine FROM [10.36.6.66].PAL_COMPSN_P80.dbo.PAL_Routing_Line 
	Update a set a.line=b.PDCA_Line 
		from  PAL_MODULE_LCDRATE a inner join #Temp_FATPLine b with(nolock)
		on a.line=b.line 
		where b.Line!=b.PDCA_Line and b.PDCA_Line!=''and b.SendToPDCA='Y'
	-----(0009)  End
	----------------------------------------------------------------------------------------------
	-----Dennis added log on 2015/02/17 13:20.
	-----因为上面已经转换过线别了，所以下面用PDCA_LINE做条件是OK的.
	------Check 40.6 lines simultaneously----
	INSERT INTO PAL_MODULE_LCDRATE(Line, Serial_Number, Work_Order, Part_Num, ErrCode, Trans_Date, Trans_Time, Station, Product_Type, Num, Type, Description, InputDateTime, Repaired, ERRDESC, Rework_Fix, Comment, Cust_PN)
		SELECT * FROM  WITH(NOLOCK) WHERE 
			line IN (SELECT PDCA_LINE FROM PAL_Routing_Line WITH(NOLOCK) WHERE sendtopdca='Y')
			or Line IN (SELECT PDCA_LINE FROM [10.36.6.66].PAL_COMPSN_P80.dbo.PAL_Routing_Line 
			WITH(NOLOCK) WHERE sendtopdca='Y')---Add link 40.6 ,seems no impact on DB performance.
	Delete FROM PAL_MODULE_LCDRATE_quarantine WHERE PAL_MODULE_LCDRATE_quarantine
			line IN (SELECT PDCA_LINE FROM PAL_Routing_Line WITH(NOLOCK) WHERE sendtopdca='Y')
			or Line IN (SELECT PDCA_LINE FROM [10.36.6.66].PAL_COMPSN_P80.dbo.PAL_Routing_Line 
			WITH(NOLOCK) WHERE sendtopdca='Y')---Add link 40.6 ,seems no impact on DB performance.
	-----Tansfer thses data whose lines are not defined to quarantine table
	INSERT INTO PAL_MODULE_LCDRATE_quarantine(Line, Serial_Number, Work_Order, Part_Num, ErrCode, Trans_Date, Trans_Time, Station, Product_Type, Num, Type, Description, InputDateTime, Repaired, ERRDESC, Rework_Fix, Comment, Cust_PN)
		SELECT Line, Serial_Number, Work_Order, Part_Num, ErrCode, Trans_Date, Trans_Time, Station, Product_Type, Num, Type, Description, InputDateTime, Repaired, ERRDESC, Rework_Fix, Comment, Cust_PN FROM PAL_MODULE_LCDRATE WITH(NOLOCK) WHERE 
			line not IN (SELECT PDCA_LINE FROM PAL_Routing_Line WITH(NOLOCK) WHERE sendtopdca='Y')
			AND Line NOT IN (SELECT PDCA_LINE FROM [10.36.6.66].PAL_COMPSN_P80.dbo.PAL_Routing_Line 
			WITH(NOLOCK) WHERE sendtopdca='Y')---Add link 40.6 ,seems no impact on DB performance.
	Delete FROM PAL_MODULE_LCDRATE WHERE 
			line not IN (SELECT PDCA_LINE FROM PAL_Routing_Line WITH(NOLOCK) WHERE sendtopdca='Y')
			AND Line NOT IN (SELECT PDCA_LINE FROM [10.36.6.66].PAL_COMPSN_P80.dbo.PAL_Routing_Line 
			WITH(NOLOCK) WHERE sendtopdca='Y')---Add link 40.6 ,seems no impact on DB performance. 
	-------------------(0002)
	update PAL_MODULE_LCDRATE set [Product_Type]='BTR'----???CR Module??BTR
	update PAL_MODULE_LCDRATE set type ='Pass' where ErrCode ='Pass'
	update PAL_MODULE_LCDRATE set type ='Fail' where ErrCode !='Pass'
	----------------------------------------------------------------------------------------------
	-----Added by Dennis on 2013-08-30 08:02AM.
	Delete from PAL_MODULE_LCDRATE_quarantine 
		where Line In (SELECT LINE FROM [10.36.6.66].PAL_COMPSN_P80.dbo.PAL_Routing_Line WITH(NOLOCK)
						  WHERE sendtopdca='N')
	Delete from PAL_MODULE_LCDRATE_quarantine 
		where Line In (SELECT LINE FROM PAL_Routing_Line WITH(NOLOCK)
						  WHERE sendtopdca='N')
	----------------------------------------------------------------------------------------------
	Truncate table PAL_PDCA_LCD_File
	---------------------------------------------------------------------------------------------（0025 Begin_1）
	Truncate table PAL_PDCA_LCD_File_SUB
	----Insert into PAL_PDCA_LCD_File
	----	Select [Description]+char(9)+[Description]+' LCD'+char(9)+Cust_PN+char(9)+[Type]+char(9)+Station+char(9)
	----	+ Trans_Date+char(9)+Trans_Time+char(9)+Serial_Number +char(9)+ERRDESC+char(9) 
	----	+[Rework_Fix]+char(9)+[Comment]+char(9)+[Line] As Col1
	----	from PAL_MODULE_LCDRATE where Station <> 'Top-Assembly'
	--Insert into PAL_PDCA_LCD_File
	--	Select [Description]+char(9)+[Description]+' LCD'+char(9)+Cust_PN+char(9)+[Type]+char(9)+Station+char(9)
	--	+ Trans_Date+char(9)+Trans_Time+char(9)+Serial_Number +char(9)+ERRDESC+char(9) 
	--	+[Rework_Fix]+char(9)+[Comment]+char(9)+[Line] As Col1
	--	from PAL_MODULE_LCDRATE where Station not in('Top-Assembly','PR655','Pre-Cos')
	--Insert into PAL_PDCA_LCD_File_SUB
	--	Select [Description]+char(9)+[Description]+' LCD'+char(9)+Cust_PN+char(9)+[Type]+char(9)+Station+char(9)
	--	+ Trans_Date+char(9)+Trans_Time+char(9)+Serial_Number +char(9)+ERRDESC+char(9) 
	--	+[Rework_Fix]+char(9)+[Comment]+char(9)+[Line] As Col1
	--	from PAL_MODULE_LCDRATE where Station  in('PR655','Pre-Cos')
	--Insert into PAL_PDCA_LCD_File_SUB  --------------0005
	--	Select [Description]+char(9)+[Description]+' KeyBoard'+char(9)+Cust_PN+char(9)+[Type]+char(9)+Station+char(9)
	--	+ Trans_Date+char(9)+Trans_Time+char(9)+Serial_Number +char(9)+ERRDESC+char(9) 
	--	+[Rework_Fix]+char(9)+[Comment]+char(9)+[Line] As Col1
	--	from PAL_MODULE_LCDRATE where Station = 'Top-Assembly'
	---------------------------------------------------------------------------------------------	
	--0033 Begin
	--PR655      -> should be included in the LCD-Yield files
	--Pre-Cos       -> should be included in the LCD-Yield files
	--Top-Assembly  -> no change. it should remain in SUBASSEMBLY-YIELD files.
	--0034_1 Begin
	Update PAL_MODULE_LCDRATE
		Set Description ='J80'
		Where Description ='J80G'
	--0034_1 End

	-----------0039 B
	Update  PAL_MODULE_LCDRATE Set Serial_Number=right(Serial_Number,len(Serial_Number)-1) where Serial_Number like'SC02%'
	-----------0039 E

	Insert into PAL_PDCA_LCD_File(Col1,QCI_Model)
		Select [Description]+char(9)+[Description]+' LCD'+char(9)+Cust_PN+char(9)+[Type]+char(9)+Station+char(9)
		+ Trans_Date+char(9)+Trans_Time+char(9)+Serial_Number +char(9)+ERRDESC+char(9) 
		+[Rework_Fix]+char(9)+[Comment]+char(9)+[Line] As Col1,Description
		from PAL_MODULE_LCDRATE where Station not in('Top-Assembly')--,'PR655','Pre-Cos')
	Insert into PAL_PDCA_LCD_File_SUB(Col1,QCI_Model)  --------------0005
		--0034_2 Begin
		Select [Description]+char(9)+[Description]+
		Case Description
		When  'J79' Then ' SA'
		When  'J80' Then ' SA'
		Else  ' SA'  --(0036)
		--Else  ' KeyBoard'  
		End 
		+char(9)+Cust_PN+char(9)+[Type]+char(9)+Station+char(9)
		+ Trans_Date+char(9)+Trans_Time+char(9)+Serial_Number +char(9)+ERRDESC+char(9) 
		+[Rework_Fix]+char(9)+[Comment]+char(9)+[Line] As Col1,Description
		from PAL_MODULE_LCDRATE where Station = 'Top-Assembly'	
		--Select [Description]+char(9)+[Description]+' KeyBoard'+char(9)+Cust_PN+char(9)+[Type]+char(9)+Station+char(9)
		--+ Trans_Date+char(9)+Trans_Time+char(9)+Serial_Number +char(9)+ERRDESC+char(9) 
		--+[Rework_Fix]+char(9)+[Comment]+char(9)+[Line] As Col1
		--from PAL_MODULE_LCDRATE where Station = 'Top-Assembly'
		--0034_2 End	
	--0033 End
	Select * Into #PAL_PDCA_LCD_File From PAL_PDCA_LCD_File
	Select * Into #PAL_PDCA_LCD_File_SUB From PAL_PDCA_LCD_File_SUB
	Select distinct QCI_Model Into #PAL_PDCA_LCD_File_Model From PAL_PDCA_LCD_File
	Select distinct QCI_Model Into #PAL_PDCA_LCD_File_SUB_Model From PAL_PDCA_LCD_File_SUB




	---------------------------------------------------------------------------------------------（0025 End_1）
	------0030_1 Begin
	While Exists(Select * From #PAL_PDCA_LCD_File_Model)
	Begin 		
		Select @Model =QCI_Model from #PAL_PDCA_LCD_File_Model	--000
		Set @FlatFileName='QCMT_SUB_YLD_'+@Model+'_'+@ToDateTime+'.txt'	--000
		Truncate Table PAL_PDCA_LCD_File	--000
		Insert Into PAL_PDCA_LCD_File(Col1)	--000
			Select Col1 From #PAL_PDCA_LCD_File Where QCI_Model=@Model	--000

		Insert Into PAL_PDCA_LCD_File (Col1) Values ('#END')
		
		---------------------------------------------------------------------------------
		If exists(Select Top 1 * from PAL_MODULE_LCDRATE where [Description]='')
		Begin 
		SET @pathJson = ( 
				Select Col1 from PAL_Module.dbo.PAL_PDCA_LCD_File order by Replace(Col1,char(9),'NA') Desc
				FOR JSON PATH);  

			SET @parametersJson = ( 
				SELECT 
					'E:\PALFA\Share\PDCA\WWSFS\Import\MANUAL-LCDRate\'+@FlatFileName as path
					,@pathJson as jsonString 
					,'N' as header
			--		,'\t' as split 
					,@SP_Name as CallSP
				FOR JSON PATH,WITHOUT_ARRAY_WRAPPER); 
			Exec [PAL_Module].dbo.CMDSHELL2CLR 'CreateFile',@parametersJson ,@iResult output ,@iMessage output --0045
			-------（0024）start
			-------（0023）
			--Set @strSQL='bcp "Select Col1 from PAL_Module.dbo.PAL_PDCA_LCD_File order by Replace(Col1,char(9),''NA'') Desc" queryout E:\PALFA\Share\PDCA\WWSFS\Import\MANUAL-LCDRate\'+
			--	@FlatFileName+
			--	' -c -S"10.36.6.86" -U"sa" -P"East#86_qmh2024"'
			-------（0024）End
		End
		Else
		Begin
			SET @pathJson = ( 
				Select Col1 from PAL_Module.dbo.PAL_PDCA_LCD_File Order by Col1 Desc
				FOR JSON PATH);  

			SET @parametersJson = ( 
				SELECT 
					'E:\PALFA\Share\PDCA\WWSFS\Import\MANUAL-LCDRate\'+@FlatFileName as path
					,@pathJson as jsonString 
					,'N' as header
			--		,'\t' as split 
					,@SP_Name as CallSP
				FOR JSON PATH,WITHOUT_ARRAY_WRAPPER); 
			Exec [PAL_Module].dbo.CMDSHELL2CLR 'CreateFile',@parametersJson ,@iResult output ,@iMessage output --0045
			--Set @strSQL='bcp "Select Col1 from PAL_Module.dbo.PAL_PDCA_LCD_File Order by Col1 Desc" queryout E:\PALFA\Share\PDCA\WWSFS\Import\MANUAL-LCDRate\'+
			--	@FlatFileName+
			--	' -c -S"10.36.6.86" -U"sa" -P"East#86_qmh2024"'
		End
		---------------------------------------------------------------------------------
		Print @strSQL
		EXEC master..xp_cmdshell @strSQL
		----------------------------------------------------------------------------------------------

		Declare @iYear varchar(6)
		Declare @iMonth varchar(6)
		Declare @iDay varchar(6)
		Declare @FileBKPath varchar(300)

		Set @iYear=Substring(@CurrentDateTime,1,4)
		Set @iMonth=Substring(@CurrentDateTime,5,2)
		Set @iDay=Substring(@CurrentDateTime,7,2)
		----------------------------------------------------------------------------------------------

		SET @parametersJson =  (SELECT 'E:\PALFA\Share\PDCA\WWSFS\Import\MANUAL-LCDRate_BK\'+@iYear+'\'+@iMonth+'\'+@iDay as path FOR JSON PATH,WITHOUT_ARRAY_WRAPPER)
		Exec PAL_Module.dbo.CMDSHELL2CLR 'CreateDirectory',@parametersJson,@iResult output ,@iMessage output   --0045
		--Set @strSQL='"MD E:\PALFA\Share\PDCA\WWSFS\Import\MANUAL-LCDRate_BK\'+@iYear+'"'
		--EXEC master..xp_cmdshell @strSQL

		--Set @strSQL='"MD E:\PALFA\Share\PDCA\WWSFS\Import\MANUAL-LCDRate_BK\'+@iYear+'\'+@iMonth+'"'
		--EXEC master..xp_cmdshell @strSQL

		--Set @strSQL='"MD E:\PALFA\Share\PDCA\WWSFS\Import\MANUAL-LCDRate_BK\'+@iYear+'\'+@iMonth+'\'+@iDay+'"'
		--EXEC master..xp_cmdshell @strSQL

		Set @FileBKPath='E:\PALFA\Share\PDCA\WWSFS\Import\MANUAL-LCDRate_BK\'+@iYear+'\'+@iMonth+'\'+@iDay+'\'
		Print @FileBKPath
		----------------------------------------------------------------------------------------------
		SET @pathJson = ( 
			Select Col1 from PAL_Module.dbo.PAL_PDCA_LCD_File Order by Replace(Col1,char(9),'NA') Desc
			FOR JSON PATH);  

		SET @parametersJson = ( 
			SELECT 
				@FileBKPath+@FlatFileName as path
				,@pathJson as jsonString 
				,'N' as header
		--		,'\t' as split 
				,@SP_Name as CallSP
			FOR JSON PATH,WITHOUT_ARRAY_WRAPPER); 
		Exec [PAL_Module].dbo.CMDSHELL2CLR 'CreateFile',@parametersJson ,@iResult output ,@iMessage output  --0045
		-------（0024）start
		--Set @strSQL='bcp "Select Col1 from PAL_Module.dbo.PAL_PDCA_LCD_File Order by Replace(Col1,char(9),''NA'') Desc" queryout '+
		--	@FileBKPath+@FlatFileName+
		--	' -c -S"10.36.6.86" -U"sa" -P"East#86_qmh2024"'
		-------（0024）End
		--Print @strSQL
		--EXEC master..xp_cmdshell @strSQL
		Delete from #PAL_PDCA_LCD_File_Model Where @Model =QCI_Model	--000
		--每产生一个txt就将该txt塞进PAL_PDCA_Compare   ----0042
		--Insert Into PAL_PDCA_Compare
		--Select @FlatFileName,'LCDRateMANUAL',@ToDateTime,'','N'
	END
	------0030_1 End
	---------------------------------------------------------------------------------------------（0025 Begin_2）
	------0030_2 Begin
	waitfor delay '00:00:01'
	Set @CurrentDateTime =Replace(Replace(Replace(Convert(varchar(19),GetDate(),121),'-',''),':',''),' ','')	--000	
	While Exists(Select * From #PAL_PDCA_LCD_File_SUB_Model)
	Begin 
		Select @Model =QCI_Model from #PAL_PDCA_LCD_File_SUB_Model	--000
		Set @FlatFileName='QCMT_SUB_YLD_'+@Model+'_'+@CurrentDateTime+'.txt'	--000
		Truncate Table PAL_PDCA_LCD_File_SUB	--000
		Insert Into PAL_PDCA_LCD_File_SUB(Col1)	--000
			Select Col1 From #PAL_PDCA_LCD_File_SUB Where QCI_Model=@Model	--000

		--Set @FlatFileName=Substring(@ToDateTime,1,8)+'_'+Substring(@ToDateTime,9,6)+'_'+'SUB'+'.txt'--000
		Insert Into PAL_PDCA_LCD_File_SUB (Col1) Values ('#END')

		SET @pathJson = ( 
		Select Col1 from PAL_Module.dbo.PAL_PDCA_LCD_File_SUB order by Replace(Col1,char(9),'NA') Desc
		FOR JSON PATH);  

		SET @parametersJson = ( 
			SELECT 
				'E:\PALFA\Share\PDCA\WWSFS\Import\MANUAL-LCDRate_SUB\'+@FlatFileName as path
				,@pathJson as jsonString 
				,'N' as header
		--		,'\t' as split 
				,@SP_Name as CallSP
			FOR JSON PATH,WITHOUT_ARRAY_WRAPPER); 
		Exec [PAL_Module].dbo.CMDSHELL2CLR 'CreateFile',@parametersJson ,@iResult output ,@iMessage output  --0045
		---------------------------------------------------------------------------------  
			--Set @strSQL='bcp "Select Col1 from PAL_Module.dbo.PAL_PDCA_LCD_File_SUB order by Replace(Col1,char(9),''NA'') Desc" queryout E:\PALFA\Share\PDCA\WWSFS\Import\MANUAL-LCDRate_SUB\'+
			--	@FlatFileName+
			--	' -c -S"10.36.6.86" -U"sa" -P"East#86_qmh2024"'
		---------------------------------------------------------------------------------
		--Print @strSQL
		--EXEC master..xp_cmdshell @strSQL
		----------------------------------------------------------------------------------------------
		---------------------------------------------------------------------------------------------（0025 End_2）
		----------------------------------------------------------------------------------------------（0025 Begin_3）
		SET @parametersJson =  (SELECT 'E:\PALFA\Share\PDCA\WWSFS\Import\MANUAL-LCDRate_SUB_BK\'+@iYear+'\'+@iMonth+'\'+@iDay as path FOR JSON PATH,WITHOUT_ARRAY_WRAPPER)
		Exec PAL_Module.dbo.CMDSHELL2CLR 'CreateDirectory',@parametersJson,@iResult output ,@iMessage output  --0045
		--Set @strSQL='"MD E:\PALFA\Share\PDCA\WWSFS\Import\MANUAL-LCDRate_SUB_BK\'+@iYear+'"'
		--EXEC master..xp_cmdshell @strSQL

		--Set @strSQL='"MD E:\PALFA\Share\PDCA\WWSFS\Import\MANUAL-LCDRate_SUB_BK\'+@iYear+'\'+@iMonth+'"'
		--EXEC master..xp_cmdshell @strSQL

		--Set @strSQL='"MD E:\PALFA\Share\PDCA\WWSFS\Import\MANUAL-LCDRate_SUB_BK\'+@iYear+'\'+@iMonth+'\'+@iDay+'"'
		--EXEC master..xp_cmdshell @strSQL

		Set @FileBKPath='E:\PALFA\Share\PDCA\WWSFS\Import\MANUAL-LCDRate_SUB_BK\'+@iYear+'\'+@iMonth+'\'+@iDay+'\'
		Print @FileBKPath
		----------------------------------------------------------------------------------------------
		-----（0024）start
			SET @pathJson = ( 
			Select Col1 from PAL_Module.dbo.PAL_PDCA_LCD_File_SUB Order by Replace(Col1,char(9),'NA') Desc
			FOR JSON PATH);  

		SET @parametersJson = ( 
			SELECT 
				@FileBKPath+@FlatFileName as path
				,@pathJson as jsonString 
				,'N' as header
		--		,'\t' as split 
				,@SP_Name as CallSP
			FOR JSON PATH,WITHOUT_ARRAY_WRAPPER); 
		Exec [PAL_Module].dbo.CMDSHELL2CLR 'CreateFile',@parametersJson ,@iResult output ,@iMessage output 

		--Set @strSQL='bcp "Select Col1 from PAL_Module.dbo.PAL_PDCA_LCD_File_SUB Order by Replace(Col1,char(9),''NA'') Desc" queryout '+
		--	@FileBKPath+@FlatFileName+
		--	' -c -S"10.36.6.86" -U"sa" -P"East#86_qmh2024"'
		-------（0024）End
		--Print @strSQL
		--EXEC master..xp_cmdshell @strSQL
		Delete from #PAL_PDCA_LCD_File_SUB_Model Where @Model =QCI_Model	--000
		----------------------------------------------------------------------------------------------（0025 End_3）
		--每产生一个txt就将该txt塞进PAL_PDCA_Compare ----0042
		--Insert Into PAL_PDCA_Compare
		--Select @FlatFileName,'LCDRateMANUAL_SUB',@ToDateTime,'','N'
		-----------------------------------------------------------------------------------------
	End
	------0030_2 End
	--select * from FAeDatetime
	update  FAeDatetime  set EDateTime=@ToDateTime,rundatetime=@ToDateTime
	 where Category='PDCALCDyield'
	----------------------------------------------------------------------------------------
	--0037 该邮件没必要发送
	-----6. 发送邮件通知相关人员.
	--Select EmailAddress Into #TempEmailAddress
	--	from QMSSC_Send_Email
	--		where FuncType='PDCA_GenMod_LCDyield' and SendFlag='Y'and ActiveFlag='Y' 
	--		order by IDNo
	--Declare @AllEmailToAddress varchar(3000)
	--Declare @AllEmailCcAddress varchar(3000)
	--Set @AllEmailToAddress=''
	--Set @AllEmailCcAddress=''
	--Print @AllEmailToAddress

	--Declare @EmailTitle nvarchar(600)
	--Set @EmailTitle='Manual PASS complete, file name: '+@FlatFileName+' (new method)'

	--Declare @EmailContent nvarchar(4000)

	--Select @AllEmailToAddress=@AllEmailToAddress+';'+EmailAddress  from #TempEmailAddress
	--If @AllEmailToAddress!=''
	--	Begin
	--		Set @AllEmailToAddress=Substring(@AllEmailToAddress,2,Len(@AllEmailToAddress)-1)
	--	End
	--Set @EmailContent='<HTML><BODY><FONT name=Arial color=blue size=2pt>'+
	--	'Dear All,'+'<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'+'Generate Manual PASS PDCA data complete!'+
	--	'<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'+'File name: '+@FlatFileName+
	--	'<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'+'You may enter \\10.36.6.86\Share\PDCA\WWSFS\Import\MANUAL-LCDRate_BK to review detail.'+
	--	'</FONT></BODY></HTML>'
	-----Exec sp_send_cdosysmail_Internet '','PAL_PDCA',@AllEmailToAddress,@AllEmailCcAddress,'',@EmailTitle,@EmailContent,'','','',1,1
	-- exec msdb..sp_send_dbmail @profile_name =  'QMS'               -- profile ?? 
	--						 ,@recipients   =@AllEmailToAddress      --@AllEmailToAddress         -- ????? 
	--						 ,@copy_recipients=@AllEmailCcAddress
	--						 ,@subject      =  @EmailTitle -- ???? 
	--						 ,@body         =  @EmailContent              -- ???? 
	--						 ,@body_format  =  'HTML'                      -- ???? 
	--						 ,@file_attachments=''
	------------------------------------------------------------------------------------------
-----------------0029 
	set @StepFlag='Try End'

End Try
Begin Catch
	Select @ErrMsg=N'Stored Precedure:['+@SP_Name+'] is executed exceptionally,'
		+N'ERROR_NUMBER:'+CAST(ERROR_NUMBER() as varchar(50)) 
		+N'ERROR_MESSAGE:'+ERROR_MESSAGE() 
	 
	set @StepFlag=@StepFlag+':' +'Error Happen'
	exec MonitorAgent_SaveErrorLog @SP_Name,'','Convey out' ,@StepFlag,@ErrMsg	 
End Catch
-----------------0029
