USE [PAL_Module]
GO
/****** Object:  StoredProcedure [dbo].[usp_PAL_PDCA_MaterialSN]    Script Date: 2026-03-27 4:54:17 CH ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO







--*Program*: <>
--*Programer*:<Jack>      
--*Date*:<2023-5-9>        
--*Description*:<送MaterialSN至Insight>     
/*
Date                 Owner        Description									Remark
2023-5-12			Jack Guo	  将laserbarcode转换为housing sn送INsight		0001
2023-5-16			Jack Guo	  J290没有拆解，所以没有ATC数据，将BDL送Insight 0002
2023-6-28			Jack Guo	  依FullBoxDatetime的时间进行送Insight			0003
2024-6-12			Tacey		  文档名修改QCMT*.txt						0004
2025-3-10			Larry Liu	  上传Insight时，含有"+"号SN，取前18位			0005
2026-3-26			Neil	      CmdShell更改为CLR								0006
*/  
ALDDDTER Procedure [dbo].[usp_PAL_PDCA_MaterialSN]
	(
		@FromDateTime varchar(20)='',
		@ToDateTime varchar(20)=''
	)
As
SET NOCOUNT ON

declare @ErrMsg Nvarchar(4000)=''
declare @StepFlag varchar(100)='',@Flag varchar(5)=''
declare @SP_Name varchar(100)='usp_PAL_PDCA_MaterialSN'
Declare @Model varchar(20)=''
Declare @Station varchar(50)='STATION1501'
Declare @CurrentDateTime varchar(30)=''
Declare @FlatFileName varchar(150)=''
Declare @iResult Varchar(200)='' , @iMessage Nvarchar(max)='' , @parametersJson NVARCHAR(MAX)='',  @pathJson Nvarchar(max)='' --0006
Begin Try       
	set @SP_Name=isnull(OBJECT_NAME(@@PROCID),'' )
	set @StepFlag='Try Start'	
	Set @CurrentDateTime=dbo.FormatDate(GETDATE(),'YYYYMMDDHHNNSS')
	
	--之所以这样写是为了方便给客户补送某个时间段的资料
	If @FromDateTime='' And  @ToDateTime=''
		Begin
			Set @Flag='Y'
			Select @FromDateTime=EDatetime  From FAeDatetime Where category='PDCAMaterialSN'
			-----这里减去一个不规则秒数，目的是防止丢失Run Job的那个时间点塞进来的数据
			Select @ToDateTime =dbo.FormatDate(DateAdd(Second,-28,GetDate()),'YYYYMMDDHHNNSS')		
		End
	If (@FromDateTime='' And  @ToDateTime <>'') Or (@FromDateTime<>'' And  @ToDateTime ='')
		Begin
			Select N'请检查你输入的2个时间，必须是同时为空或者同时不为空'
			Return
		End
	
	--J290的没有拆解，没法送ATC,只送BDL的
	select  a.MaterialSN,left(a.TransDateTime,8) as ScanDate,dbo.FormatDate(dbo.Convert2Date(a.TransDateTime),'HH:NN:SS')as ScanTime, 
	@Station as Station, a.Plant+'-WH01' as Plant ,a.Model,a.TransDateTime,a.MaterialName,
	space(50) as LinkedSN,  space(50) as Remark,space(200) as FlatFileName,'N' as  IsExistsFlag
	into #MaterialSN
	--from MaterialSNReceive a where TransDateTime Between @FromDatetime and @ToDatetime 
	from MaterialSNReceive a where FullBoxDateTime Between @FromDatetime and @ToDatetime ---0003
	and exists (select 1from MaterialSNReturn b where a.MaterialSN=b.MaterialSN and b.Station='ATC')
	and a.Model !='J290'
	
	--J290的只送BDL站  0002
	insert into #MaterialSN(MaterialSN,ScanDate,ScanTime,Station,Plant,Model,TransDateTime,MaterialName,LinkedSN,Remark,FlatFileName,IsExistsFlag)
	select  a.MaterialSN,left(a.TransDateTime,8) as ScanDate,dbo.FormatDate(dbo.Convert2Date(a.TransDateTime),'HH:NN:SS')as ScanTime, 
	@Station as Station, a.Plant+'-WH01' as Plant ,a.Model,a.TransDateTime,a.MaterialName,
	space(50) as LinkedSN,  space(50) as Remark,space(200) as FlatFileName,'N'
	--from MaterialSNReceive a where TransDateTime Between @FromDatetime and @ToDatetime 
	from MaterialSNReceive a where FullBoxDateTime Between @FromDatetime and @ToDatetime ---0003
	and exists (select 1from MaterialSNReturn b where a.MaterialSN=b.MaterialSN and b.Station='BDL')
	and a.Model ='J290'
	
	If not exists(select 1 from #MaterialSN)
		Begin
			print 'Success-->But No Data'
			return
		End

	--系统刷的Housing，实际是刷的Laser条码，在送Insight的时候送Housing SN，0001
	update a set a.LinkedSN=b.PAL_SN from  #MaterialSN a ,PAL_LaserBarcode  b
	where a.MaterialSN=b.LaserBarcode and a.MaterialName in ('Housing')

	--备份表的也要考虑下
	update a set a.LinkedSN=b.PAL_SN from  #MaterialSN a , PALModuleBK.dbo.PAL_LaserBarcode b
	where a.MaterialSN=b.LaserBarcode and a.MaterialName in ('Housing') and a.LinkedSN=''

	--转换为原始的Housing SN
	update a set a.LinkedSN=b.Comp_PN,IsExistsFlag='Y' from  #MaterialSN a ,PAL_ModuleCheck_LabelData  b
	where a.LinkedSN=b.Comp_SN and a.MaterialName in ('Housing') and len(b.Comp_PN)>=17

	update a set a.LinkedSN=b.Comp_PN,IsExistsFlag='Y' from  #MaterialSN a , PALModuleBK.dbo.PAL_ModuleCheck_LabelData b
	where a.LinkedSN=b.Comp_SN and a.MaterialName in ('Housing') and a.LinkedSN='' and len(b.Comp_PN)>=17
	
	--针对Housing在PAL_ModuleCheck_LabelData匹配不到关系的，不送Insight,啥时候送在另谈
	delete from #MaterialSN output deleted.MaterialSN,deleted.LinkedSN,'No Mapping','',deleted.Model,deleted.MaterialName,@CurrentDateTime 
	into PAL_PDCA_MaterialSN_File_Record
	where MaterialName in ('Housing') and IsExistsFlag='N'

	 
	--统一设置为OK
	update #MaterialSN set  Remark='OK'

	Declare @strSQL nvarchar(600)=''	
	Declare @iYear varchar(6)=''
	Declare @iMonth varchar(6)=''
	Declare @iDay varchar(6)=''
	Declare @FileBKPath varchar(300)=''
	
	Declare @FileLocalPath varchar(300)='E:\PALFA\Share\PDCA\WWSFS\Import\MANUAL-MaterialSN\'
	Set @iYear=Substring(@CurrentDateTime,1,4)
	Set @iMonth=Substring(@CurrentDateTime,5,2)
	Set @iDay=Substring(@CurrentDateTime,7,2)
	----------------------------------------------------------------------------------------------

	SET @parametersJson =  (SELECT 'E:\PALFA\Share\PDCA\WWSFS\Import\MANUAL-MaterialSN_BK\'+@iYear as path FOR JSON PATH,WITHOUT_ARRAY_WRAPPER)
	Exec PAL_Module.dbo.CMDSHELL2CLR 'CreateDirectory',@parametersJson,@iResult output ,@iMessage output   --0006
	--Set @strSQL='"MD E:\PALFA\Share\PDCA\WWSFS\Import\MANUAL-MaterialSN_BK\'+@iYear+'"'
	--EXEC master..xp_cmdshell @strSQL


	SET @parametersJson =  (SELECT 'E:\PALFA\Share\PDCA\WWSFS\Import\MANUAL-MaterialSN_BK\'+@iYear+'\'+@iMonth as path FOR JSON PATH,WITHOUT_ARRAY_WRAPPER)
	Exec PAL_Module.dbo.CMDSHELL2CLR 'CreateDirectory',@parametersJson,@iResult output ,@iMessage output   --0006
	--Set @strSQL='"MD E:\PALFA\Share\PDCA\WWSFS\Import\MANUAL-MaterialSN_BK\'+@iYear+'\'+@iMonth+'"'
	--EXEC master..xp_cmdshell @strSQL

	SET @parametersJson =  (SELECT 'E:\PALFA\Share\PDCA\WWSFS\Import\MANUAL-MaterialSN_BK\'+@iYear+'\'+@iMonth+'\'+@iDay as path FOR JSON PATH,WITHOUT_ARRAY_WRAPPER)
	Exec PAL_Module.dbo.CMDSHELL2CLR 'CreateDirectory',@parametersJson,@iResult output ,@iMessage output   --0005
	--Set @strSQL='"MD E:\PALFA\Share\PDCA\WWSFS\Import\MANUAL-MaterialSN_BK\'+@iYear+'\'+@iMonth+'\'+@iDay+'"'
	--EXEC master..xp_cmdshell @strSQL

	Set @FileBKPath='E:\PALFA\Share\PDCA\WWSFS\Import\MANUAL-MaterialSN_BK\'+@iYear+'\'+@iMonth+'\'+@iDay+'\'	

	While Exists(Select 1 From #MaterialSN)   
	Begin 
		Select Top 1 @Model=Model From #MaterialSN
		--Set @FlatFileName='QSMC_MPASS_YLD_'+@Model+'CR_'+@ToDateTime+'.txt' -----0004
		Set @FlatFileName='QCMT_MPASS_YLD_'+@Model+'CR_'+@ToDateTime+'.txt' -----0004
		
		--Housing 因为要由laserbarcode转换为Housing SN，为空或第三码为Q表示没有找到对应的原始Housing SN,记录下转换异常的，便于分析
		--update #MaterialSN set Remark ='No LinkedSN' where  Model =@Model and MaterialName in ('Housing')
		--and ( LinkedSN='' or  SUBSTRING(LinkedSN,3,1)='Q' )

		--在调整之前记录下Log
		Insert into PAL_PDCA_MaterialSN_File_Record(MaterialSN, LinkedSN, Remark,FlatFileName, Model,MaterialName, TransDatetime) 
		SELECT MaterialSN ,LinkedSN, Remark, 
		case when Remark in('No LinkedSN') then '' else @FlatFileName end,
		Model,MaterialName,  @CurrentDateTime  FROM  #MaterialSN where Model=@Model

		---调整为送LinkedSN
			update #MaterialSN 
		SET MaterialSN = CASE 
			WHEN CHARINDEX('+', LinkedSN) > 0 THEN LEFT(LinkedSN, 18) -- 包含+号时取前18位（0005）
			ELSE LinkedSN -- 否则保留原值
		END
		where Model =@Model and MaterialName in ('Housing') --and LinkedSN!=''	and SUBSTRING(LinkedSN,3,1)!='Q'

		--处理MaterialSN有'+'号
		update #MaterialSN
		SET MaterialSN = LEFT(MaterialSN,18)
		WHERE MaterialSN LIKE '%+%'

		--将laserbarcode转换为Housing SN异常的，删除下不送Insight
		--delete from  #MaterialSN where Model =@Model and MaterialName in ('Housing') and (LinkedSN='' or SUBSTRING(LinkedSN,3,1)='Q')
							
		Truncate table  PAL_PDCA_MaterialSN_File

		INSERT INTO PAL_PDCA_MaterialSN_File(DataContext, TransDatetime)
		SELECT MaterialSN+char(9)+ScanDate+char(9)
		+ ScanTime+char(9)+Station + char(9) +Plant ,TransDateTime  FROM  #MaterialSN where Model=@Model
		order by TransDateTime

		Insert Into PAL_PDCA_MaterialSN_File(DataContext,TransDatetime) Values ('#END',@CurrentDateTime)
	

		SET @pathJson = ( 
		Select DataContext From PAL_Module.dbo.PAL_PDCA_MaterialSN_File Order by TransDateTime
		FOR JSON PATH); 
		
		SET @parametersJson = ( 
			SELECT 
				@FileBKPath+@FlatFileName as path
				,@pathJson as jsonString 
				,'N' as header
		--		,'\t' as split 
				,@SP_Name as CallSP
			FOR JSON PATH,WITHOUT_ARRAY_WRAPPER); 
		Exec [PAL_Module].dbo.CMDSHELL2CLR 'CreateFile',@parametersJson ,@iResult output ,@iMessage output    --0006
		--Set @strSQL='bcp "Select DataContext From PAL_Module.dbo.PAL_PDCA_MaterialSN_File Order by TransDateTime" queryout '+
		--@FileBKPath+@FlatFileName+
		--' -c -S"10.36.6.86" -U"sa" -P"East#86_qmh2024"'
		--EXEC master..xp_cmdshell @strSQL	

		WAITFOR   DELAY   '00:00:00.200' 

		
		SET @parametersJson = ( 
			SELECT 
				@FileBKPath as Sourcepath 
				,@FileLocalPath as Destpath 
				,@FlatFileName as filename
				,@FlatFileName as newfilename
				,@SP_Name as CallSP
			FOR JSON PATH,WITHOUT_ARRAY_WRAPPER); 
		Exec [PAL_Module].dbo.CMDSHELL2CLR 'CopyFile',@parametersJson,@iResult output ,@iMessage output  ---0006
		--Set @strSQL='"Copy '+@FileBKPath+@FlatFileName+' '+@FileLocalPath+'"'  
		--EXEC master..xp_cmdshell @strSQL

		delete from #MaterialSN where Model=@Model
	End			
	If @Flag='Y'
		Begin
			Update  FAeDatetime  set EDateTime=@ToDateTime,rundatetime=@ToDateTime Where Category='PDCAMaterialSN'
		End	
	Set @StepFlag='Try End'

	Print 'Success!!'
End Try
Begin Catch     
	Select @ErrMsg=N'Stored Precedure:['+@SP_Name+'] is executed exceptionally,'
		+N'ERROR_NUMBER:'+CAST(ERROR_NUMBER() as varchar(50)) 
		+N'ERROR_MESSAGE:'+ERROR_MESSAGE() 
	 
	set @StepFlag=@StepFlag+':' +'Error Happen'
	exec MonitorAgent_SaveErrorLog @SP_Name,'','PDCDMaterialSn' ,@StepFlag,@ErrMsg	 
End Catch

