USE [PAL_Module]
GO
/****** Object:  StoredProcedure [dbo].[usp_PAL_PDCA_OfflineParts_FormatB]    Script Date: 2026-03-27 4:56:15 CH ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO




















--*Program*: <>
--*Programer*:<Jack>      
--*Date*:<2025/3/15>        
--*Description*:<送OfflineyPart至Insight>     
/*
Date                 Owner        Description									Remark
2025/5/20			Jack			DC &LC 从table中获取						0001
2025/5/20			OY				QMH,Change IP FROM 40.91 to 6.86 ,and change the pwd  0002
2025/07/08			OY				ADD Model J700  0003
*/
ALDDDDTER Procedure [dbo].[usp_PAL_PDCA_OfflineParts_FormatB]
	(
		@FromDateTime varchar(20)='',
		@ToDateTime varchar(20)=''
	)
As
SET NOCOUNT ON

declare @ErrMsg Nvarchar(4000)=''
declare @StepFlag varchar(100)='',@Flag varchar(5)=''
declare @SP_Name varchar(100)='usp_PAL_PDCA_OfflineParts_FormatB'
Declare @Model varchar(20)=''
Declare @CurrentDateTime varchar(30)=''
Declare @FlatFileName varchar(150)=''
Begin Try       
	set @SP_Name=isnull(OBJECT_NAME(@@PROCID),'' )
	set @StepFlag='Try Start'	
	Set @CurrentDateTime=dbo.FormatDate(GETDATE(),'YYYYMMDDHHNNSS')
	
	--之所以这样写是为了方便给客户补送某个时间段的资料
	If @FromDateTime='' And  @ToDateTime=''
		Begin
			Set @Flag='Y'
			Select @FromDateTime=EDatetime  From FAeDatetime Where category='PDCAOfflinePartsFormatB'
			-----这里减去一个不规则秒数，目的是防止丢失Run Job的那个时间点塞进来的数据
			Select @ToDateTime =dbo.FormatDate(DateAdd(Second,-28,GetDate()),'YYYYMMDDHHNNSS')		
		End
	If (@FromDateTime='' And  @ToDateTime <>'') Or (@FromDateTime<>'' And  @ToDateTime ='')
		Begin
			Select N'请检查你输入的2个时间，必须是同时为空或者同时不为空'
			Return
		End
			
	Select A.QCI_SN  ,Substring(dbo.FormatDate(dbo.Convert2Date(A.TransDateTime),'YYYYMMDD HH:NN:SS'),1,8) As PickDate,
	Substring(dbo.FormatDate(dbo.Convert2Date(A.TransDateTime),'YYYYMMDD HH:NN:SS'),10,8) As PickTime,
	A.Cust_PN,A.Comp_Desc, Comp_SN ,'' as EEE_Code,A.Line,LotCode As LotCode,DayCode As DateCode,A.Vendor,  A.QCI_Model, A.TransDateTime, 'A' As Flag, A.Station , space(50) as OPID  --0001
	Into #PAL_PTL_Trace_OffLine 
	From PAL_PTL_Trace_OffLine A with(nolock) Where  QCI_Model in('J714','J716','J700') and TransDateTime  Between @FromDatetime and @ToDatetime  --- 0003

	update a set a.OPID=b.OPID  from  #PAL_PTL_Trace_OffLine a,PAL_SystemLog b where a.QCI_SN=b.Serial_Number and a.Line=b.Line and a.Station=b.Station

	Update a Set a.line=b.PDCA_Line From  #PAL_PTL_Trace_OffLine a inner join PAL_Routing_Line b 
	On a.line=b.line Where b.Line!=b.PDCA_Line and b.PDCA_Line!=''and b.SendToPDCA='Y' 

	Delete #PAL_PTL_Trace_OffLine Where line not in (select PDCA_Line from PAL_Routing_Line)

	If not exists(select 1 from #PAL_PTL_Trace_OffLine)
	Begin
		print 'Success-->But No Data'
		return
	End	

	Declare @strSQL nvarchar(600)=''	
	Declare @iYear varchar(6)=''
	Declare @iMonth varchar(6)=''
	Declare @iDay varchar(6)=''
	Declare @FileBKPath varchar(300)=''
	
	Declare @FileLocalPath varchar(300)='E:\PALFA\Share\PDCA\WWSFS\Import\MOD_TRACK_OfflinePart\'
	Set @iYear=Substring(@CurrentDateTime,1,4)
	Set @iMonth=Substring(@CurrentDateTime,5,2)
	Set @iDay=Substring(@CurrentDateTime,7,2)
	----------------------------------------------------------------------------------------------
	Set @strSQL='"MD E:\PALFA\Share\PDCA\WWSFS\Import\MOD_TRACK_OfflinePart_BK\'+@iYear+'"'
	EXEC master..xp_cmdshell @strSQL

	Set @strSQL='"MD E:\PALFA\Share\PDCA\WWSFS\Import\MOD_TRACK_OfflinePart_BK\'+@iYear+'\'+@iMonth+'"'
	EXEC master..xp_cmdshell @strSQL

	Set @strSQL='"MD E:\PALFA\Share\PDCA\WWSFS\Import\MOD_TRACK_OfflinePart_BK\'+@iYear+'\'+@iMonth+'\'+@iDay+'"'
	EXEC master..xp_cmdshell @strSQL

	Set @FileBKPath='E:\PALFA\Share\PDCA\WWSFS\Import\MOD_TRACK_OfflinePart_BK\'+@iYear+'\'+@iMonth+'\'+@iDay+'\'	

	While Exists(Select 1 From #PAL_PTL_Trace_OffLine)   
	Begin 
		Select Top 1 @Model=QCI_Model From #PAL_PTL_Trace_OffLine
		Set @FlatFileName='QCMT_FATP_MOD_'+@Model+'CRB_'+@ToDateTime+'.txt'
											
		Truncate table  PAL_PDCA_OfflinePart_FormatA_File

		INSERT INTO PAL_PDCA_OfflinePart_FormatA_File(DataContext, TransDatetime)
		SELECT QCI_SN+char(9)+PickDate+char(9)+ PickTime+char(9)+Cust_PN+char(9) +Comp_Desc+char(9)+OPID
		+char(9)+EEE_Code+char(9)+Line+char(9)+LotCode+char(9)+DateCode+char(9)+Vendor+char(9)+Flag+char(9)+Comp_SN ,TransDateTime 
		FROM  #PAL_PTL_Trace_OffLine where QCI_Model=@Model
		order by TransDateTime

		Insert Into PAL_PDCA_OfflinePart_FormatA_File(DataContext,TransDatetime) Values ('#END',@CurrentDateTime)
	
		Set @strSQL='bcp "Select DataContext From PAL_Module.dbo.PAL_PDCA_OfflinePart_FormatA_File Order by TransDateTime" queryout '+
		@FileBKPath+@FlatFileName+
		' -c -S"10.36.6.86" -U"sa" -P"East#86_qmh2024"'		--- 0002
		--' -c -S"172.26.40.91" -U"sa" -P"qms7sa"'
		EXEC master..xp_cmdshell @strSQL	

		WAITFOR   DELAY   '00:00:00.200' 
		Set @strSQL='"Copy '+@FileBKPath+@FlatFileName+' '+@FileLocalPath+'"'  
		EXEC master..xp_cmdshell @strSQL

		delete from #PAL_PTL_Trace_OffLine where QCI_Model=@Model
	End			
	If @Flag='Y'
		Begin
			Update  FAeDatetime  set EDateTime=@ToDateTime,rundatetime=@ToDateTime Where Category='PDCAOfflinePartsFormatB'
		End	
	Set @StepFlag='Try End'

	Print 'Success!!'
End Try
Begin Catch     
	Select @ErrMsg=N'Stored Precedure:['+@SP_Name+'] is executed exceptionally,'
		+N'ERROR_NUMBER:'+CAST(ERROR_NUMBER() as varchar(50)) 
		+N'ERROR_MESSAGE:'+ERROR_MESSAGE() 
	 
	set @StepFlag=@StepFlag+':' +'Error Happen'
	exec MonitorAgent_SaveErrorLog @SP_Name,'','PDCAOfflineParts' ,@StepFlag,@ErrMsg	 
End Catch

