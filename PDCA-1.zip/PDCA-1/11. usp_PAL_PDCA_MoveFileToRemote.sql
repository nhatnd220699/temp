USE [PAL_Module]
GO
/****** Object:  StoredProcedure [dbo].[usp_PAL_PDCA_MoveFileToRemote]    Script Date: 2026-03-27 4:54:43 CH ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO




ALSSSSTER Procedure [dbo].[usp_PAL_PDCA_MoveFileToRemote]
(
  @functype varchar(50)=''
)

As
SET NOCOUNT ON
----------------------------------------------------------------------------------------
----------------------------
------------------------------------------------------------------------------
-----Created by Tacey  on 2023-04-04 15-20
-----Purpose: 为了取消DB Server的类似File Server功能，将172.26.16.29到DB Server抓取文档逻辑改为主动Copy至16.29.
----------------------------------------------------------------------------------------------
--########## Update Log Begin  ###################
--Date                 UpdateOwner        Description

--##########Update Log End # ###################
----exec [[_usp_PAL_PDCA_MoveFileToRemote]]
----------------------------------------------------------------------------------------
-----1. 获取时间段.
declare @ErrMsg Nvarchar(4000)=''
declare @StepFlag varchar(100)='',@Flag varchar(5)=''
declare @SP_Name varchar(100)='usp_PAL_PDCA_MoveFileToRemote'

Begin Try       
	set @SP_Name=isnull(OBJECT_NAME(@@PROCID),'' )
	set @StepFlag='Try Start'

	Declare @strSQL nvarchar(600)=''
	Declare @RemotePath VARCHAR(200)=''
	Declare @typename VARCHAR(30)=''

	set @functype=@functype+'%'

	select para_name,para_Value into #PDCAPath from File_Path with(nolock) where SP_name='PDCAtoRemote'and para_name like @functype


	While Exists(Select * From #PDCAPath)   
	Begin 
		SELECT TOP 1 @typename=para_name,@RemotePath=para_Value from #PDCAPath
		set @strSQL='"'+@RemotePath+'"'
		--select @strSQL
		EXEC master..xp_cmdshell @strSQL
		delete from #PDCAPath where para_name=@typename
			--WAITFOR   DELAY   '00:00:00.200' 
	End
	---------------------------------

	----------------------------------------------------------------------------------------
	
	set @StepFlag='Try End'

End Try
Begin Catch     
	Select @ErrMsg=N'Stored Precedure:['+@SP_Name+'] is executed exceptionally,'
		+N'ERROR_NUMBER:'+CAST(ERROR_NUMBER() as varchar(50)) 
		+N'ERROR_MESSAGE:'+ERROR_MESSAGE() 
	 
	set @StepFlag=@StepFlag+':' +'Error Happen'
	exec MonitorAgent_SaveErrorLog @SP_Name,'','Convey out' ,@StepFlag,@ErrMsg	 
End Catch

