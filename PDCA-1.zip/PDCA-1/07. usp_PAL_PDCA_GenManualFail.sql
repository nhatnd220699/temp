USE [PAL_Module]
GO
/****** Object:  StoredProcedure [dbo].[usp_PAL_PDCA_GenManualFail]    Script Date: 2026-03-27 4:52:44 CH ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO



ALDDDTER Procedure [dbo].[usp_PAL_PDCA_GenManualFail]
	(
		 @FromDateTime varchar(20)='',
		@ToDateTime varchar(20)=''
	)
As
set nocount on
----------------------------------------------------------------------------------------
-----Created by OuYang 20190511
-----Purpose: Generate flat file of Manual Fail for PDCA feed.
-----频率：每小时送一次.
-----每次产生00:00到上一个小时的累积资料.
----------------------------------------------------------------------------------------------
--########## Update Log Begin  ###################
--Date             UpdateOwner   Description
---20200312        OuYang        应客户要求送J290 Insight信息 Line 格式 F5-2F-J35  ---0001
---20210520        Freedom       RTrim(A.Serial_Number)+RTrim(c.PAL_P_N) As [CID] 中去掉开头S和PAL_P_N --0002
---20260320		   Neil		     CMDShell更改为CLR   0003
--##########Update Log End # ###################
----------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------
declare @ErrMsg Nvarchar(4000)=''
declare @StepFlag varchar(100)=''
declare @SP_Name varchar(100)='usp_PAL_PDCA_GenManualFail'
Declare @Model varchar(20)=''  
Begin Try       
	set @SP_Name=isnull(OBJECT_NAME(@@PROCID),'' )
	set @StepFlag='Try Start'
	-----1. 获取时间段.
	--Declare @FlatFileName varchar(20)--0027
	Declare @FlatFileName varchar(80)=''
	declare @FromDateTimeF varchar(20)='',
			@ToDateTimeF varchar(20)='',
			@ToDateTimeF_KB varchar(20)=''
     Declare @iResult Varchar(200)='' , @iMessage Nvarchar(max)='' , @parametersJson NVARCHAR(MAX)='',  @pathJson Nvarchar(max)=''
	----------------------------------------------------------------------------------------
	---Select *  from FAeDatetime where category='PDCAManualFail'
	Select @FromDateTime=EDatetime  from FAeDatetime where category='PDCAManualFail'
	set @ToDateTime=dbo.FormatDate(GetDate(),'YYYYMMDDHHNNSS')
	
	set @FromDateTimeF=Substring(@FromDateTime,1,8)+Substring(@FromDateTime,9,2)+':'+Substring(@FromDateTime,11,2)+':'+Substring(@FromDateTime,13,2)
	set @ToDateTimeF=Substring(@ToDateTime,1,8)+Substring(@ToDateTime,9,2)+':'+Substring(@ToDateTime,11,2)+':'+Substring(@ToDateTime,13,2)

	----------------------------------------------------------------------------------------
	-----2. 收集MOD TRACK资料.
	-----注意: Table PAL_PDCA_ManualFail中的Qty字段为varchar，与Table PAL_PDCA_Report(int)不同.

	Truncate Table PAL_PDCA_ManualFail

	Insert Into PAL_PDCA_ManualFail([Family Type],[Product Type],[MPU Speed],[Type],[Stage],[Date],[Time],[Qty],[CID],[Failure Symptom],
			[Diagnostics],[Rework Fix],[Comment],[Error_Date],[Error_Time],[Line],[Comp_SN],[Comp_CustPN],[NewComp_SN],[NewComp_CustPN],[Unit_SN])
		Select distinct  A.Description,B.PO,'' AS [MPU Speed],'FAIL' AS [Type],A.Station AS [Stage],
			[Error_Date]=Substring(A.TransDateTime,1,8) ,
			[Error_Time]= Substring(A.TransDateTime,9,2)+':'+Substring(A.TransDateTime,11,2)+':'+Substring(A.TransDateTime,13,2),
			A.Num,
			---RTrim(A.Serial_Number)+RTrim(c.PAL_P_N)As [CID], ---0002
			CASE WHEN SUBSTRING(A.Serial_Number,1,1)='S' THEN  right(A.Serial_Number,len(A.Serial_Number)-1) ELSE RTrim(A.Serial_Number) END as [CID],
			A.ErrCode AS [Failure Symptom],'' AS [Diagnostics],'' AS [Rework Fix],'' AS [Comment],'' AS [Date],
			'' AS [Time],
			----Case Len(A.[Time])
			----	when 6 then Substring(A.[Time],1,2)+':'+Substring(A.[Time],3,2)+':'+Substring(A.[Time],5,2)
			----	else A.[Time]
			----End,
			A.[Line],
			'','','','',RTrim(A.Serial_Number)
			-------------------------------------------------------------------
			From PQC A with(nolock),PAL_SN b with(nolock),PAL C with(nolock)
			Where B.PO<>''
			and A.Serial_Number=b.QCI_SN
			and b.QCI_PN_1=c.QCI_P_N
			and b.QCI_PN_1 like '1%' 
			and A.ErrCode<>'Pass'
			----and A.[MPU Speed]<>''
			and A.Station<>''
			and A.Station in (select ShopFloor_Format from PAL_PDCA_StageMapping)
			And	A.Description IN ('J290','A132','A290')
			And A.TransDateTime Between @FromDateTimeF and @ToDateTimeF
			----or A.[Date]+A.[Time] Between @FromDateTimeF and @ToDateTimeF)
			----and A.[Error_Time] Like '__:__:__'
	--		------------------------------------------
	--select top 10 * from  PQC A with(nolock) where Description ='J290'
	--select top 10 * from PAL_SN b with(nolock)where Model ='J290'
	--select top 10 * from PAL C with(nolock)
	
	----------------Rework J290还在需求处理中，当前了解到的逻辑：sn,custpn没有变动
	--UPDATE a SET a.CID =b.New_sn +b.Cust_PN
	--FROM PAL_PDCA_ManualFail a INNER JOIN Pal_rework_SN b with(nolock) ON a.CID =b.old_SN +b.Cust_PN
	----------------------------------------------------------------------------------------
	-----(0002)
	Update A
		Set A.Comp_SN=Case when B.NewComp_SN !=''Then B.Comp_SN else ''End,
		A.Comp_CustPN=Case when B.NewComp_SN !=''Then B.Comp_PN else ''End,
		A.NewComp_SN=Case when B.NewComp_SN !=''Then B.NewComp_SN else ''End,
		A.NewComp_CustPN=Case when B.NewComp_SN !=''Then B.NewComp_PN else ''End,
		A.Error_Date = Substring(B.TransDateTime,1,8),
		A.Error_Time = Substring(B.TransDateTime,9,2)+':'+Substring(B.TransDateTime,11,2)+':'+Substring(B.TransDateTime,13,2),
		A.[Rework Fix] = Case when B.SolutionCode ='Re-Test' and B.CorrectiveAction='RSTOK' Then 'Re-test OK'else
							Case when B.NewComp_SN !='' and B.SolutionCode='SWAP'Then 'Replaced Defective Part/CR' else ''End
						 End
		from PAL_PDCA_ManualFail A,PQC_Repair B with(nolock)
		where A.Unit_SN=B.Serial_Number
		and A.[Date]+Replace(A.[Time],':','')=B.ErrTransDateTime 
		-----[Error_Date],[Error_Time]列存放的其实是维修的Date/Time.
		and A.Stage = B.UpStation
		-----[Failure Symptom]上面最初塞入的是PQC的Errcode
		and A.[Failure Symptom] = B.ErrCode
		and A.[Type]='Fail'
		-----只有NewComp_SN不为空的才送新旧Comp S/N, P/N给PDCA.
		-----对于RetestOK 的SN ,并没有更换材料，也要更新其解不良的时间
		------and B.NewComp_SN !=''

	Update A
		Set A.Comp_CustPN=RTrim(B.Option_PALPN)
		from PAL_PDCA_ManualFail A,TDDOPTIO B with(nolock)
		where A.Comp_CustPN=B.Option_Code
	------SELECT TOP 100 * FROM Error_Code 
	Update A
		Set A.[Failure Symptom]=RTrim(B.Description),
			A.[Diagnostics] = RTrim(B.Description)
		from PAL_PDCA_ManualFail A,Error_Code B with(nolock)
		where A.[Failure Symptom]=B.ErrCode

	Update A
		Set A.NewComp_CustPN=RTrim(B.Option_PALPN)
		from PAL_PDCA_ManualFail A,TDDOPTIO B with(nolock)
		where A.NewComp_CustPN=B.Option_Code
	


	Update A
	Set A.stage = B.PDCA_Format from PAL_PDCA_ManualFail A,PAL_PDCA_StageMapping B
		Where A.Stage =B.ShopFloor_Format 
	Delete A from PAL_PDCA_ManualFail A
		Where Stage not in (Select PDCA_Format  from PAL_PDCA_StageMapping) 
			and Stage not in (select BobcatStation from BobCat_RoutingControl B with(nolock) where A.[Family Type]=B.Model)	

	--select top 100 * from PAL_Routing_Line where line ='J35'
		--------------------------0032
	   update a set a.line=b.PDCA_Line 
	   from  PAL_PDCA_ManualFail a inner join   PAL_Routing_Line b 
	   on a.line=b.line 
	   where b.Line!=b.PDCA_Line and b.PDCA_Line!=''and b.SendToPDCA='Y' 
		--------------------------0032

	Delete FROM PAL_PDCA_ManualFail WHERE line not IN (SELECT PDCA_LINE FROM PAL_Routing_Line WITH(NOLOCK) WHERE sendtopdca='Y') 
	-------------(0026)
	----------------------------------------------------------------------------------------
	-----(0021)
	update PAL_PDCA_ManualFail  
		set comp_sn =REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE( REPLACE(Comp_SN,';',' '),',',' '),'&',' '),'/',' '),'"',' '),')',' '),'@',' '),'.',' '),':',' '),'$',' '),'!',' '),'(',' '),'?',' '),
			NewComp_SN  =REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE( REPLACE(NewComp_SN,';',' '),',',' '),'&',' '),'/',' '),'"',' '),')',' '),'@',' '),'.',' '),':',' '),'$',' '),'!',' '),'(',' '),'?',' ')

	Update PAL_PDCA_ManualFail
	  Set [Failure Symptom]=Replace([Failure Symptom],Char(9),' ')
	  where CHARINDEX(CHAR(9),[Failure Symptom])>0
	Update PAL_PDCA_ManualFail
	  Set Diagnostics=Replace(Diagnostics,Char(9),' ')
	  where CHARINDEX(CHAR(9),Diagnostics)>0
	--0047 Begin
	--Error_Date为空就是非Rework的
	Update PAL_PDCA_ManualFail
	  Set Diagnostics=''
	  where Error_Date=''
	--0047 End
	--0048	 Begin
	Update PAL_PDCA_ManualFail
	  Set [Rework Fix]='NA'
	  where Error_Date<>''And [Rework Fix]=''
	--0048	 End
	 Update PAL_PDCA_ManualFail
	  Set [Rework Fix]=Replace([Rework Fix],Char(9),' ')
	  where CHARINDEX(CHAR(9),[Rework Fix])>0
	 Update PAL_PDCA_ManualFail
	  Set [Comment]=Replace([Comment],Char(9),' ')
	  where CHARINDEX(CHAR(9),[Comment])>0

	--------------------------------------------------------------------------------------------

	
	
	Declare @CurrentDateTime varchar(19)
	Set @CurrentDateTime=Replace(Replace(Replace(Convert(varchar(19),GetDate(),121),'-',''),':',''),' ','')
	----Print @CurrentDateTime
	Declare @iYear varchar(6)
	Declare @iMonth varchar(6)
	Declare @iDay varchar(6)
	Declare @FileBKPath varchar(300)
	Declare @strSQL nvarchar(600)
	Declare @FileLocalPath varchar(300)  --	

	Set @iYear=Substring(@CurrentDateTime,1,4)
	Set @iMonth=Substring(@CurrentDateTime,5,2)
	Set @iDay=Substring(@CurrentDateTime,7,2)
	----------------------------------------------------------------------------------------------
	----(0024)备份也放在40.6上
	--Set @strSQL='"MD E:\Data\PDCA\WWSFS\Import\MANUAL-FAIL_BK\'+@iYear+'"'
	--EXEC master..xp_cmdshell @strSQL

	--Set @strSQL='"MD E:\Data\PDCA\WWSFS\Import\MANUAL-FAIL_BK\'+@iYear+'\'+@iMonth+'"'
	--EXEC master..xp_cmdshell @strSQL

	--Set @strSQL='"MD E:\Data\PDCA\WWSFS\Import\MANUAL-FAIL_BK\'+@iYear+'\'+@iMonth+'\'+@iDay+'"'
	--EXEC master..xp_cmdshell @strSQL

	--Set @strSQL='"MD E:\Data\PDCA\WWSFS\Import\MANUAL-FAIL"'
	--EXEC master..xp_cmdshell @strSQL



	SET @parametersJson =  (SELECT 'E:\Data\PDCA\WWSFS\Import\MANUAL-FAIL_BK\'+@iYear+'\'+@iMonth+'\'+@iDay as path FOR JSON PATH,WITHOUT_ARRAY_WRAPPER)
	Exec PAL_Module.dbo.CMDSHELL2CLR 'CreateDirectory',@parametersJson,@iResult output ,@iMessage output   --0003
	
	SET @parametersJson =  (SELECT 'E:\Data\PDCA\WWSFS\Import\MANUAL-FAIL' as path FOR JSON PATH,WITHOUT_ARRAY_WRAPPER)
	Exec PAL_Module.dbo.CMDSHELL2CLR 'CreateDirectory',@parametersJson,@iResult output ,@iMessage output   --0003


	Set @FileBKPath='E:\Data\PDCA\WWSFS\Import\MANUAL-FAIL_BK\'+@iYear+'\'+@iMonth+'\'+@iDay+'\'
	Set @FileLocalPath='E:\Data\PDCA\WWSFS\Import\MANUAL-FAIL\'  ----本地备份后；

	Select Distinct [Family Type] as QCI_Model Into #PAL_PDCA_ManualFail_Model From PAL_PDCA_ManualFail With(nolock) Where [Family Type]<>'' 
	
	update PAL_PDCA_ManualFail set Line = 'F5-2F-J35' where [Family Type]='J290'	---0001
	--select * from PAL_PDCA_ManualFail   where [Family Type]='J290'
	While Exists(Select * from #PAL_PDCA_ManualFail_Model)  ---------0054
	Begin	
			Select Top 1 @Model=QCI_Model from #PAL_PDCA_ManualFail_Model

			Truncate Table PAL_PDCA_ManualFail_File
			-----(0016)
			Insert into PAL_PDCA_ManualFail_File(Col1)
				Select [Family Type]+char(9)+[Product Type]+char(9)+[MPU Speed]+char(9)+[Type]+char(9)+[Stage]+char(9)
				+ [Date]+char(9)+[Time]+char(9)+[Qty]+char(9)+upper([CID])+char(9)+[Failure Symptom]+char(9)+ [Diagnostics]+char(9)
				+[Rework Fix]+char(9)+[Comment]+char(9)+[Error_Date]+char(9)+[Error_Time]+char(9)+[Line]+char(9)
				----------------------------------------------------------------------------------------
				-----(0002)
				+upper([Comp_SN])+char(9)+upper([Comp_CustPN])+char(9)+upper([NewComp_SN])+char(9)+upper([NewComp_CustPN])
				----------------------------------------------------------------------------------------
				As Col1
				from PAL_PDCA_ManualFail with(nolock) where [Family Type]=@Model
	----- 添加结束符#END.

			Insert Into PAL_PDCA_ManualFail_File(Col1) Values ('#END')
			----------------------------------------------------------------------------------------
			-----5. 产生文档.
			-----Select Top 100 * from PAL_PDCA_ManualFail

			Set @FlatFileName='QSMC_MFAIL_YLD_'+@Model+'_'+@ToDateTime+'.txt'
		
			
			SET @pathJson = ( 
				Select Col1 from PAL_Module.dbo.PAL_PDCA_ManualFail_File Order by Col1 Desc
				FOR JSON PATH);  

			SET @parametersJson = ( 
				SELECT 
					@FileBKPath+@FlatFileName as path
					,@pathJson as jsonString 
					,'N' as header
			--		,'\t' as split 
					,@SP_Name as CallSP
				FOR JSON PATH,WITHOUT_ARRAY_WRAPPER); 
			Exec [PAL_Module].dbo.CMDSHELL2CLR 'CreateFile',@parametersJson ,@iResult output ,@iMessage output 
		
			SET @parametersJson = ( 
				SELECT 
					@FileBKPath as Sourcepath 
					,@FileLocalPath as Destpath 
					,@FlatFileName as filename
					,@FlatFileName as newfilename
					,@SP_Name as CallSP
				FOR JSON PATH,WITHOUT_ARRAY_WRAPPER); 
			Exec [PAL_Module].dbo.CMDSHELL2CLR 'CopyFile',@parametersJson,@iResult output ,@iMessage output 

			--Set @strSQL='bcp "Select Col1 from PAL_Module.dbo.PAL_PDCA_ManualFail_File Order by Col1 Desc" queryout '+@FileBKPath+
			--	@FlatFileName+
			--	' -c -S"10.36.6.86" -U"sa" -P"East#86_qmh2024"'
			--------Print @strSQL
			--EXEC master..xp_cmdshell @strSQL
			
			--WAITFOR   DELAY   '00:00:00.200' --	
			--Set @strSQL='"Copy '+@FileBKPath+@FlatFileName+' '+@FileLocalPath+'"'  --	
			--------Print @strSQL
			--EXEC master..xp_cmdshell @strSQL
			----------------------------------------------------------------------------------------
			--每产生一个txt就将该txt塞进PAL_PDCA_Compare
			Insert Into PAL_PDCA_Compare(FileName,Type,Createtime,FeedbkTime,Flag)
			Select @FlatFileName,'ModuleManualFail',@ToDateTime,'','N'
			-----------------------------------------------------------------------------------------
			Delete From #PAL_PDCA_ManualFail_Model Where QCI_Model =@Model
	End

	 update FAeDatetime set  EDatetime=@ToDateTime,RunDateTime=@ToDateTime 
			 where category='PDCAManualFail'

	
	----------------------------------------------------------------------------------------
	set @StepFlag='Try End'

End Try
Begin Catch     -------0002_2
	Select @ErrMsg=N'Stored Precedure:['+@SP_Name+'] is executed exceptionally,'
		+N'ERROR_NUMBER:'+CAST(ERROR_NUMBER() as varchar(50)) 
		+N'ERROR_MESSAGE:'+ERROR_MESSAGE() 
	 
	set @StepFlag=@StepFlag+':' +'Error Happen'
	exec MonitorAgent_SaveErrorLog @SP_Name,'','Convey out' ,@StepFlag,@ErrMsg	 
End Catch

