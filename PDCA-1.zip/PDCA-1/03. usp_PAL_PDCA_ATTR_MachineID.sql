USE [PAL_Module]
GO
/****** Object:  StoredProcedure [dbo].[usp_PAL_PDCA_ATTR_MachineID]    Script Date: 2026-03-26 4:28:39 CH ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO






ALdddTER Procedure [dbo].[usp_PAL_PDCA_ATTR_MachineID]
	(
		@FromDateTime varchar(20)='',
		@ToDateTime varchar(20)=''
	)
As
SET NOCOUNT ON
----------------------------------------------------------------------------------------
----------------------------
------------------------------------------------------------------------------
-----Created by Freedom Gao on 2022-06-13 15-20
-----Purpose: aging柜里的位置信息上传到Insight Agingin OPID data.
----------------------------------------------------------------------------------------------
--########## Update Log Begin  ###################
--Date                 UpdateOwner        Description
--0001                 Freedom           应客户需求，AGINGIN站点送数据到insight需在原有基础上的aging编号，再增加clamp编号信息---0001
--0002                 Freedom           CableNO站点送CRSN对应的CableSN(A1/A2/A3)和TraySN到insight,格式AttributeKey，AttributeValue---0002
--0003                 Freedom           CableSN(A1/A2/A3)后添加送当前使用次数_Count_3----0003
--0004                 Freedom           CABLENO站绑定的TrayLabel_SN送insight----0004
--20250726             Tacey             应SF King:Mudflap ASSY站送OPID，并和Agingin统一格式----0005
--20250726			   Jack Guo			 Add OfflineParts 0006
--20250726             Tacey             应SF King:CableNO站送OPID(Defective_Code),并调整送OPID不为空才送----0007
--20260320			    Neil 		     CMDSHell更改为CLR    0008
--##########Update Log End # ###################
----exec [usp_PAL_PDCA_LCDyield]
----------------------------------------------------------------------------------------
-----1. 获取时间段.
declare @ErrMsg Nvarchar(4000)=''
declare @StepFlag varchar(100)='',@Flag varchar(5)=''
declare @SP_Name varchar(100)='usp_PAL_PDCA_ATTR_MachineID'
Declare @Model varchar(20)=''
Declare @iResult Varchar(200)='' , @iMessage Nvarchar(max)='' , @parametersJson NVARCHAR(MAX)='',  @pathJson Nvarchar(max)=''
Begin Try       
	set @SP_Name=isnull(OBJECT_NAME(@@PROCID),'' )
	set @StepFlag='Try Start'
	Declare @FlatFileName varchar(60)=''
	--之所以这样写是为了方便给客户补送某个时间段的资料
	If @FromDateTime='' And  @ToDateTime=''
	Begin
		Set @Flag='Y'
		Select @FromDateTime=EDatetime  From FAeDatetime Where category='PDCAATTR'
		-----这里减去一个不规则秒数，目的是防止丢失Run Job的那个时间点塞进来的数据
		Select @ToDateTime =dbo.FormatDate(DateAdd(Second,-28,GetDate()),'YYYYMMDDHHNNSS')
		--Select TOP 10000 *  From FAeDatetime Where category='PDCAATTR'
		--UPDATE  TOP(1) FAeDatetime SET EDateTime='20220615113028',RunDateTime='20220615113028' WHERE category='PDCAATTR'

	End
	If (@FromDateTime='' And  @ToDateTime <>'') Or (@FromDateTime<>'' And  @ToDateTime ='')
	Begin
		Select N'请检查你输入的2个时间，必须是同时为空或者同时不为空'
		Return
	End
	
	-----收集资料
	--select top 1000 * from pqc where Station='Agingin' and Description='j290'

	--select Serial_Number,'AGING_MACHINE_ID' as AttributeKey,'Aging-'+OPID as AttributeValue,TransDateTime,Description
	--  into #Agingin_ALL_ATTR_Temp  FROM PQC with(nolock) WHERE Station='Agingin' and TransDateTime Between @FromDatetime and @ToDatetime 
	--                    --   and Serial_Number='C022134000M17T6AN'
    ----0005 增加Mudflap ASSY----0007 CableNO

	select top 100 * from PQC with(nolock)  where Station in('Agingin','Mudflap ASSY','CableNO') and Defective_Code is not null and Defective_Code != ''

      select Serial_Number,OPID,Defective_Code,TransDateTime,Description,Station
	  into #Agingin_ALL_ATTR_Temp  FROM PQC with(nolock) WHERE Station in('Agingin','Mudflap ASSY','CableNO') and TransDateTime Between @FromDatetime and @ToDatetime ----0005 增加Mudflap ASSY

     --select Serial_Number,'AGING_MACHINE_ID' as AttributeKey, 'Aging-'+OPID+'-'+Defective_Code as AttributeValue,   ----0005 统一格式，站别+其他
	 select Serial_Number,Station+' OP ID' as AttributeKey,OPID+' '+Defective_Code as AttributeValue,   ----0005 统一格式，站别+
	 dbo.FormatDate(dbo.Convert2Date(TransDateTime),'YYYY-MM-DD HH:NN:SS') as CapturedTimestamp,Description
	  into #Agingin_ALL_ATTR   from #Agingin_ALL_ATTR_Temp  where  Defective_Code<>'' ----------0001

	  insert into  #Agingin_ALL_ATTR
	   --select Serial_Number,'AGING_MACHINE_ID' as AttributeKey, 'Aging-'+OPID as AttributeValue,
	   select Serial_Number,Station+' OP ID' as AttributeKey, OPID as AttributeValue,  ----0005 统一格式，站别+
	 dbo.FormatDate(dbo.Convert2Date(TransDateTime),'YYYY-MM-DD HH:NN:SS') as CapturedTimestamp,Description
		from #Agingin_ALL_ATTR_Temp  where  OPID<>''  --0007
	    --from #Agingin_ALL_ATTR_Temp  where  Defective_Code=''  --0007

 --    select Serial_Number,AttributeKey,AttributeValue,
	-- dbo.FormatDate(dbo.Convert2Date(TransDateTime),'YYYY-MM-DD HH:NN:SS') as CapturedTimestamp,Description
	-- into #Agingin_ALL_ATTR   from #Agingin_ALL_ATTR_Temp

	 ---select * from #Agingin_ALL_ATTR1
	 --Update #Agingin_ALL_ATTR  set  CapturedTimestamp=dbo.FormatDate(dbo.Convert2Date(CapturedTimestamp),'YYYY-MM-DD HH:NN:SS') 
	    --------0002 Begin  		
		Select * into #CableSN_Tray from 
		PAL_Cable_Control_Statistic with(Nolock)WHERE Station='CableNO' and TransDateTime Between @FromDatetime and @ToDatetime 

		--Select DISTINCT SN,'TrayLabel_SN' AS AttributeKey ,TraySN ,TransDateTime,Model INTO #TraySN from #CableSN_Tray ----0004 取消扫描Cable SN后，这张表数据就没有了

		--insert into  #Agingin_ALL_ATTR
		--select SN, AttributeKey, TraySN ,
		--dbo.FormatDate(dbo.Convert2Date(TransDateTime),'YYYY-MM-DD HH:NN:SS') as CapturedTimestamp,Model  from #TraySN  ---0004

		UPDATE A SET A.Cable_Seq=B.PDCAMaterial_Name from #CableSN_Tray A join MaterialName_Mapping B ON A.Cable_Seq=B.SFMaterial_Name

		insert into #Agingin_ALL_ATTR
		Select SN,Cable_Seq,Cable_SN+'_Count_'+CAST(Current_Qty AS varchar(10)),dbo.FormatDate(dbo.Convert2Date(TransDateTime),'YYYY-MM-DD HH:NN:SS')  as CapturedTimestamp,Model from #CableSN_Tray
	    -------------0002 End---0003
	  Select *  INTO #PAL_SaveTrayLabel from PAL_SaveTrayLabel with(Nolock) where Station='CableNO' and TransDateTime Between @FromDatetime and @ToDatetime
	  
	  insert into #Agingin_ALL_ATTR
      Select Serial_Number,'TrayLabel_SN' AS AttributeKey,TrayLabel_SN,dbo.FormatDate(dbo.Convert2Date(TransDateTime),'YYYY-MM-DD HH:NN:SS') as CapturedTimestamp,
	     '' Model from #PAL_SaveTrayLabel A 
	--- 0006
	select  a.QCI_SN,a.Station+' OP ID' as Station ,b.OPID, dbo.FormatDate(dbo.Convert2Date(a.TransDateTime),'YYYY-MM-DD HH:NN:SS') as CapturedTimestamp,a.QCI_Model  
	into #PAL_PTL_Trace_OffLine
	from PAL_PTL_Trace_OffLine a with(nolock) ,PAL_SystemLog b with(nolock)
	where a.QCI_SN=b.Serial_Number and a.Line=b.Line and a.Station=b.Station
	and a.TransDateTime Between @FromDatetime and @ToDatetime

	insert into #Agingin_ALL_ATTR 
	select QCI_SN,Station,OPID,CapturedTimestamp,QCI_Model   from #PAL_PTL_Trace_OffLine
		--------------------------------------0004
	  IF Exists(SELECT * from #Agingin_ALL_ATTR where Description='')
	  Begin       
			Update A set A.Description=B.Model
			from #Agingin_ALL_ATTR A,PAL_SN B
			where A.Serial_Number=B.QCI_SN and A.Description=''
	  End

	  Update #Agingin_ALL_ATTR set Serial_Number=CASE WHEN SUBSTRING(Serial_Number,1,4)='SC02'   --0006
		THEN  right(Serial_Number,len(Serial_Number)-1) ELSE Serial_Number END 

   
     Truncate table  PAL_PDCA_ATTR_MachineID_File
	--- SELECT TOP 100  * FROM PAL_PDCA_ATTR_MachineID_File
	 INSERT INTO PAL_PDCA_ATTR_MachineID_File([ReworkDesc], [QCI_Model])
	 SELECT Serial_Number+char(9)+AttributeKey+char(9)
		+ AttributeValue+char(9)+CapturedTimestamp As Col1,Description FROM  #Agingin_ALL_ATTR

	Select * Into #PAL_PDCA_ATTR_MachineID_File From PAL_PDCA_ATTR_MachineID_File
	Select distinct QCI_Model Into #PAL_PDCA_ATTR_MachineID_File_Model From PAL_PDCA_ATTR_MachineID_File
	 --select  dbo.FormatDate(dbo.Convert2Date('20220530151515'),'YYYY-MM-DD HH:NN:SS') 
	 --select dbo.FormatDate('20220530151515','YYYY-MM-DD HH:NN:SS')
	 --select * from #Agingin_templ

	Declare @strSQL nvarchar(600)=''
	Declare @CurrentDateTime varchar(19)=''
	Set @CurrentDateTime=Replace(Replace(Replace(Convert(varchar(19),GetDate(),121),'-',''),':',''),' ','')
	--Print @CurrentDateTime
	Declare @iYear varchar(6)=''
	Declare @iMonth varchar(6)=''
	Declare @iDay varchar(6)=''
	Declare @FileBKPath varchar(300)=''
	----Declare @FileLocalPath varchar(300)='E:\PALFA\Share\PDCA\WWSFS\Import\MANUAL-LCDRate\'
	Declare @FileLocalPath varchar(300)='E:\PALFA\Share\PDCA\WWSFS\Import\MANUAL-LCDATTR\'
	Set @iYear=Substring(@CurrentDateTime,1,4)
	Set @iMonth=Substring(@CurrentDateTime,5,2)
	Set @iDay=Substring(@CurrentDateTime,7,2)
	----------------------------------------------------------------------------------------------

	SET @parametersJson =  (SELECT  'E:\PALFA\Share\PDCA\WWSFS\Import\MANUAL-LCDATTR_BK\'+@iYear as path FOR JSON PATH,WITHOUT_ARRAY_WRAPPER)
	Exec PAL_Module.dbo.CMDSHELL2CLR 'CreateDirectory',@parametersJson,@iResult output ,@iMessage output   --0008
	--Set @strSQL='"MD E:\PALFA\Share\PDCA\WWSFS\Import\MANUAL-LCDATTR_BK\'+@iYear+'"'
	--EXEC master..xp_cmdshell @strSQL


	SET @parametersJson =  (SELECT  'E:\PALFA\Share\PDCA\WWSFS\Import\MANUAL-LCDATTR_BK\'+@iYear+'\'+@iMonth as path FOR JSON PATH,WITHOUT_ARRAY_WRAPPER)
	Exec PAL_Module.dbo.CMDSHELL2CLR 'CreateDirectory',@parametersJson,@iResult output ,@iMessage output   --0008
	--Set @strSQL='"MD E:\PALFA\Share\PDCA\WWSFS\Import\MANUAL-LCDATTR_BK\'+@iYear+'\'+@iMonth+'"'
	--EXEC master..xp_cmdshell @strSQL


	SET @parametersJson =  (SELECT  'E:\PALFA\Share\PDCA\WWSFS\Import\MANUAL-LCDATTR_BK\'+@iYear+'\'+@iMonth+'\'+@iDay as path FOR JSON PATH,WITHOUT_ARRAY_WRAPPER)
	Exec PAL_Module.dbo.CMDSHELL2CLR 'CreateDirectory',@parametersJson,@iResult output ,@iMessage output   --0008	
	--Set @strSQL='"MD E:\PALFA\Share\PDCA\WWSFS\Import\MANUAL-LCDATTR_BK\'+@iYear+'\'+@iMonth+'\'+@iDay+'"'
	--EXEC master..xp_cmdshell @strSQL

	Set @FileBKPath='E:\PALFA\Share\PDCA\WWSFS\Import\MANUAL-LCDATTR_BK\'+@iYear+'\'+@iMonth+'\'+@iDay+'\'
	While Exists(Select * From #PAL_PDCA_ATTR_MachineID_File_Model)   
	Begin 
			Select Top 1 @Model=QCI_Model From #PAL_PDCA_ATTR_MachineID_File_Model
			Set @FlatFileName='QCMT_ALL_ATTR_CR_'+@Model+'_'+@ToDateTime+'.txt'
			Truncate Table PAL_PDCA_ATTR_MachineID_File
			Insert Into PAL_PDCA_ATTR_MachineID_File(ReworkDesc)
				Select ReworkDesc From #PAL_PDCA_ATTR_MachineID_File Where QCI_Model=@Model
			Insert Into PAL_PDCA_ATTR_MachineID_File(ReworkDesc) Values ('#END')
			----------------------------------------------------------------------------------------------

			SET @pathJson = ( 
				Select ReworkDesc From PAL_Module.dbo.PAL_PDCA_ATTR_MachineID_File Order by ReworkDesc Desc
				FOR JSON PATH);  

			SET @parametersJson = ( 
				SELECT 
					@FileBKPath+@FlatFileName as path
					,@pathJson as jsonString 
					,'N' as header
			--		,'\t' as split 
					,'usp_PAL_PDCA_ATTR_MachineID' as CallSP
				FOR JSON PATH,WITHOUT_ARRAY_WRAPPER); 
			Exec [PAL_Module].dbo.CMDSHELL2CLR 'CreateFile',@parametersJson ,@iResult output ,@iMessage output 

			--Set @strSQL='bcp "Select ReworkDesc From PAL_Module.dbo.PAL_PDCA_ATTR_MachineID_File Order by ReworkDesc Desc" queryout '+
			--	@FileBKPath+@FlatFileName+
			--	' -c -S"10.36.6.86" -U"sa" -P"East#86_qmh2024"'
			----Print @strSQL
			--EXEC master..xp_cmdshell @strSQL

			WAITFOR   DELAY   '00:00:00.200' 
			SET @parametersJson = ( 
				SELECT 
					@FileBKPath as Sourcepath 
					,@FileLocalPath as Destpath 
					,@FlatFileName as filename
					,@FlatFileName as newfilename
					,'usp_PAL_PDCA_ATTR_MachineID' as CallSP
				FOR JSON PATH,WITHOUT_ARRAY_WRAPPER); 
			Exec [PAL_Module].dbo.CMDSHELL2CLR 'CopyFile',@parametersJson,@iResult output ,@iMessage output    --0008
			--Set @strSQL='"Copy '+@FileBKPath+@FlatFileName+' '+@FileLocalPath+'"'  
			--EXEC master..xp_cmdshell @strSQL



			Delete From #PAL_PDCA_ATTR_MachineID_File_Model Where QCI_Model=@Model
			----------------------------------------------------------------------------------------
			--每产生一个txt就将该txt塞进PAL_PDCA_Compare
			--Insert Into PAL_PDCA_Compare(FileName,Type,CreateTime,FeedBKTime,Flag)  -0007
			--	Select @FlatFileName,'PorATTR_Refurbish',@ToDateTime,@FromDateTime,'N'
			----------------------------------------------------------------------------------------
	End
	---------------------------------

	If @Flag='Y'
	Begin
		Update  FAeDatetime  set EDateTime=@ToDateTime,rundatetime=@ToDateTime
		Where Category='PDCAATTR'
	End
	----------------------------------------------------------------------------------------
	
	set @StepFlag='Try End'

End Try
Begin Catch     
	Select @ErrMsg=N'Stored Precedure:['+@SP_Name+'] is executed exceptionally,'
		+N'ERROR_NUMBER:'+CAST(ERROR_NUMBER() as varchar(50)) 
		+N'ERROR_MESSAGE:'+ERROR_MESSAGE() 
	 
	set @StepFlag=@StepFlag+':' +'Error Happen'
	exec MonitorAgent_SaveErrorLog @SP_Name,'','Convey out' ,@StepFlag,@ErrMsg	 
End Catch

