document.addEventListener('DOMContentLoaded', () => {
    loadData();
    loadEvent();
});

const loadEvent = () => {};

const loadData = () => {
    highchartsInit();
    getDailyBonepileInventory();
    getDailyBonepileInventory2();
    getDailyREInOut();
    getTop10Model();
    getTopERC();
};

const highchartsInit = () => {
    Highcharts.setOptions({
        chart: {
            backgroundColor: 'transparent',
            spacing: [5, 5, 5, 5],
        },

        xAxis: {
            gridLineWidth: 1,
            gridLineColor: '#313f62',
            gridLineDashStyle: 'Dash',
            lineWidth: 1,
            lineColor: '#313f62',
            lineDashStyle: 'ShortDash',
            labels: {
                style: {
                    fontSize: '12px',
                    fontWeight: '600',
                    color: '#7a95c3',
                },
            },
        },

        yAxis: {
            gridLineWidth: 1,
            gridLineColor: '#313f62',
            gridLineDashStyle: 'Dash',
            labels: {
                style: {
                    fontSize: '12px',
                    fontWeight: '600',
                    color: '#7a95c3',
                },
            },
        },

        credits: {
            enabled: false,
        },

        plotOptions: {
            series: {
                borderWidth: 0,
            },
        },
    });
};

// Chart 1
const getDailyBonepileInventory = () => {
    Highcharts.chart('chart-1', {
        chart: {
            type: 'line',
            backgroundColor: 'transparent',
        },
        title: null,
        accessibility: {
            point: {
                valueDescriptionFormat: '{xDescription}{separator}{value} million(s)',
            },
        },
        xAxis: {
            title: null,
            categories: [1995, 2000, 2005, 2010, 2015, 2020, 2023],
        },
        yAxis: {
            title: null,
        },
        tooltip: {
            headerFormat: '<b>{series.name}</b><br />',
            pointFormat: '{point.y} million(s)',
        },
        legend: {
            enabled: false,
        },
        series: [
            {
                name: 'Internet Users',
                data: [16, 361, 1018, 2025, 3192, 4673, 5200],
                color: 'var(--highcharts-color-1, #2caffe)',
            },
        ],
    });
};

// Chart 2
const getDailyBonepileInventory2 = () => {
    Highcharts.chart('chart-2', {
        chart: {
            type: 'line',
            backgroundColor: 'transparent',
        },
        title: null,
        accessibility: {
            point: {
                valueDescriptionFormat: '{xDescription}{separator}{value} million(s)',
            },
        },
        xAxis: {
            title: null,
            categories: [1995, 2000, 2005, 2010, 2015, 2020, 2023],
        },
        yAxis: {
            title: null,
        },
        tooltip: {
            headerFormat: '<b>{series.name}</b><br />',
            pointFormat: '{point.y} million(s)',
        },
        legend: {
            enabled: false,
        },
        series: [
            {
                name: 'Internet Users',
                data: [16, 361, 1018, 2025, 3192, 4673, 5200],
                color: 'var(--highcharts-color-1, #2caffe)',
            },
        ],
    });
};

// Chart 3
const getDailyREInOut = () => {
    Highcharts.chart('chart-3', {
        chart: {
            type: 'column',
        },
        title: null,
        xAxis: {
            categories: ['Arsenal', 'Chelsea', 'Liverpool', 'Manchester United'],
        },
        yAxis: {
            min: 0,
            title: null,
            stackLabels: {
                enabled: true,
            },
        },
        legend: {
            align: 'left',
            x: 60,
            verticalAlign: 'top',
            y: 0,
            floating: true,
            backgroundColor: 'var(--highcharts-background-color, #ffffff)',
            borderColor: 'var(--highcharts-neutral-color-20, #cccccc)',
            borderWidth: 1,
            shadow: false,
            padding: 5,
        },
        tooltip: {
            headerFormat: '<b>{category}</b><br/>',
            pointFormat: '{series.name}: {point.y}<br/>Total: {point.stackTotal}',
        },
        plotOptions: {
            column: {
                stacking: 'normal',
                borderWidth: 0,
                maxPointWidth: 40,
                dataLabels: {
                    enabled: true,
                    style: {
                        color: '#fff',
                        textOutline: '1px contrast',
                        // fontSize: '1.12rem',
                        fontWeight: 'normal',
                    },
                },
            },
        },
        series: [
            {
                name: 'BPL',
                color: '#fddd60',
                data: [3, 5, 1, 13],
            },
            {
                name: 'FA Cup',
                color: '#7cffb2',
                data: [14, 8, 8, 12],
            },
        ],
    });
};

// Chart 4
const getTop10Model = () => {
    Highcharts.chart('chart-4', {
        title:null,
        xAxis: {
            categories: ['Error A', 'Error B', 'Error C', 'Error D', 'Error E'],
            crosshair: true,
        },
        yAxis: [
            {
               title: null
            },
            {
                title: null,
                minPadding: 0,
                maxPadding: 0,
                max: 100,
                min: 0,
                opposite: true,
                labels: {
                    format: '{value}%',
                },
            },
        ],
        tooltip: {
            shared: true,
        },
        legend: {
            enabled: false,
        },
        series: [
            {
                type: 'column',
                name: 'Occurrences',
                data: [45, 26, 12, 8, 5],
                zIndex: 2,
            },
            {
                type: 'pareto',
                name: 'Pareto',
                yAxis: 1,
                zIndex: 3,
                baseSeries: 0, // lấy dữ liệu từ series[0]
            },
        ],
    });
};

// Chart 5
const getTopERC = () => {
    Highcharts.chart('chart-5', {
        title:null,
        xAxis: {
            categories: ['Error A', 'Error B', 'Error C', 'Error D', 'Error E'],
            crosshair: true,
        },
        yAxis: [
            {
               title: null
            },
            {
                title: null,
                minPadding: 0,
                maxPadding: 0,
                max: 100,
                min: 0,
                opposite: true,
                labels: {
                    format: '{value}%',
                },
            },
        ],
        tooltip: {
            shared: true,
        },
        legend: {
            enabled: false,
        },
        series: [
            {
                type: 'column',
                name: 'Occurrences',
                data: [45, 26, 12, 8, 5],
                zIndex: 2,
            },
            {
                type: 'pareto',
                name: 'Pareto',
                yAxis: 1,
                zIndex: 3,
                baseSeries: 0, // lấy dữ liệu từ series[0]
            },
        ],
    });
};
// Table 3
const getAgingDateDistribution = () => {};
